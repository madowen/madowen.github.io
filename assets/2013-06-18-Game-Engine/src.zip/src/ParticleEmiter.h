//
//  ParticleEmiter.h
//  JeProject
//
//  Created by Alex Catalán on 23/06/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_ParticleEmiter_h
#define JeProject_ParticleEmiter_h

#include "includes.h"
#include "Defines.h"
#include "framework.h"
#include "texture.h"
#include "mesh.h"
#include "Particle.h"
#include <vector>
#include <list>

class ParticleEmiter{

//    static std::list<ParticleEmiter*> particleEmiterList;
    std::list<Particle*> particleList;
    Vector3 startPos;
    Vector3 turbulence;
    float speed;
    Texture *texture;
    float particle_per_sec;
    float max_particles;
    float emisortdv;
    float emisormaxtdv;
    float particlemaxtdv;
    
    float startAlpha;
    float startSize;
    Vector3 startColor;
    float endAlpha;
    float endSize;
    Vector3 endColor;
    
    float last_particle;
    int type;
public:    

    ParticleEmiter(Vector3 pos, int t);
    void render();
    void update(float dt);
    void setStartPos(Vector3 pos);
    void addSpeedParticles(Vector3 spd);

};

#endif
