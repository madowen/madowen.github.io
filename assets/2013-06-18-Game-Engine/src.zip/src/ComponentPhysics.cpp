//
//  ComponentPhysics.cpp
//  JeProject
//
//  Created by Alex Catalán on 30/06/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "ComponentPhysics.h"
#include <iostream>

ComponentPhysics::ComponentPhysics(int objectType){ 
    collide = false;
    rotation =   Vector3(0,0,0);
    roll =       Vector3(0,0,1);
    yaw =        Vector3(0,1,0);
    pitch =      Vector3(1,0,0);
    velocity =   Vector3(0,0,0);


    if (objectType == X3_INTERCEPTOR){
        turnspeed = 0.03;
        speed = 1000;
        acc =   0;
        accMax =   40000;
        accMin = 0;
//        accMin = 10000;
        drag = 0.3;
    }
    if (objectType == X3_FIGHTER){
        turnspeed = 0.01;
        speed = 1000;
        acc =   0;
        accMax =   40000;
        accMin = 10000;
        drag = 0.5;
    }
    if (objectType == SPACE_TANK){
        turnspeed = 0.01;
        speed = 1000;
        acc =   0;
        accMax =   40000;
        accMin = 10000;
        drag = 0.5;
    }
    if (objectType == FRIGATE){
        turnspeed = 0.01;
        speed = 1000;
        acc =   0;
        accMax =   40000;
        accMin = 10000;
        drag = 0.5;
    }
}

void ComponentPhysics::onEvent(Event *event){
    if (event->typeEvent == EVENT_UPDATE)
        update(event->elapsed_time);
    if (event->typeEvent == EVENT_GO_COLLISION)
        collide = true;
}

void ComponentPhysics::update(float dt){
    GameObject *owner = getOwner();
    
    if (collide) {
        Vector3 goBack = lastPos - owner->getPosition();
        Matrix44 *mo = owner->getModel();
        mo->setFrontAndOrthonormalize(mo->frontVector());
        mo->traslate(goBack.x, goBack.y, goBack.z);
        collide = false;
    }
    
    lastPos = owner->getPosition();

    velocity = velocity + World::Instance()->getGravity()*dt*500*((accMax-acc)/accMax);                          //vel+=Gt
    velocity = velocity - velocity*(drag);                                          //vel-=vel*-drag        
    
    
    Matrix44 *mo = owner->getModel();
    mo->setFrontAndOrthonormalize(mo->frontVector());
    mo->traslate(velocity.x, velocity.y, velocity.z);
    mo->rotateLocal(1,rotation);

}

