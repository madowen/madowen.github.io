//
//  ResourceFactory.h
//  JeProject
//
//  Created by Alex Catalán on 05/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_ResourceFactory_h
#define JeProject_ResourceFactory_h
#include "Defines.h"
#include "ResourceManager.h"
#include "GameObject.h"
#include "ComponentMeshRender.h"
#include "ComponentParticleEmiter.h"
#include "ComponentAction.h"
#include "ComponentController.h"
#include "ComponentCamera.h"
#include "ComponentAttributes.h"
#include "ComponentPhysics.h"
#include "ComponentHUD.h"
#include "ParticleEmiter.h"

class ResourceFactory
{
public:
    static ComponentMeshRender* createRender(int meshRenderType);
//    static ComponentParticleEmiter* createRender(int meshRenderType);
    static GameObject* createPlayer(float x, float y, float z, int objectType, int team);
    static GameObject* createIAObect(float x, float y, float z, int objectType, int team);
    static GameObject* createCamera(int cameraType, Vector3 eye, Vector3 center, Vector3 up, float fov, float aspect, float near_plane, float far_plane);
    static GameObject* createStaticObject(float x, float y, float z, int objectType, int team);
    static ParticleEmiter* createParticleEmiter(float x, float y, float z,int typeGameObject);
};

#endif
