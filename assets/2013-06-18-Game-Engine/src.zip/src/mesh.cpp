#include "includes.h"
#include "mesh.h"
#include "text.h"
#include <cassert>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

Mesh::Mesh(){
    primitive = GL_TRIANGLES;
}

void Mesh::clear()
{
	vertices.clear();
	normals.clear();
	uvs.clear();
	indices.clear();
}

bool Mesh::load(){
    std::string type = path;
    type = type.substr(type.size()-3,3); 
    if (type == "ASE" || type == "ase")
        return loadASE(this->path);
    else return false;
}

void Mesh::render()
{
	assert(vertices.size() && "No vertices in this mesh");

	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(3, GL_FLOAT, 0, &vertices[0] );

	if (normals.size())
	{
		glEnableClientState(GL_NORMAL_ARRAY);
		glNormalPointer(GL_FLOAT, 0, &normals[0] );
	}
	if (uvs.size())
	{
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		glTexCoordPointer(2,GL_FLOAT, 0, &uvs[0] );
	}
    if (colors.size())
    {
        glEnableClientState(GL_COLOR_ARRAY );
        glColorPointer(4,GL_FLOAT, 0, &colors[0] );
    }
	glDrawArrays(primitive, 0, vertices.size() );
	glDisableClientState(GL_VERTEX_ARRAY);

    if (colors.size())
        glDisableClientState(GL_COLOR_ARRAY);
	if (normals.size())
		glDisableClientState(GL_NORMAL_ARRAY);
	if (uvs.size())
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);

}

void Mesh::renderDebug()
{
    glColor3f(0,0,1);
    float s = 0.75;
    glBegin(GL_LINES);
    for (int i = 0 ; i<vertices.size(); i++) {
        glVertex3f(vertices[i].x, vertices[i].y, vertices[i].z);
        glVertex3f(vertices[i].x+normals[i].x*s, vertices[i].y+normals[i].y*s, vertices[i].z+normals[i].z*s);
    }
    glEnd();
    glColor3f(1,1,1);
}

void Mesh::renderBoundingBox()
{
    glColor3f(1, 0, 0);
    glTranslatef(binfo.center.x, binfo.center.y, binfo.center.z);
//    glScalef(binfo.center.x-binfo.half_size.x, binfo.center.y-binfo.half_size.y, binfo.center.z-binfo.half_size.z);
//    glutWireCube(binfo.half_size.length());
    glBegin(GL_LINES);

    glVertex3f(binfo.half_size.x,binfo.half_size.y,binfo.half_size.z);      //+++
    glVertex3f(binfo.half_size.x,binfo.half_size.y,-binfo.half_size.z);     //++-
    
    glVertex3f(binfo.half_size.x,binfo.half_size.y,binfo.half_size.z);      //+++
    glVertex3f(-binfo.half_size.x,binfo.half_size.y,binfo.half_size.z);     //-++
    
    glVertex3f(binfo.half_size.x,binfo.half_size.y,binfo.half_size.z);      //+++
    glVertex3f(binfo.half_size.x,-binfo.half_size.y,binfo.half_size.z);     //+-+
    
    glVertex3f(binfo.half_size.x,binfo.half_size.y,-binfo.half_size.z);     //++-
    glVertex3f(-binfo.half_size.x,binfo.half_size.y,-binfo.half_size.z);    //-+-
    
    glVertex3f(binfo.half_size.x,binfo.half_size.y,-binfo.half_size.z);     //++-
    glVertex3f(binfo.half_size.x,-binfo.half_size.y,-binfo.half_size.z);    //+--
    
    glVertex3f(binfo.half_size.x,-binfo.half_size.y,binfo.half_size.z);     //+-+
    glVertex3f(-binfo.half_size.x,-binfo.half_size.y,binfo.half_size.z);    //--+
    
    glVertex3f(-binfo.half_size.x,-binfo.half_size.y,binfo.half_size.z);    //--+
    glVertex3f(-binfo.half_size.x,binfo.half_size.y,binfo.half_size.z);     //-++
    
    glVertex3f(-binfo.half_size.x,-binfo.half_size.y,binfo.half_size.z);    //--+
    glVertex3f(-binfo.half_size.x,-binfo.half_size.y,-binfo.half_size.z);   //---

    glVertex3f(-binfo.half_size.x,-binfo.half_size.y,-binfo.half_size.z);   //---
    glVertex3f(binfo.half_size.x,-binfo.half_size.y,-binfo.half_size.z);    //+--
    
    glVertex3f(-binfo.half_size.x,-binfo.half_size.y,-binfo.half_size.z);   //---
    glVertex3f(-binfo.half_size.x,binfo.half_size.y,-binfo.half_size.z);    //-+-
    
    glVertex3f(-binfo.half_size.x,binfo.half_size.y,-binfo.half_size.z);    //-+-
    glVertex3f(-binfo.half_size.x,binfo.half_size.y,binfo.half_size.z);     //-++
    
    glVertex3f(binfo.half_size.x,-binfo.half_size.y,-binfo.half_size.z);    //+--
    glVertex3f(binfo.half_size.x,-binfo.half_size.y,binfo.half_size.z);     //+-+   
    
    glEnd();
    glColor3f(1,1,1);
}



bool Mesh::loadASE(std::string file)
{
//    string binfile = file;
//    binfile+=".bin";
//    ifstream fin(binfile.c_str(),ios::binary);
//    
//    if (fin.is_open()){
//        loadBinary(binfile.c_str());
//    }else{
//        
        text *parser = new text();
        
        if (not parser->create(file.c_str()))return false;
        
        float minx,maxx,miny,maxy,minz,maxz;
        minx=maxx=miny=maxy=minz=maxz=NULL;
        bool first=true;
        
        parser->seek("*MESH_NUMVERTEX"); // busca la palabra
        int num_v = parser->getint();
        parser->seek("*MESH_NUMFACES");
        int num_f = parser->getint();
        std::vector<Vector3> vertex;
        vertex.resize(num_v);
        for(int i = 0; i < num_v; i++){
            parser->seek("*MESH_VERTEX");
            parser->getint();
            float x = parser->getfloat();
            float z = parser->getfloat();
            float y = parser->getfloat();
            if (first){
                minx=x;
                maxx=x;
                miny=y;
                maxy=y;
                minz=z;
                maxz=z;
                first = false;
            }else {
                minx = x<minx ? x : minx;
                maxx = x>maxx ? x : maxx;
                miny = y<miny ? y : miny;
                maxy = y>maxy ? y : maxy;
                minz = z<minz ? z : minz;
                maxz = z>maxz ? z : maxz;
            }
            Vector3 v;
            v.set(x, y, z);
            vertex[i] = v;
        }
        binfo.center = Vector3((minx+maxx)/2.0,(miny+maxy)/2.0,(minz+maxz)/2.0);
        binfo.half_size = binfo.center-Vector3(maxx,maxy,maxz);

        collision_model = newCollisionModel3D();
        collision_model->setTriangleNumber(num_f);
        vertices.resize(num_f*3);
        parser->seek("*MESH_FACE_LIST");
        for (int i = 0; i < num_f*3; i+=3) {
            parser->seek("*MESH_FACE");
            parser->getint();
            parser->getword();
            vertices[i]=vertex[parser->getint()];
            parser->getword();
            vertices[i+1]=vertex[parser->getint()];
            parser->getword();
            vertices[i+2]=vertex[parser->getint()];
            collision_model->addTriangle(vertices[i].x, vertices[i].y, vertices[i].z, vertices[i+1].x, vertices[i+1].y, vertices[i+1].z, vertices[i+2].x, vertices[i+2].y, vertices[i+2].z);

        }
        collision_model->finalize();
    

        parser->seek("*MESH_NUMTVERTEX");
        int num_tv = parser->getint();
        std::vector<Vector2> tvertex;
        tvertex.resize(num_tv);
        parser->seek("*MESH_TVERTLIST");
        for (int i = 0; i < num_tv; i++) {
            parser->seek("*MESH_TVERT");
            parser->getint();
            Vector2 uv;
            float u = parser->getfloat();
            float v = parser->getfloat();
            uv.set(u,v);
            tvertex[i]=uv;
        }
        
        uvs.resize(num_f*3);
        parser->seek("*MESH_TFACELIST");
        for (int i = 0; i < num_f*3; i+=3) {
            parser->seek("*MESH_TFACE");
            parser->getint();
            uvs[i]=tvertex[parser->getint()];
            uvs[i+1]=tvertex[parser->getint()];
            uvs[i+2]=tvertex[parser->getint()];
        }

        parser->seek("*MESH_NORMALS");
        normals.resize(num_f*3);
        for (int i = 0; i < num_f*3; i++) {
                parser->seek("*MESH_VERTEXNORMAL");
                parser->getint();
                float x = parser->getfloat();
                float y = parser->getfloat();
                float z = parser->getfloat();
                Vector3 vnorm;
                vnorm.set(x,z,y);
                normals[i]=vnorm;
        }
                
        if(vertices.size() != normals.size()){
            std::cout << "WARNING!!! SIZES DIFFERENT" << std::endl;
            return false;
        }
        
        delete parser;
//        saveBinary(binfile.c_str());
//    }
    return true;
}

bool Mesh::loadBinary(std::string file)
{    
    ifstream fin(file.c_str(),ios::binary);
    int size;
    
    //read vertex from file
    fin.read((char *)(&size), sizeof(int));
    vertices.resize(size);
    fin.read((char *)(&vertices[0]),sizeof(Vector3)*vertices.size());
    
    //read normals from file
    fin.read((char *)(&size), sizeof(int));
    normals.resize(size);
    fin.read((char *)(&normals[0]),sizeof(Vector3)*normals.size());

    //read texture vertex from file
    fin.read((char *)(&size), sizeof(int));
    uvs.resize(size);
    fin.read((char *)(&uvs[0]),sizeof(Vector3)*uvs.size());
    
//    //read center, half_size and radius
    binfo.center = Vector3(1,1,1);
    binfo.half_size = Vector3(1,1,1);
    fin.read((char *)(&binfo), sizeof(bounding_info));
//    fin.read((char *)(&half_size), sizeof(Vector3)*1);
//    fin.read((char *)(&center), sizeof(Vector3)*1);
//    fin.read((char *)(&radius), sizeof(Vector3));

    fin.close();
    
//    std::cout << "Center" << std::endl;
//    std::cout << " x: " << binfo.center.x << " y: " << binfo.center.y << " z: " << binfo.center.z << std::endl;
//    std::cout << "Halfsize" << std::endl;
//    std::cout << " x: " << binfo.half_size.x << " y: " << binfo.half_size.y << " z: " << binfo.half_size.z << std::endl;
    
    return true;
}

bool Mesh::saveBinary(std::string file)
{
    ofstream fout(file.c_str(),ios::binary);
    int size;

    //write vertex to file
    size = vertices.size();    
    fout.write((char *)(&size), sizeof(int));
    fout.write((char *)(&vertices[0]), sizeof(Vector3)*vertices.size());
    
    //write normals to file
    size = normals.size();
    fout.write((char *)(&size), sizeof(int));
    fout.write((char *)(&normals[0]), sizeof(Vector3)*normals.size());
    
    //write texture vertex to file
    size = uvs.size();
    fout.write((char *)(&size), sizeof(int));
    fout.write((char *)(&uvs[0]), sizeof(Vector2)*uvs.size());
    
//    //write center, half_size and radius
    fout.write((char *)(&binfo), sizeof(bounding_info));
//    fout.write((char *)(&half_size), sizeof(Vector3));
//    fout.write((char *)(&binfo.center), sizeof(Vector3));
//    fout.write((char *)(&radius), sizeof(Vector3));
    
    fout.close();

//    std::cout << "Center" << std::endl;
//    std::cout << " x: " << binfo.center.x << " y: " << binfo.center.y << " z: " << binfo.center.z << std::endl;
//    std::cout << "Halfsize" << std::endl;
//    std::cout << " x: " << binfo.half_size.x << " y: " << binfo.half_size.y << " z: " << binfo.half_size.z << std::endl;

    
    return true;
}

//Box* Mesh::getBoundingBox(){
//    return boundingBox;
//}

CollisionModel3D* Mesh::getCollisionModel(){
    return collision_model;
}

void Mesh::setVertices(std::vector<Vector3> v){
    vertices = v;
}
void Mesh::setNormals(std::vector<Vector3> n){
    normals = n;
}
void Mesh::setUVS(std::vector<Vector2> u){
    uvs = u;
}
void Mesh::setColors(std::vector<Vector4> c){
    colors = c;
}
void Mesh::setPrimitive(int p){
    primitive = p;
}
