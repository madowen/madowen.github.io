//
//  ComponentParticleEmiter.cpp
//  JeProject
//
//  Created by Alex Catalán on 29/06/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "ComponentParticleEmiter.h"
#include "ResourceFactory.h"
#include <iostream>

ComponentParticleEmiter::ComponentParticleEmiter(){
    smoke = false;
    fire = false;
}


void ComponentParticleEmiter::addParticleEmiter(ParticleEmiter *pe){
    particleList.push_back(pe);
}

void ComponentParticleEmiter::onEvent(Event *event){
    if (event->typeEvent == EVENT_UPDATE) {
        this->update(event->elapsed_time);
    }
    if (event->typeEvent == EVENT_RENDER_PARTICLES) {
        this->render();
    }
}

void ComponentParticleEmiter::update(float dt){
    Vector3 p = *getOwner()->getModel()*Vector3(0,0,0);
    ComponentAttributes ca = *((ComponentAttributes*)getOwner()->getComponent("ComponentAttributes"));
    if ((ca.getHealth() < ca.getMaxHealth()*70/100)) {
    
        if (smoke == false) 
            addParticleEmiter(ResourceFactory::createParticleEmiter(p.x,p.y,p.z,SMOKE_ALPHA));
        smoke = true;
    }
    if ((ca.getHealth() < ca.getMaxHealth()*30/100)){
        if (fire == false) {
            addParticleEmiter(ResourceFactory::createParticleEmiter(p.x,p.y,p.z,FIRE));
        }
        fire = true;
    }
    ComponentPhysics *cp = (ComponentPhysics*)getOwner()->getComponent("ComponentPhysics");
    Vector3 spd;
    if (cp) 
        spd = ((ComponentPhysics*)getOwner()->getComponent("ComponentPhysics"))->getVelocity();
    else
        spd = Vector3(0,0,0);
    std::list<ParticleEmiter*>::iterator it;
    for (it=particleList.begin();it!=particleList.end();it++){
        (*it)->setStartPos(p);
        (*it)->addSpeedParticles(spd);
        (*it)->update(dt);
    }
}

void ComponentParticleEmiter::render(){
    std::list<ParticleEmiter*>::iterator it;
    for (it=particleList.begin();it!=particleList.end();it++){
        (*it)->render();
    }
}