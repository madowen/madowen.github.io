//
//  Component.h
//  JeProject
//
//  Created by Alex Catalán on 01/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_Component_h
#define JeProject_Component_h
#include <iostream>
#include "Event.h"
#include "GameObject.h"
class Component
{
private:
    GameObject* cOwner;    
public:
    Component():cOwner(NULL){};
    ~Component(){};
    virtual void onEvent(Event *event){if (event->typeEvent == EVENT_UPDATE) update(event->elapsed_time);};
    void setOwner(GameObject * goOwner){cOwner = goOwner;}
    GameObject* getOwner(){return cOwner;}
    virtual void update(float dt){};
};

#endif
