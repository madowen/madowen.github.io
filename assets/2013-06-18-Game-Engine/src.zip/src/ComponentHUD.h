//
//  ComponentHUD.h
//  JeProject
//
//  Created by Alex Catalán on 29/06/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#ifndef JeProject_ComponentHUD_h
#define JeProject_ComponentHUD_h

#include "includes.h"
#include "Defines.h"
#include "framework.h"
#include "texture.h"
#include "Component.h"
#include <list>

typedef struct{
    Vector2 pos;
    Texture *texture;
    Vector3 color;
    int primitive;
    float sizeX;
    float sizeY;
    float alpha;
}widget;
class ComponentHUD: public Component
{
    std::map<std::string,widget> widgetList;

public:
    ComponentHUD(int type);
    void render();
    void onEvent(Event *event);
    void update();

};

#endif
