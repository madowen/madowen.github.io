//
//  ResourceManager.cpp
//  JeProject
//
//  Created by Alex Catalán on 26/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#include "ResourceManager.h"
#include "mesh.h"
#include "texture.h"
#include <iostream>
#include <utility>
#include <map>

ResourceManager* ResourceManager::pinstance = 0;// Inicializar el puntero
ResourceManager* ResourceManager::Instance ()
{
    if (pinstance == 0)  // ¿Es la primera llamada?
    {
        pinstance = new ResourceManager; // Creamos la instancia
    }
    return pinstance; // Retornamos la dirección de la instancia
}

ResourceManager::ResourceManager()
{
    root_path = "/Users/MaD/Xcode/JeProject/JeProject/resources/";
//    root_path = "./resources/";
    count = 0;
}

ResourceManager::~ResourceManager(){}

void ResourceManager::add(Resource *r){
    if (list.find(r->getName()) == list.end()){ //not found, it's OK
        list.insert(std::pair<std::string,Resource *>(r->getName(),r)); //add to map
        count++;
        error = RESOURCEMANAGER_ERROR_NO;
    }else {
        error = RESOURCEMANAGER_ERROR_EXISTS;
    }
}

Resource* ResourceManager::get(std::string file){
    if (list.find(file) == list.end()){ //not found
        std::string type = file; type = type.substr(type.size()-3,3);
        std::string pathfile = root_path; pathfile+=file;
        if (type == "ASE" || type == "ase"){
            Mesh* resource = new Mesh();
            resource->setName(file.c_str());
            resource->setPath(pathfile.c_str());
            list.insert(std::pair<std::string,Resource *>(file,resource));
        }else if ( type == "TGA" || type == "tga") {
            Texture* resource = new Texture();
            resource->setName(file.c_str());
            resource->setPath(pathfile.c_str());
            list.insert(std::pair<std::string,Resource *>(file,resource));
            std::cout << file << std::endl;
        }
        return list.find(file)->second;
    }else {
        error = RESOURCEMANAGER_ERROR_NO;
        return list.find(file)->second;
    }
}

void ResourceManager::pop(std::string n){
    if (list.find(n) == list.end()){ //not found, it's not OK
        error = RESOURCEMANAGER_ERROR_NOTFOUND;
    }else {
        error = RESOURCEMANAGER_ERROR_NO;
        count--;
        delete list.at(n);
        list.erase(n);
    }
}

int ResourceManager::getCount(){return count;}
int ResourceManager::getError(){return error;}

const char* ResourceManager::messageError(std::string n){
    switch(error)
	{
        case RESOURCEMANAGER_ERROR_NO:
            return "ResourceManager -> No error\n";
        case RESOURCEMANAGER_ERROR_NOTFOUND:
            return "ResourceManager -> Object not found!\n";
        case RESOURCEMANAGER_ERROR_EXISTS:
            return "ResourceManager -> Object already exists\n";
        case RESOURCEMANAGER_ERROR_LOADFAIL:
            std::string err = "ResourceManager -> Fail at load resource: ";
            err += n;
            err +="\n";
            return err.c_str();
	}
	return "ResourceManager -> Undefined error!\n";
}


void ResourceManager::update(){
    std::map<std::string,Resource *>::iterator it;
    for ( it=list.begin() ; it != list.end(); it++ )
        if ((*it).second->load()){
            error = RESOURCEMANAGER_ERROR_NO;
            std::cout << messageError((*it).first);
        }else {
            error = RESOURCEMANAGER_ERROR_LOADFAIL;
            std::cout << messageError((*it).first);
        }
}
