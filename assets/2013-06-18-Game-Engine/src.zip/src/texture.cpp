//
//  texture.cpp
//  JeProject
//
//  Created by Alex Catalán on 24/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#include "texture.h"
#include <iostream>
#include <string.h>

Texture::Texture(){}

bool Texture::load()
{
    std::string type = path;
    type = type.substr(type.size()-3,3);
    if (type == "TGA" || type == "tga"){
        if (loadTGA(path)==false) return false;
    }else return false;
    
    //How to store a texture in VRAM
	glGenTextures(1, &this->texture_id); //we need to create an unique ID for the texture
	glBindTexture(GL_TEXTURE_2D, this->texture_id);	//we activate this id to tell opengl we are going to use this texture
	//glTexImage2D(GL_TEXTURE_2D, 0, 3, tgainfo->width, tgainfo->height, 0, GL_RGB, GL_UNSIGNED_BYTE, tgainfo->data); //upload without mipmaps
    if (this->bpp == 24) //without alpha color
        gluBuild2DMipmaps(GL_TEXTURE_2D, 3, this->width, this->height, GL_RGB, GL_UNSIGNED_BYTE, this->data); //upload the texture and create their mipmaps
    else if (this->bpp == 32) //with alpha color
        gluBuild2DMipmaps(GL_TEXTURE_2D, 4, this->width, this->height, GL_RGBA, GL_UNSIGNED_BYTE, this->data); //upload the texture and create their mipmaps
    //    glGenerateMipmap(texture->texture_id);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR); //set the mag filter
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);	//set the min filter
    
    delete data;
    
    return true;
}

void Texture::bind()
{
    glBindTexture(GL_TEXTURE_2D, this->texture_id);
}
void Texture::unbind()
{
    glBindTexture(GL_TEXTURE_2D, 0);
}

bool Texture::loadTGA(std::string filename)
{
    GLubyte TGAheader[12] = {0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    GLubyte TGAcompare[12];
    GLubyte header[6];
    GLuint bytesPerPixel;
    GLuint imageSize;
    GLuint temp;
    GLuint type = GL_RGBA;
    
    FILE * file = fopen(filename.c_str(), "rb");
    
    if (file == NULL || fread(TGAcompare, 1, sizeof(TGAcompare), file) != sizeof(TGAcompare) ||
        memcmp(TGAheader, TGAcompare, sizeof(TGAheader)) != 0 ||
        fread(header, 1, sizeof(header), file) != sizeof(header))
    {
        if (file == NULL)
            return false;
        else
        {
            fclose(file);
            return false;
        }
    }
        
    this->width = header[1] * 256 + header[0];
    this->height = header[3] * 256 + header[2];
    
    if (this->width <= 0 || this->height <= 0 || (header[4] != 24 && header[4] != 32))
    {
        fclose(file);
        return false;
    }
    
    this->bpp = header[4];
    bytesPerPixel = this->bpp / 8;
    imageSize = this->width * this->height * bytesPerPixel;
    
    this->data = (GLubyte*)malloc(imageSize);
    
    if (this->data == NULL || fread(this->data, 1, imageSize, file) != imageSize)
    {
        if (this->data != NULL)
            free(this->data);
        
        fclose(file);
        return false;
    }
    
    for (GLuint i = 0; i < int(imageSize); i += bytesPerPixel)
    {
        temp = this->data[i];
        this->data[i] = this->data[i + 2];
        this->data[i + 2] = temp;
    }
        
    fclose(file);
    
    return true;
}

void Texture::info()
{
    std::cout << "width= " << width << std::endl;
    std::cout << "height= " << height << std::endl;
    std::cout << "bpp= " << bpp << std::endl;
    
}
