//
//  world.cpp
//  JeProject
//
//  Created by Alex Catalán on 28/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "world.h"
#include "Event.h"
#include <iostream>

World* World::pinstance = 0;// Inicializar el puntero
World* World::Instance ()
{
    if (pinstance == 0)  // ¿Es la primera llamada?
    {
        pinstance = new World; // Creamos la instancia
        atexit(&DestroySingleton);    // At exit, destroy the singleton
    }
    return pinstance; // Retornamos la dirección de la instancia
}

World::World()
{
//    gravity = Vector3(0,-9.8,0);
    gravity = Vector3(0,0,0);
}

World::~World(){
    if (landScape != NULL) delete landScape;
//    std::map<std::string, GameObject*>::iterator it;
//    for (it = child_list.begin(); it != child_list.end(); it++) {
//        delete (*it).second;
//        child_list.erase(it);
//        it--;
//    }
//    if (child_list.size()) child_list.clear();
}

void World::DestroySingleton(){
    if(pinstance != NULL) delete pinstance;
}

GameObject* World::getActivePlayer(){return child_list[activePlayer];}
GameObject* World::getActiveCamera(){return child_list[activeCamera];}
Vector3 World::getGravity(){return gravity;};
void World::setActivePlayer(std::string goName){activePlayer=goName;}
void World::setActiveCamera(std::string goName){activeCamera=goName;}
void World::setLandscape(ComponentMeshRender* mr){landScape = mr;}
ComponentMeshRender* World::getLandscape(){return landScape;}

void World::nextCamera(){
    std::map<std::string, GameObject*>::iterator it;
    it = child_list.find(activeCamera);
    it++;
    if (it == child_list.end()) it = child_list.begin();
    while (!(*it).second->isCamera ) {
        it++;
        if (it == child_list.end()) it = child_list.begin();
    }
    activeCamera = (*it).first;
}


void World::onEvent(Event *event){
    if (event->typeEvent == EVENT_OBJECTIVE_COLLISION) {
        std::cout << "OBJECTIVE COLLISION!!!" << std::endl;
        delete child_list.at(event->key);
        child_list.erase(event->key);
    }
    std::map<std::string, GameObject*>::iterator it;
    for ( it = child_list.begin(); it != child_list.end(); it++){
        (*it).second->onEvent(event);
    }
}

void World::addGameObject(std::string name,GameObject *object, GameObject *parent){
    child_list[name] = object;
    child_list.find(name)->second->setParent(parent);
    
}
GameObject* World::getGameObject(std::string name)
{
    return child_list.at(name);
}

bool World::update(float dt){
    std::map<std::string, GameObject*>::iterator it;
    for ( it = child_list.begin(); it != child_list.end(); it++){
        if ((*it).second->ttd == 0){
            if ((*it).first == "player") {
                return true;
            }
            delete (*it).second;
            child_list.erase(it);
            it--;
        }
    }        
        
    updateGlobalModel();
    return false;
}