//
//  Stage.cpp
//  JeProject
//
//  Created by Alex Catalán on 01/07/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "Stage.h"
#include "includes.h"
#include "ResourceManager.h"
#include "ComponentController.h"
#include <iostream>

Stage::Stage(){
    screen = STAGE_MADLABS;
    tdv = 0;
}

void Stage::update(float dt){
    Uint8* keystate = SDL_GetKeyState(NULL);


    switch (screen) {
        case STAGE_MADLABS:
            texture =  (Texture*)ResourceManager::Instance()->get("screens/madlabs.tga");
            texture->load();
            tdv = tdv + dt*100;
            if (tdv > 3) {
                screen = STAGE_LOAD;
                tdv = 0;
                update(0);
            }
            break;
        case STAGE_LOAD:
            texture = (Texture*)ResourceManager::Instance()->get("screens/loading.tga");
            texture->load();
            break;
        case STAGE_MISSION_COMPLETE:
            texture = (Texture*)ResourceManager::Instance()->get("screens/mission_complete.tga");
            texture->load();
            break;
        case STAGE_CREDITS:
            texture = (Texture*)ResourceManager::Instance()->get("screens/credits.tga");
            texture->load();
            if (keystate[SDLK_SPACE]){
                screen = STAGE_MISSION_OBJECTIVES;
            }

            break;
        case STAGE_CONTROLS:
            texture = (Texture*)ResourceManager::Instance()->get("screens/controls.tga");
            texture->load();
            if (keystate[SDLK_SPACE]){
                screen = STAGE_GAME;
            }
            break;
        case STAGE_MISSION_OBJECTIVES:
            texture = (Texture*)ResourceManager::Instance()->get("screens/objectives.tga");
            texture->load();
            if (keystate[SDLK_SPACE]){
                screen = STAGE_GAME;
            }
            break;
            
        case STAGE_GAME_OVER:
            texture = (Texture*)ResourceManager::Instance()->get("screens/gameover.tga");
            texture->load();
            if (keystate[SDLK_SPACE]){
                screen = STAGE_LOAD;
            }
            break;

        default:
            break;
    }
}

void Stage::render(){
    glDisable(GL_DEPTH_TEST);
    float alpha=1;;
    if (screen == STAGE_MISSION_OBJECTIVES) {
        alpha = 0.5;
    }
	glColor4f(1.0f, 1.0f, 1.0f,alpha);
    
    glEnable(GL_TEXTURE_2D);
    
    texture->bind();
    
	glBegin(GL_QUADS);
    glTexCoord2f(0,0);
    glVertex2f(0,1);
    glTexCoord2f(0,1);
    glVertex2f(0,0);
    glTexCoord2f(1,1);
    glVertex2f(1,0);
    glTexCoord2f(1,0);
    glVertex2f(1,1);
    
    glEnd();
    
    texture->unbind();
    
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_DEPTH_TEST);
    
}