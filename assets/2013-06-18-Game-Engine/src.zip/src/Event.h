//
//  Event.h
//  JeProject
//
//  Created by Alex Catalán on 04/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_Event_h
#define JeProject_Event_h

#include "Defines.h"
#include "BulletManager.h"

class GameObject;
class Event{
public:
    int typeEvent;
    float elapsed_time;
    std::string key;
    GameObject* go;
    Bullet* bullet;
    Vector3 point;
    
    Event(){};
    Event(int t):typeEvent(t){};
    Event(int t, float et):typeEvent(t),elapsed_time(et){};
    ~Event(){};
};

#endif
