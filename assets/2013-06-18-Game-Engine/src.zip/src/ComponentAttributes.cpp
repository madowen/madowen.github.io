//
//  ComponentAttributes.cpp
//  JeProject
//
//  Created by Alex Catalán on 19/06/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "ComponentAttributes.h"
#include "BulletManager.h"
#include <iostream>

ComponentAttributes::ComponentAttributes(int objectType){
    if (objectType == X3_FIGHTER) {
        shoot_per_second=5;
        health= 200;
        maxHealth=200;      
        weight=10000;      
    }
    if (objectType == X3_INTERCEPTOR){
        shoot_per_second=10;
        health= 200;
        maxHealth=200;      
        weight=8000;      
    }
    if (objectType == SPACE_TANK){
        shoot_per_second=10;
        health= 500;
        maxHealth=500;
        weight=80000;
    }
    if (objectType == FRIGATE){
        shoot_per_second=10;
        health= 500;
        maxHealth=500;
        weight=80000;
    }
    if (objectType == BOX){
        shoot_per_second = 0;
        health = 3000;
        maxHealth = 3000;
        weight = 4000;
    }
}

float ComponentAttributes::getSPS(){return shoot_per_second;}
float ComponentAttributes::getHealth(){return health;}
float ComponentAttributes::getMaxHealth(){return maxHealth;}
float ComponentAttributes::getWeight(){return weight;}
bool ComponentAttributes::isColliding(){return collide;}

void ComponentAttributes::setSPS(float sps){shoot_per_second=sps;}
void ComponentAttributes::setHealth(float h){
    this->health=h;
    if (health == 0)
        getOwner()->state = DEAD;
}
void ComponentAttributes::setWeight(float w){weight=w;}
void ComponentAttributes::setCollide(bool c){collide=c;}


void ComponentAttributes::onEvent(Event *event){
    if (event->typeEvent == EVENT_UPDATE) 
        update(event->elapsed_time);
    if (event->typeEvent == EVENT_BULLET_COLLISION)
        bulletCollide(*event->bullet);
    if (event->typeEvent == EVENT_GO_COLLISION)
        gameObjectCollide(event->go);
}

void ComponentAttributes::bulletCollide(Bullet b){
    setHealth(health - b.getPower());
    std::cout << "bullet collide!! Power: " << b.getPower() << " Type: " << this->getOwner()->type << " Health: " << health << std::endl;
}

void ComponentAttributes::gameObjectCollide(GameObject *go){
    setHealth(0);
    ComponentAttributes *ca =(ComponentAttributes*)go->getComponent("ComponentAttributes");
    if (ca)
        ca->setHealth(0);
}


void ComponentAttributes::update(float ft){
    if (health < 0) {
        health = 0;
    }
}