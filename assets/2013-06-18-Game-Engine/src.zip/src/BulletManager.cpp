//
//  BulletManager.cpp
//  JeProject
//
//  Created by Alex Catalán on 30/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "Defines.h"
#include "BulletManager.h"

std::list<Bullet*> Bullet::bulletList;

Bullet::Bullet(int objectType){
    if (objectType == X3_FIGHTER) {
        power = 20;
        lifetime = 700;
        color = Vector3(1,0.5,0);
    }
    if (objectType == X3_INTERCEPTOR){
        power = 5;
        lifetime = 1000;
        color = Vector3(0,0.5,1);
    }
}

Vector3 Bullet::getVel(){
    return vel;
}
Vector3 Bullet::getPosition(){
    return pos;
}
Vector3 Bullet::getPositionAnt(){
    return posAnt;
}
std::string Bullet::getAuthor(){
    return author;
}

float Bullet::getPower(){
    return power;
}

void Bullet::setVel(Vector3 v){
    vel = v;
}
void Bullet::setPosition(Vector3 p){
    pos = p;
}
void Bullet::setPositionAnt(Vector3 p){
    posAnt = p;
}
void Bullet::saveBullet(){
    bulletList.push_back(this);
}
void Bullet::setAuthor(std::string a){
    author = a;
}
void Bullet::update(float ft){
    std::list<Bullet*>::iterator it;
    for (it=bulletList.begin(); it!=bulletList.end(); it++) {
        if ((*it)->lifetime > 0){
            (*it)->posAnt = (*it)->pos;
            (*it)->pos = (*it)->pos+(*it)->vel;
            (*it)->lifetime = (*it)->lifetime-ft;
        }else{
            bulletList.remove(*it);
            it--;
        }
    }
}

void Bullet::render(){
    std::list<Bullet*>::iterator it;

    glBegin(GL_LINES);
    for (it=bulletList.begin(); it!=bulletList.end(); it++) {
        glColor3fv((*it)->color.v);
        glVertex3f((*it)->pos.x+(*it)->vel.x, (*it)->pos.y+(*it)->vel.y, (*it)->pos.z+(*it)->vel.z);
        glVertex3f((*it)->pos.x, (*it)->pos.y, (*it)->pos.z);

    }
    glEnd();
//    glDisable(GL_BLEND);
    glColor3f(1, 1, 1);
    
}