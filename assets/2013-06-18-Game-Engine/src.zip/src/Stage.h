//
//  Stage.h
//  JeProject
//
//  Created by Alex Catalán on 01/07/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_Stage_h
#define JeProject_Stage_h

#include "Defines.h"
#include "includes.h"
#include "texture.h"

class Stage{
public:
    
    int screen;
    float tdv;
    Texture *texture;
    
    Stage();
    void render();
    void update(float dt);
    
};

#endif
