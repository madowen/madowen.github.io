//
//  entity.h
//  JeProject
//
//  Created by Alex Catalán on 23/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

// representa cualquier objeto que este en el mundo, ya sea visual o no

#ifndef JeProject_entity_h
#define JeProject_entity_h

#include "includes.h"
#include "Component.h"
#include "Event.h"
#include "mesh.h"
#include "texture.h"
#include <map>

class ComponentMeshRender:public Component
{
public:
    Mesh* mesh;
    Texture* texture;
    
    ComponentMeshRender();
    ~ComponentMeshRender();
    Mesh* getMesh();
    void setMesh(Mesh* m);
    void setTexture(Texture* t);
    void render();
    void onEvent(Event *event);
    void update();
};
#endif
