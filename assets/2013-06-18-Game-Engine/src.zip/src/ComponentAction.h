//
//  ComponentAction.h
//  JeProject
//
//  Created by Alex Catalán on 11/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_ComponentAction_h
#define JeProject_ComponentAction_h
#include "Component.h"
#include "ComponentPhysics.h"
#include "ComponentAttributes.h"
#include "BulletManager.h"

class ComponentAction: public Component{
    
    float last_shoot;
    
public:
    void shoot(std::string author,float dt, int s){
        
        last_shoot += dt*100;

        ComponentAttributes *ca = (ComponentAttributes*) getOwner()->getComponent("ComponentAttributes");
        
        if (last_shoot > 1/ca->getSPS()){
            ComponentPhysics *cp = (ComponentPhysics*) getOwner()->getComponent("ComponentPhysics");
            Matrix44 mo = *getOwner()->getModel();
            Vector3 po = getOwner()->getPosition();

            Bullet *b1 = new Bullet(getOwner()->type);
            Vector3 pos = po+mo.frontVector()*-3;
            pos = pos-mo.rightVector()*5;
            b1->setPosition(pos);
            b1->setVel( mo.frontVector()*-5*cp->getVelocity().length());
            b1->setAuthor(author);
            b1->saveBullet();

            Bullet *b2 = new Bullet(getOwner()->type);
            pos = po+mo.frontVector()*-3;
            pos = pos+mo.rightVector()*5;
            b2->setPosition(pos);
            b2->setVel(mo.frontVector()*-5*cp->getVelocity().length());
            b2->setAuthor(author);
            b2->saveBullet();
            
            last_shoot =0;
        }
    }
    
    void accerelate(float dt, float s){
        ComponentPhysics *cp = (ComponentPhysics*) getOwner()->getComponent("ComponentPhysics");
        if (s) // if is accelerating
            cp->setAcc(cp->getAcc()+cp->getSpeed()*s > cp->getAccMax()? cp->getAccMax() : cp->getAcc()+cp->getSpeed()*s);
        else   // if is not accelerating
            cp->setAcc(cp->getAcc()-cp->getAcc()*0.02 < cp->getAccMin()? cp->getAccMin() : cp->getAcc()-cp->getAcc()*0.02);
        cp->addForce(getOwner()->getModel()->frontVector() * -cp->getAcc()*dt);
    }
    void rotatePitch(float dt,float s){
        ComponentPhysics *cp = (ComponentPhysics*) getOwner()->getComponent("ComponentPhysics");
        if (s == 0) // if is not rotating
            cp->setRotation(Vector3(0,cp->getRotation().y,cp->getRotation().z));
        else if (cp->getRotation().x == 0.0) // if is rotating
            cp->setRotation(cp->getRotation() + cp->getPitch() * cp->getTurnSpeed() * s);    
    }
    void rotateRoll(float dt,float s){
        ComponentPhysics *cp = (ComponentPhysics*) getOwner()->getComponent("ComponentPhysics");
        if (s == 0) 
            cp->setRotation(Vector3(cp->getRotation().x,cp->getRotation().y,0));
        else if (cp->getRotation().z == 0.0)
            cp->setRotation(cp->getRotation() + cp->getRoll() * cp->getTurnSpeed() * s);    
    }
    void rotateYaw(float dt,float s){
        ComponentPhysics *cp = (ComponentPhysics*) getOwner()->getComponent("ComponentPhysics");
        if (s == 0) 
            cp->setRotation(Vector3(cp->getRotation().x,0,cp->getRotation().z));
        else if (cp->getRotation().y == 0.0)
            cp->setRotation( cp->getRotation() + cp->getYaw() * cp->getTurnSpeed() * s*0.5);    
    }
};

#endif
