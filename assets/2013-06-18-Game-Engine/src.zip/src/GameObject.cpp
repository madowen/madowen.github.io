//
//  GameObject.cpp
//  JeProject
//
//  Created by Alex Catalán on 01/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "GameObject.h"
#include <iostream>
#include "Component.h"
#include "world.h"

GameObject::GameObject(){
    isCamera = false;
    parent = NULL;
    model = new Matrix44();
    globalModel = new Matrix44();
    state = ALIVE;
    ttd = 60;
}

GameObject::~GameObject(){
    if (model != NULL) delete model;
    if (globalModel != NULL) delete globalModel;
    std::map<std::string, Component*>::iterator it;
    for (it = componentList.begin(); it != componentList.end(); it++) {
        delete (*it).second;
        componentList.erase(it);
        it--;
    }
}

void GameObject::setParent(GameObject* goParent){
    parent = goParent;
}
GameObject* GameObject::getParent(){
    return parent;
}
void GameObject::setModel(){
    globalModel->set();
}
void GameObject::setModel(float x, float y, float z){
    model = new Matrix44();
    model->setIdentity();
    model->traslateLocal(x, y, z);
    
}

Matrix44* GameObject::getModel(){return model;}

void GameObject::addComponent(std::string componentName,Component* comp){
    componentList[componentName] = comp;
    componentList.find(componentName)->second->setOwner(this);
}

Component* GameObject::getComponent(std::string componentName){
    
    if ( componentList.find(componentName) != componentList.end() ) return componentList.find(componentName)->second;
    else return NULL;
}

void GameObject::removeComponent(std::string componentName){
    delete componentList.at(componentName);
    componentList.erase(componentName);
}

void GameObject::addChild(std::string name, GameObject* child){
    World::Instance()->addGameObject(name, child,this);
}

void GameObject::onEvent(Event *event){
    if (event->typeEvent == EVENT_UPDATE) {
        update(event->elapsed_time);
    }
    std::map<std::string, Component*>::iterator it;
    for (it=componentList.begin();it!=componentList.end();it++){
        (*it).second->onEvent(event);
    }
}

void GameObject::update(float dt){
    if (state == DEAD) {
        ttd-dt < 0?ttd=0:ttd-=dt*100 ;
    }
    updateGlobalModel();
}

Matrix44* GameObject::getGlobalModel(){
    if (parent)
        return globalModel;
    else 
        return model;
}

void GameObject::updateGlobalModel(){
    if (parent){
        *globalModel =  *model * *(parent->getGlobalModel());
    }else {
        *globalModel = *model;
    }
    
}

Vector3 GameObject::getPosition(){
    return Vector3(this->model->m[12],this->model->m[13],this->model->m[14]);
}

