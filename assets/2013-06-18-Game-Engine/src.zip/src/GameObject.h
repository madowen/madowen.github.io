//
//  GameObject.h
//  JeProject
//
//  Created by Alex Catalán on 30/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_GameObject_h
#define JeProject_GameObject_h

#include "includes.h"
#include "Defines.h"
#include "framework.h"
#include "Event.h"
#include <map>
#include "BulletManager.h"

class Component;
class GameObject{
private:
    GameObject* parent;
    Matrix44 *model;
    Matrix44 *globalModel;
    std::map<std::string,Component*> componentList;
//    std::map<std::string,GameObject*> childList;
public:
    bool isCamera;
    int state;      //Dead or alive?
    float ttd;      //time to disapear when dead
    int type;
    int team;       // 0 = environment, > 0 = team
    
    GameObject();
    ~GameObject();


    void setParent(GameObject* goParent);
    void setModel();
    void setModel(float x, float y, float z);
    void addComponent(std::string name,Component* comp);

    Vector3 getPosition();
    GameObject* getParent();
    Matrix44* getModel();
    Component* getComponent(std::string componentName);
    Matrix44* getGlobalModel();

    void removeComponent(std::string componentName);
    void addChild(std::string name, GameObject* child);
    void onEvent(Event *event);
    void update(float dt);
    void updateGlobalModel();


};

#endif
