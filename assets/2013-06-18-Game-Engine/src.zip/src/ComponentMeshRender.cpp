//
//  entity.cpp
//  JeProject
//
//  Created by Alex Catalán on 23/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#include "ComponentMeshRender.h"
#include "Event.h"
#include <iostream>

ComponentMeshRender::ComponentMeshRender(){
    mesh = NULL;
    texture = NULL;
}

ComponentMeshRender::~ComponentMeshRender()
{
    if (mesh != NULL) delete mesh;
    if (texture != NULL) delete texture;
}

void ComponentMeshRender::render()
{
    glPushMatrix();
    if (texture ){
        texture->bind();
        glEnable( GL_TEXTURE_2D ); //enable the textures 
    }
    glColor3f(1, 1, 1);
    
    if (getOwner()->team == TEAM_YELLOW) 
        glColor3f(0, 1, 0.5);

    getOwner()->setModel();
//    std::cout << mesh->path << std::endl;
    mesh->render();
//    mesh->renderDebug();
//    mesh->renderBoundingBox();
    glDisable( GL_TEXTURE_2D ); //disable the textures
    glColor3f(1, 1, 1);
   

    glPopMatrix();
}
Mesh* ComponentMeshRender::getMesh(){
    return mesh;
}
void ComponentMeshRender::setMesh(Mesh* m)
{
    mesh = m;
    if (mesh == NULL) {
		std::cout << "ASE File not found" << std::endl;
		exit(0);
    }
}

void ComponentMeshRender::setTexture(Texture* t)
{
    texture = t;
    if (texture == NULL)
    {
		std::cout << "TGA File not found" << std::endl;
		exit(0);
	}
}

void ComponentMeshRender::onEvent(Event *event){
    if (event->typeEvent == EVENT_UPDATE)
        this->update();
    if (event->typeEvent == EVENT_RENDER)
        this->render();
}

void ComponentMeshRender::update(){
}

