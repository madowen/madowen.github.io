//
//  ParticleEmiter.cpp
//  JeProject
//
//  Created by Alex Catalán on 23/06/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#include "ParticleEmiter.h"
#include <iostream>
#include "ResourceFactory.h"

std::list<ParticleEmiter*> particleEmiterList;

ParticleEmiter::ParticleEmiter(Vector3 pos, int t){
    type = t;
    startPos = pos;
    switch (type) {
        case SMOKE_ALPHA:
            speed = 10;
            
            texture = (Texture*)ResourceManager::Instance()->get("particles/smoke_alpha.tga");
            texture->load();
            
            startSize = 5;
            startAlpha = 1;
            startColor = Vector3(0,0,0);;
            endSize = 200;
            endAlpha = 0;
            endColor = Vector3(0,0,0);;
            particle_per_sec = 5;
            max_particles = 100;
            emisortdv = 0;
            emisormaxtdv = 30;
            particlemaxtdv = 20;
            break;
            
        case FIRE:
            startPos = pos;
            speed = 5;
            
            texture = (Texture*)ResourceManager::Instance()->get("particles/explosion.tga");
            texture->load();
            
            startSize = 1;
            startAlpha = 0.2;
            startColor = Vector3(0,0,0);
            endSize = 0;
            endAlpha = 0;
            endColor = Vector3(0,0,0);
            particle_per_sec = 30;
            max_particles = 500;
            emisortdv = 0;
            emisormaxtdv = 20;
            particlemaxtdv = 10;
            break;
            
        default:
            break;
    }
    

}

void ParticleEmiter::update(float dt){
    emisortdv += dt*100;
    last_particle += dt*100;
    
    if (last_particle > 1/particle_per_sec && particleList.size() < max_particles && emisortdv < emisormaxtdv*0.9) {
        if (type == SMOKE_ALPHA) 
            turbulence = Vector3((1*(rand()%100-50)),(3*(rand()%100)),(1*(rand()%100-50)))*speed;
        if (type == FIRE) 
            turbulence = Vector3((0.1*(rand()%100-50)),(0.1*(rand()%100)),(0.1*(rand()%100-50)))*speed;
        particleList.push_front(new Particle(startPos,turbulence));
        last_particle = 0;
    }
    std::list<Particle*>::iterator it;
    for (it=particleList.begin(); it!=particleList.end(); it++) {
        (*it)->update(dt);
        if ((*it)->getTDV() > particlemaxtdv){
            particleList.remove(*it);
            it--;
        }
    }
}

void ParticleEmiter::render(){
    if (particleList.size()) {
        Mesh m;
        m.setPrimitive(GL_QUADS);
        ComponentCamera *cc = (ComponentCamera*)World::Instance()->getActiveCamera()->getComponent("ComponentCamera");

        Vector3 top = cc->getLocalVector(Vector3(0,1,0));
        Vector3 right = cc->getLocalVector(Vector3(1,0,0));
        Vector3 left = (Vector3(0,0,0)-right);
        Vector3 bot = (Vector3(0,0,0)-top);
        glPushMatrix();
        
        std::vector<Vector3> verts;
        std::vector<Vector3> norms;
        std::vector<Vector2> uvs;
        std::vector<Vector4> colors;

        std::list<Particle*>::iterator it;
        for (it=particleList.begin(); it!=particleList.end(); it++) {
            Vector3 p = (*it)->getPosition();
            float size = (startSize+(endSize-startSize)*(*it)->getTDV()/particlemaxtdv);
            Vector3 topright =  p + ( top + right) * size;
            Vector3 topleft  =  p + ( top + left) * size;
            Vector3 botright =  p + ( bot + right) * size;
            Vector3 botleft  =  p + ( bot + left) * size;
            
            verts.push_back(topright);
            verts.push_back(botright);
            verts.push_back(botleft);
            verts.push_back(topleft);
            
            norms.push_back(Vector3(0,0,1));
            norms.push_back(Vector3(0,0,1));
            norms.push_back(Vector3(0,0,1));
            norms.push_back(Vector3(0,0,1));
            uvs.push_back(Vector2(1,1));
            uvs.push_back(Vector2(0,1));
            uvs.push_back(Vector2(0,0));
            uvs.push_back(Vector2(1,0));

            float alpha = startAlpha+(endAlpha-startAlpha)*((*it)->getTDV()/particlemaxtdv);
            Vector3 rgb = startColor+(endColor-startColor)*((*it)->getTDV()/particlemaxtdv);

            colors.push_back(Vector4(rgb.x,rgb.y,rgb.z,alpha));
            colors.push_back(Vector4(rgb.x,rgb.y,rgb.z,alpha));
            colors.push_back(Vector4(rgb.x,rgb.y,rgb.z,alpha));
            colors.push_back(Vector4(rgb.x,rgb.y,rgb.z,alpha));
            
        }
        m.setVertices(verts);
        m.setNormals(norms);
        m.setUVS(uvs);
        m.setColors(colors);
        
        if (texture->data != NULL){
            texture->bind();
            glEnable( GL_TEXTURE_2D ); //enable the textures 
        }else {
            glColor3f(1, 0, 0);
        }
        glDepthMask(GL_FALSE);
        glEnable (GL_BLEND);
        if(type == SMOKE_ALPHA)
            glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        if(type == FIRE)
            glBlendFunc(GL_ONE, GL_ONE);
        
        m.render();
        glDisable( GL_TEXTURE_2D ); //disable the textures
        glDisable(GL_BLEND);
        glDepthMask(GL_TRUE);
        glColor3f(1, 1, 1);
        glPopMatrix();
    }	
}

void ParticleEmiter::setStartPos(Vector3 pos){
    startPos = pos;
}

void ParticleEmiter::addSpeedParticles(Vector3 spd){
    std::list<Particle*>::iterator it;
    for (it=particleList.begin(); it!=particleList.end(); it++)
        (*it)->setSpeed((*it)->getSpeed()+spd);

}