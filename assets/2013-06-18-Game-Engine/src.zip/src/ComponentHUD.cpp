//
//  ComponentHUD.cpp
//  JeProject
//
//  Created by Alex Catalán on 29/06/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "ComponentHUD.h"
#include "ResourceFactory.h"
#include <iostream>

ComponentHUD::ComponentHUD(int type){
    if (type == HUD){
        widget crosshair;
        crosshair.pos = Vector2(0.45,0.45);
        crosshair.sizeX = 0.1;
        crosshair.sizeY = 0.1;
        crosshair.color = Vector3(0,0.75,1);
        crosshair.primitive = GL_QUADS;
        crosshair.alpha = 1;
        crosshair.texture =  (Texture*)ResourceManager::Instance()->get("HUD/crosshair2.tga");
        crosshair.texture->load();
        widgetList["crosshair"] = crosshair;
        widget life;
        life.pos = Vector2(0.01,0.01);
        life.sizeX = 0.25;
        life.sizeY = 0.02;
        life.color = Vector3(1,0,0);
        life.primitive = GL_QUADS;
        life.alpha = 1;
        life.texture = NULL;
        widgetList["life"] = life;
        widget radarQuad;
        radarQuad.pos = Vector2(0.69,0.01);
        radarQuad.sizeX = 0.3;
        radarQuad.sizeY = 0.3;
        radarQuad.color = Vector3(0.5,1,0.5);
        radarQuad.primitive = GL_QUADS;
        radarQuad.alpha = 0.25;
        radarQuad.texture = (Texture*)ResourceManager::Instance()->get("HUD/radar.tga");
        widgetList["radarQuad"] = radarQuad;
    }
    if (type == LOAD) {
        widget load;
        load.pos = Vector2(0.5,0.5);
        load.sizeX = 1;
        load.sizeY = 1;
        load.color = Vector3(1,1,1);
        load.alpha = 1;
        load.texture =  (Texture*)ResourceManager::Instance()->get("screens/madlabs.tga");
        load.texture->load();
        widgetList["load"] = load;
    }
}

void ComponentHUD::onEvent(Event *event){
    if (event->typeEvent == EVENT_RENDER)
        this->render();
    if (event->typeEvent == EVENT_UPDATE) 
        this->update();

}

void ComponentHUD::render(){
    
    glColor3f(1.0f, 1.0f, 1.0f);

    std::map<std::string,widget>::iterator it;
    for (it=widgetList.begin(); it!=widgetList.end(); it++) {
    
        glEnable(GL_TEXTURE_2D);
        if ((*it).second.texture) 
            (*it).second.texture->bind();
        glEnable(GL_BLEND);
        
        glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);    
            
        float x_ini = (*it).second.pos.x+(1*(*it).second.sizeX); //centrado -> (0.5*(*it).sizeX)
        float x_end = (*it).second.pos.x+(0*(*it).second.sizeX); //centrado -> (-0.5*(*it).sizeX)
        float y_ini = (*it).second.pos.y+(1*(*it).second.sizeY); //centrado -> (0.5*(*it).sizeY)
        float y_end = (*it).second.pos.y+(0*(*it).second.sizeY); //centrado -> (-0.5*(*it).sizeY)
       
        Vector3 color = (*it).second.color;
        float alpha = (*it).second.alpha;
        glColor4f(color.x,color.y,color.z,alpha);
        if ((*it).second.primitive == GL_QUADS) {
            glBegin(GL_QUADS);
            glTexCoord2f(0,0);
            glVertex2f(x_ini,y_ini);
            glTexCoord2f(0,1);
            glVertex2f(x_ini,y_end);
            glTexCoord2f(1,1);
            glVertex2f(x_end,y_end);
            glTexCoord2f(1,0);
            glVertex2f(x_end,y_ini);
            glEnd();
        }
        if ((*it).second.primitive == GL_POINTS) {
            glPointSize(4);
            glBegin(GL_POINTS);
            glVertex2f((*it).second.pos.x, (*it).second.pos.y);
            glEnd();
        }
        glColor3f(1,1,1);

        (*it).second.texture->unbind();
        glDisable(GL_BLEND);
        
        glDisable(GL_TEXTURE_2D);
            
    }
}

void ComponentHUD::update(){
    ComponentAttributes *ca = (ComponentAttributes*)getOwner()->getComponent("ComponentAttributes");
    widgetList.at("life").sizeX = 0.25*ca->getHealth()/ca->getMaxHealth();
    Vector3 pos_owner = getOwner()->getPosition();
    std::map<std::string, GameObject*>::iterator it;
    for (it = World::Instance()->child_list.begin(); it != World::Instance()->child_list.end(); it++) {
        if ((*it).second->team != 0){
            Vector3 pos = (*it).second->getPosition();
            float x = pos_owner.x - pos.x;
            float y = pos_owner.z - pos.z;
            if(fabs(x) < 7000 && fabs(y) < 7000){
                widget enemy;
                enemy.sizeX = 0.01;
                enemy.sizeY = 0.01;
                enemy.pos = Vector2(0.84+(x/7000)*widgetList.at("radarQuad").sizeX/2,0.16+(y/7000)*widgetList.at("radarQuad").sizeY/2);
                if ((*it).second->team == TEAM_RED)
                    enemy.color = Vector3(1,0,0);
                if ((*it).second->team == TEAM_BLUE) 
                    enemy.color = Vector3(0,0,1);
                if ((*it).second->team == TEAM_GREEN) 
                    enemy.color = Vector3(0,1,0);
                if ((*it).second->team == TEAM_YELLOW) 
                    enemy.color = Vector3(0,1,0.5);
                enemy.primitive = GL_POINTS;
                enemy.alpha = 1;
                enemy.texture = (Texture*)ResourceManager::Instance()->get("HUD/triangle.tga");
                widgetList[(*it).first] = enemy;
            }else {
                widgetList.erase((*it).first);
            }
        }
    }


    
}