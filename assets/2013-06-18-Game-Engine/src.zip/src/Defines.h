//
//  Defines.h
//  JeProject
//
//  Created by Alex Catalán on 30/06/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_Defines_h
#define JeProject_Defines_h

// Game Stages //
#define STAGE_MADLABS               1
#define STAGE_LOAD                  2
#define STAGE_GAME                  3
#define STAGE_GAME_OVER             4
#define STAGE_CONTROLS              5
#define STAGE_CREDITS               6
#define STAGE_MISSION_COMPLETE      7
#define STAGE_MISSION_OBJECTIVES    8



// ComponentHUD //
#define HUD     1
#define LOAD    2

// Event //
#define EVENT_TEST                  0
#define EVENT_RENDER                1
#define EVENT_RENDER_PARTICLES      7
#define EVENT_UPDATE                2
#define EVENT_GO_COLLISION          3
#define EVENT_OBJECTIVE_COLLISION   8
#define EVENT_BULLET_COLLISION      4
#define EVENT_CAMERA_SET_3D         5
#define EVENT_CAMERA_SET_2D         6

// GameObject //
#define ALIVE   1
#define DEAD    2

// ParticleEmiter //
#define SMOKE_ALPHA     0X01
#define FIRE            0X02

// ResourceFactory //
// **************** COMPONENTS **************** //
#define MESHRENDER              0x1000
#define KEYMOVE                 0x1100
#define CAMERA                  0x1200
#define PHYSICS                 0x1300
#define MOVEMENT                0x1400
#define ATTRIBUTES              0x1500

// ************** MESH + TEXTURE ************** //
// *********** LIGHT FLYING OBJECTS *********** //
#define SPITFIRE                0x1001
#define SPITFIRE_AXIS           0x1002
#define P38                     0x1003
#define P38_AXIS                0x1004
#define X3_FIGHTER              0x1005
#define X3_INTERCEPTOR          0x1006
#define X3_RUNNER               0x1007
#define WILDCAT                 0x1008
#define HUNTER                  0x1009
#define BOMBER                  0x100A
#define BOMBER_AXIS             0x100B
// *********** HEAVY FLYING OBJECTS *********** //
#define EVE_STATION             0x1024
#define SPACE_TANK              0x100C
#define SPACE_TRAIN             0x100D
#define FRIGATE                 0x100E
#define X3_STATION              0x1023
// ********** CUBE MAPS (LANDSCAPES) ********** //
#define CIELO                   0x100F
#define CIELO_CUBEMAP           0x1010
#define SPACE_CUBEMAP           0x1011
#define NEBULA_CUBEMAP          0x1012
#define HELL_CUBEMAP            0x1013
#define STARS_CUBEMAP           0x1014
// ****************** TERRAIN ***************** //
#define TERRAIN                 0x1015
#define TERRAIN_AIRPORT         0x1016
#define ISLAND                  0x1025
// **************** SPACE STUFF *************** //
#define PLANET_CITY_LIGHTS      0x1017
#define PLANET_CLOUDS           0x1018
#define PLANET_CLOUDS2          0x1019
#define PLANET_CRATERS          0x101A
#define PLANET_ISLAND           0x101B
#define PLANET_PLANET_COLOR     0x101C
#define PLANET_PLANET_CRUST     0x101D
#define PLANET_PLANET_SURFACE   0x101E
#define PLANET_PLANET_PURPLE    0x101F
#define ASTEROIDE_1             0x1020
#define ASTEROIDE_2             0x1021
#define ASTEROIDE_3             0x1022
// **************** AMMUNITION **************** //
#define BULLET                  0X1026
// **************** AMMUNITION **************** //
#define BOX                     0X1027

// ****************** CAMERA ****************** //
#define CAMERA_PLAYER           0x1201
#define CAMERA_FREE             0x1202


// ResourceManager //
#define RESOURCEMANAGER_ERROR_NO			  0
#define RESOURCEMANAGER_ERROR_NOTFOUND		  1
#define RESOURCEMANAGER_ERROR_EXISTS		  2
#define RESOURCEMANAGER_ERROR_LOADFAIL		  3

// Teams //
#define TEAM_RED    1
#define TEAM_BLUE   2
#define TEAM_GREEN  3
#define TEAM_YELLOW  4



#endif
