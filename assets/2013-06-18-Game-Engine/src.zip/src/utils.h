#ifndef UTILS_H
#define UTILS_H

#include "framework.h"

//General functions **************
long getTime();

//generic purposes fuctions
void drawGrid(float dist);

#endif
