//
//  KeyMove.h
//  JeProject
//
//  Created by Alex Catalán on 05/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_KeyMove_h
#define JeProject_KeyMove_h
#include "Component.h"
#include <vector>

class ComponentController:public Component
{
public:
    ComponentController(){}
    virtual void update(float dt){};
};

enum XBOXpad{
	//axis
	LEFT_ANALOG_X = 0,
	LEFT_ANALOG_Y = 1,
	RIGHT_ANALOG_X = 2,
	RIGHT_ANALOG_Y = 3,
	TRIGGERS = 4, //both triggers share an axis (positive is right, negative is left trigger)
    
	//buttons
	A_BUTTON = 0,
	B_BUTTON = 1,
	X_BUTTON = 2,
	Y_BUTTON = 3,
	LB_BUTTON = 4,
	RB_BUTTON = 5,
	BACK_BUTTON = 6,
	START_BUTTON = 7,
	LEFT_ANALOG_BUTTON = 8,
	RIGHT_ANALOG_BUTTON = 9
};

enum HATState{
	HAT_CENTERED = 0x00,
	HAT_UP = 0x01,
	HAT_RIGHT = 0x02,
	HAT_DOWN = 0x04,
	HAT_LEFT = 0x08,
	HAT_RIGHTUP = (HAT_RIGHT|HAT_UP),
	HAT_RIGHTDOWN = (HAT_RIGHT|HAT_DOWN),
	HAT_LEFTUP = (HAT_LEFT|HAT_UP),
	HAT_LEFTDOWN = (HAT_LEFT|HAT_DOWN)
};

struct JoystickState{
	int num_axis;	//num analog sticks
	int num_buttons; //num buttons
	float axis[8]; //analog stick
	char button[16]; //buttons
	HATState hat; //digital pad
};

class ComponentControllerPlayer:public ComponentController
{
//    double last_time;
//    double time;
    SDL_Joystick* joystick;

    public:
    void update(float dt);
    bool openJoystick(int num_joystick);
    JoystickState getJoystickState();
};

class ComponentControllerIA:public ComponentController
{
    std::string estado;
    std::vector<Vector3> puntos_patrulla;
    int patrulla;
    float viewing_angle;
public:
    ComponentControllerIA();
    Vector3 locateObjective(Vector3 posObjective, float dt);
    void faceObjective(float right, float top, float dt);
    bool chaseObjective(float distance, float dt);
    void update(float dt);
};

class ComponentControllerCamera:public ComponentController
{
public:
    bool lock_mouse; //to block the mouse to navigate
    int mouse_last_x, mouse_last_y; //last mouse position
    ComponentControllerCamera():lock_mouse(false){};
    void onEvent(Event *event){if (event->typeEvent == EVENT_UPDATE) update(event->elapsed_time);};    
    void update(float dt);
};

#endif
