//
//  Particle.h
//  JeProject
//
//  Created by Alex Catalán on 26/06/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_Particle_h
#define JeProject_Particle_h

#include "framework.h"


class Particle {
    Vector3 position;
    Vector3 speed;
    float tdv;
    
    float last_time;
    
public:
    Particle(Vector3 p,Vector3 s);
    Vector3 getPosition();
    void setPosition(Vector3 p);
    float getTDV();
    Vector3 getSpeed();
    void setSpeed(Vector3 spd);
    void render();
    void update(float dt);
};

#endif
