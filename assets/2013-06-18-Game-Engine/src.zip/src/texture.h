//
//  texture.h
//  JeProject
//
//  Created by Alex Catalán on 24/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_texture_h
#define JeProject_texture_h

#include "includes.h"
#include "Resource.h"

class Texture: public Resource
{
private:
    bool loadTGA(std::string filename);
public:
    GLuint width;
	GLuint height;
	GLuint bpp; //bits per pixel
	GLubyte* data; //bytes with the pixel information
    GLuint texture_id; // GL id to identify the texture in opengl, every texture must have its own id
    
    Texture();

    bool load();
    void bind();
    void unbind();
    void info();


};

#endif
