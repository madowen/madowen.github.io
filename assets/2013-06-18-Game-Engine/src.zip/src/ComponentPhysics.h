//
//  Physics.h
//  JeProject
//
//  Created by Alex Catalán on 04/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_Physics_h
#define JeProject_Physics_h
#include "Defines.h"
#include "Component.h"
#include "world.h"


class ComponentPhysics: public Component
{
    int objectType;
    bool collide;
    float speed;
    float acc;           
    float accMax; 
    float accMin;
    float turnspeed;   
    Vector3 lastPos;
    Vector3 rotation;           
    Vector3 yaw;
    Vector3 pitch;
    Vector3 roll;
    
    float drag;
    Vector3 velocity;
public:
    
    ComponentPhysics(int objectType);
    ~ComponentPhysics(){
    };
    
    float   getSpeed(){return speed;};
    float   getAcc(){return acc;};
    float   getAccMax(){return accMax;};
    float   getAccMin(){return accMin;};
    float   getTurnSpeed(){return turnspeed;}
    Vector3 getRotation(){return rotation;};
    Vector3 getPitch(){return pitch;};
    Vector3 getYaw(){return yaw;};
    Vector3 getRoll(){return roll;};
    Vector3 getVelocity(){return velocity;};
    
    void setRotation(Vector3 r){rotation=r;};
    void setAcc(float a){acc=a;};
    void setAccMax(float am){accMax=am;};
    void setAccMin(float am){accMin=am;};
    void setTurnSpeed(float ts){turnspeed = ts;};
    void setPitch(Vector3 p){pitch = p;};
    void setYaw(Vector3 y){yaw = y;};
    void setRoll(Vector3 r){roll = r;};
    void addForce(Vector3 force){velocity = velocity + force;};
    
    void onEvent(Event *event);    
    void update(float dt);
};
#endif
