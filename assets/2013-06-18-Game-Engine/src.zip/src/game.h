//
//  game.h
//  JeProject
//
//  Created by Alex Catalán on 27/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

// gestiona el hardware, controla el raton, teclado, joystick, etc

#ifndef JeProject_game_h
#define JeProject_game_h
#include "Defines.h"
#include "includes.h"
#include "Componentcamera.h"
#include "ComponentHUD.h"
#include "utils.h"
#include "ResourceManager.h"
#include "ResourceFactory.h"
#include "GameObject.h"
#include "world.h"
#include "Stage.h"
#include "ComponentController.h"
#include "ParticleEmiter.h"

class Game{
public:
    Stage stage;
    bool load;
    long last_time; //this is used to calcule the elapsed time between frames
    Uint8 *keystate; //here we store the keyboard state
    int mouse_last_x, mouse_last_y; //last mouse position
    bool lock_mouse; //to block the mouse to navigate
    
    Game();
    ~Game();

    int createWindow(const char* caption, int width, int height, bool fullscreen=false);
    void init(void); // here we prepare everything
    void onKeyPressed( SDL_KeyboardEvent event ); // Keyboard event handler (sync input)
    void update(double seconds_elapsed);
    void onDraw(void); //what to do when the image has to be draw
    void bulletCollisionCheck();
    void gameObjectCollisionCheck();
    void GameOver();


};

#endif
