//
//  ResourceFactory.cpp
//  JeProject
//
//  Created by Alex Catalán on 05/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "ResourceFactory.h"
#include <iostream>

GameObject* ResourceFactory::createPlayer(float x, float y, float z, int objectType, int team){
        
    GameObject *player = new GameObject();
    player->setModel(x, y, z);
    player->team = team;
    player->ttd = 5;
//    player->type = objectType;
    player->addComponent("ComponentAction", new ComponentAction());
    player->addComponent("ComponentPhysics", new ComponentPhysics(objectType));
    player->addComponent("ComponentAttributes", new ComponentAttributes(objectType));
    player->addComponent("ComponentController", new ComponentControllerPlayer());
    player->addComponent("ComponentParticleEmiter", new ComponentParticleEmiter());
    player->addComponent("ComponentHUD", new ComponentHUD(HUD));
    player->addComponent("ComponentMeshRender", createRender(objectType));
    
    return player;
}

GameObject* ResourceFactory::createIAObect(float x, float y, float z, int objectType, int team){
    
    GameObject *iaobject = new GameObject();
    iaobject->setModel(x, y, z);
    iaobject->type = objectType;
    iaobject->team = team;
    iaobject->addComponent("ComponentAction", new ComponentAction());
    iaobject->addComponent("ComponentPhysics", new ComponentPhysics(objectType));
    iaobject->addComponent("ComponentAttributes", new ComponentAttributes(objectType));
    iaobject->addComponent("ComponentParticleEmiter", new ComponentParticleEmiter());
    iaobject->addComponent("ComponentController", new ComponentControllerIA());
    iaobject->addComponent("ComponentMeshRender", createRender(objectType));
    
    return iaobject;
}

GameObject* ResourceFactory::createStaticObject(float x, float y, float z, int objectType, int team){
    GameObject *go = new GameObject();
    go->setModel(x,y,z);
    go->team = team;
    go->addComponent("ComponentMeshRender", createRender(objectType));
    if (objectType == BOX){
        go->addComponent("ComponentAttributes", new ComponentAttributes(objectType));
        go->addComponent("ComponentParticleEmiter", new ComponentParticleEmiter());
    }

    return go;
}

GameObject* ResourceFactory::createCamera(int cameraType ,Vector3 eye, Vector3 center, Vector3 up, float fov, float aspect, float near_plane, float far_plane ){
    GameObject *goCamera = new GameObject();
    ComponentCamera *camera3D = new ComponentCamera();
	camera3D->lookAt(eye,center,up);
	camera3D->setPerspective(fov,aspect,near_plane,far_plane);
    if (cameraType == CAMERA_PLAYER){ 
        camera3D->setCameraPlayer(true);
//        ComponentCamera *camera2D = new ComponentCamera();
//        camera2D->setOrthographic(0, 1, 0, 1, -1, 1);
//        camera2D->setCameraPlayer(true);
//        goCamera->addComponent("ComponentCameraHUD", camera2D);        
    }
    if (cameraType == CAMERA_FREE) goCamera->addComponent("ComponentController", new ComponentControllerCamera());
    goCamera->addComponent("ComponentCamera", camera3D);
    goCamera->isCamera = true;
    return goCamera;
}


ComponentMeshRender* ResourceFactory::createRender(int meshRenderType){
    ComponentMeshRender *mr = new ComponentMeshRender();
    switch (meshRenderType) {
        case SPITFIRE:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("spitfire/spitfire.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("spitfire/spitfire_color_spec.tga"));
            break;
        case SPITFIRE_AXIS:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("spitfire/spitfire.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("spitfire/spitfire_axis_color_spec.tga"));
            break;
        case P38:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("p38/p38.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("p38/p38.tga"));
            break;
        case P38_AXIS:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("p38/p38.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("p38/p38_axis.tga"));
            break;
        case X3_FIGHTER:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("x3_fighter/x3_fighter.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("x3_fighter/x3_fighter.tga"));
            break;
        case X3_INTERCEPTOR:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("x3_interceptor/x3_interceptor.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("x3_interceptor/x3_interceptor.tga"));
            break;
        case X3_RUNNER:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("x3_runner/x3_runner.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("x3_runner/x3_runner.tga"));
            break;
        case WILDCAT:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("wildcat/wildcat.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("wildcat/wildcat.tga"));
            break;
        case HUNTER:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("hunter/hunter.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("hunter/hunter.tga"));
            break;
        case BOMBER:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("bomber/bomber.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("bomber/bomber.tga"));
            break;
        case BOMBER_AXIS:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("bomber_axis/bomber_axis.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("bomber_axis/bomber_axis.tga"));
            break;
        case EVE_STATION:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("eve_station/eve_station.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("eve_station/eve2.tga"));
            break;
        case FRIGATE:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("frigate/frigate.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("frigate/frigate.tga"));
            break;
        case X3_STATION:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("x3_station/station1.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("x3_station/metal.tga"));
            break;
        case SPACE_TANK:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("space_tank/space_tank.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("space_tank/tank1.tga"));
            break;
        case SPACE_TRAIN:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("space_train/space_train.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("space_train/space_train.tga"));
            break;
        case CIELO:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("cielo/cielo.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("cielo/cielo.tga"));
            break;
        case CIELO_CUBEMAP:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("cubemap/cubemap.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("cubemap/cielo.tga"));
            break;
        case SPACE_CUBEMAP:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("space_cubemap/space_cubemap.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("space_cubemap/space_cubemap.tga"));
            break;
        case NEBULA_CUBEMAP:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("space_cubemap/space_cubemap.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("space_cubemap/nebula.tga"));
            break;
        case HELL_CUBEMAP:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("space_cubemap/space_cubemap.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("space_cubemap/hell.tga"));
            break;
        case STARS_CUBEMAP:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("space_train/space_train.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("space_train/space_train.tga"));
            break;
        case TERRAIN:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("terrain/terrain.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("terrain/pepe.tga"));
            break;
        case ISLAND:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("island/island.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("island/island_color_luz.tga"));
            break;
        case BULLET:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("torpedo_bullet/bullet.ASE"));
            mr->setTexture((Texture*)ResourceManager::Instance()->get("torpedo_bullet/torpedo.tga"));
            break;
        case BOX:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("box/box.ASE"));
            
        default:
            mr->setMesh((Mesh*)ResourceManager::Instance()->get("box/box.ASE"));
//            mr->setTexture((Texture*)ResourceManager::Instance()->get("box/box.tga"));
            break;
    }
    return mr;
}

ParticleEmiter *ResourceFactory::createParticleEmiter(float x, float y, float z,int typeGameObject){
    ParticleEmiter *pe = new ParticleEmiter(Vector3(x,y,z),typeGameObject);
    return pe;
}
