//
//  ResourceManager.h
//  JeProject
//
//  Created by Alex Catalán on 26/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_ResourceManager_h
#define JeProject_ResourceManager_h

#include "Defines.h"
#include <map>
#include "Resource.h"

class ResourceManager
{
protected:
    ResourceManager();
    ResourceManager(const ResourceManager &);
    ResourceManager &operator= (const ResourceManager &);
private:
    static ResourceManager* pinstance;
    
public:
    static ResourceManager* Instance();
    std::map<std::string,Resource *> list;
    const char* root_path; 
    int count;
    int error;

    ~ResourceManager();
    void add(Resource *r);              //add new resource
    Resource* get(std::string file);    //get resource named file
    void pop(std::string n);            //delete resource named n
    int getCount();
    int getError();
    const char* messageError(std::string n= "unknown");
    void update();                  //update resources
};

#endif
