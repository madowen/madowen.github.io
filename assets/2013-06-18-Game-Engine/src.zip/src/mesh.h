#ifndef MESH_H
#define MESH_H

#include <vector>
#include "framework.h"
#include "Resource.h"
#include "coldet/coldet.h"
#include "coldet/box.h"

typedef struct{
    Vector3 center;
    Vector3 half_size;
}bounding_info;

class Mesh : public Resource {
public:
    Mesh();

	void clear();
	void render();
    void renderDebug();
    void renderBoundingBox();
    bool load();
    void setPrimitive(int p);
    void setVertices(std::vector<Vector3> v);
    void setNormals(std::vector<Vector3> n);
    void setUVS(std::vector<Vector2> u);
    void setColors(std::vector<Vector4> c);
    CollisionModel3D* getCollisionModel();

private:
    
    int primitive;
    CollisionModel3D* collision_model;   
    
	std::vector< Vector3 > vertices; //here we store the vertices
	std::vector< Vector3 > normals;	 //here we store the normals
	std::vector< Vector4 > colors;	 //here we store the colors
	std::vector< Vector2 > uvs;	 //here we store the texture coordinates
    
	//we can store the indices or we can skip them and store the mesh uncompressed (without indexing)
	std::vector< Vector3u > indices;	 //here we store the indices
    
    bounding_info binfo;
        
    bool loadASE(std::string);
    bool loadBinary(std::string);
    bool saveBinary(std::string);
};

#endif