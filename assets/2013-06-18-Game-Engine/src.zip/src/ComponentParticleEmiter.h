//
//  ComponentParticleEmiter.h
//  JeProject
//
//  Created by Alex Catalán on 29/06/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#ifndef JeProject_ComponentParticleEmiter_h
#define JeProject_ComponentParticleEmiter_h

#include "Component.h"
#include "ParticleEmiter.h"
#include <list>

class ComponentParticleEmiter: public Component
{
    std::list<ParticleEmiter*> particleList;
    bool smoke;
    bool fire;
public:
    ComponentParticleEmiter();
    void addParticleEmiter(ParticleEmiter *pe);
    void render();
    void onEvent(Event *event);
    void update(float dt);
    
};


#endif
