//
//  KeyMove.cpp
//  JeProject
//
//  Created by Alex Catalán on 05/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "ComponentController.h"
#include "ComponentCamera.h"
#include "ComponentAction.h"
#include "world.h"
#include <iostream>

void ComponentControllerCamera::update(float dt){
    if (World::Instance()->getActiveCamera() == getOwner() ) {
        Uint8* keystate = SDL_GetKeyState(NULL);        
        int x,y, mouse_state;
        mouse_state = SDL_GetMouseState(&x,&y);
        int delta_x = mouse_last_x - x;
        int delta_y = mouse_last_y - y;
        mouse_last_x = x;
        mouse_last_y = y;
        
        ComponentCamera *cc = ((ComponentCamera *)getOwner()->getComponent("ComponentCamera")); 

        float rspeed = 0.1;    
        if ((mouse_state & SDL_BUTTON_LEFT) || lock_mouse ) //is left button pressed?
        {
            cc->rotate(rspeed * delta_x * 0.1, Vector3(0,-1,0));
            cc->rotate(rspeed * delta_y * 0.1, ((ComponentCamera *)getOwner()->getComponent("ComponentCamera"))->getLocalVector( Vector3(-1,0,0)));
        }
        
        float tspeed = 10;
        keystate = SDL_GetKeyState(NULL);
        if (keystate[SDLK_UP])      cc->move(Vector3(0,0,1) * tspeed*0.3);
        if (keystate[SDLK_DOWN])    cc->move(Vector3(0,0,-1) * tspeed*0.3);
        if (keystate[SDLK_LEFT])    cc->move(Vector3(1,0,0) * tspeed*0.3);
        if (keystate[SDLK_RIGHT])   cc->move(Vector3(-1,0,0) * tspeed*0.3);
        //		camera->rotate(speed * delta_y * 0.1, camera->getLocalVector( Vector3(-1,0,0)));
    }
}

void ComponentControllerPlayer::update(float dt){
    if (getOwner()->state == ALIVE) {

        Uint8* keystate = SDL_GetKeyState(NULL);

        ComponentAction *ca = ((ComponentAction*) getOwner()->getComponent("ComponentAction"));
        
        if (keystate[SDLK_LSHIFT]) ca->accerelate(dt,1);
        else ca->accerelate(dt, 0);
        if (keystate[SDLK_w]) ca->rotatePitch(dt,-1);
        else if (keystate[SDLK_s]) ca->rotatePitch(dt,1);
        else ca->rotatePitch(dt,0);
        if (keystate[SDLK_a]) ca->rotateRoll(dt,-1);
        else if (keystate[SDLK_d]) ca->rotateRoll(dt,1);
        else ca->rotateRoll(dt,0);
        if (keystate[SDLK_q]) ca->rotateYaw(dt,-1);
        else if (keystate[SDLK_e]) ca->rotateYaw(dt,1);
        else ca->rotateYaw(dt,0);

        if (keystate[SDLK_SPACE]) ca->shoot("player",dt, 1);   

        if (openJoystick(0)) {
            JoystickState js = getJoystickState();
            if (js.button[LB_BUTTON])
                ca->rotateYaw(dt, -1);
            else if (js.button[RB_BUTTON])
                ca->rotateYaw(dt, 1);
            else
                 ca->rotateYaw(dt, 0);

            if (fabs(js.axis[LEFT_ANALOG_Y]) >= 0.1) 
                ca->rotatePitch(dt, js.axis[LEFT_ANALOG_Y]);
            else
                ca->accerelate(dt, 0);

            if (fabs(js.axis[LEFT_ANALOG_X]) >= 0.1) 
                ca->rotateRoll(dt, js.axis[LEFT_ANALOG_X]);
            else
                ca->rotateRoll(dt, 0);
            
            if (js.button[A_BUTTON]) ca->shoot("player",dt, 1);
            if (js.button[B_BUTTON]) ca->accerelate(dt, 0.9);
        }
    }
}

ComponentControllerIA::ComponentControllerIA(){
    estado = "patrol";
    for (int i = 0; i<3; i++) {
        Vector3 wp = Vector3(rand()%14000-7000,rand()%1000+1000,rand()%14000-7000);
        puntos_patrulla.push_back(wp);
    }
    patrulla = 0;
    viewing_angle=0.1;
}

Vector3 ComponentControllerIA::locateObjective(Vector3 posObjective, float dt){
    Matrix44 mo = *getOwner()->getModel();
    Vector3 pos_enemy = getOwner()->getPosition();
//    Vector3 pos_enemy = Vector3(mo.m[12],mo.m[13],mo.m[14]);

    Vector3 R = pos_enemy-posObjective;
    float distance = R.length();
    R.normalize();
    mo.topVector().normalize();
    mo.frontVector().normalize();
    
    Vector2 owner_xz = Vector2(mo.frontVector().x, mo.frontVector().z);
    Vector2 player_xz = Vector2(R.x, R.z);
    
    Vector2 owner_yz = Vector2(mo.frontVector().y, mo.frontVector().z);
    Vector2 player_yz = Vector2(R.y, R.z);
    
    return Vector3(R.dot(mo.rightVector()),R.dot(mo.topVector()),distance);
}

void ComponentControllerIA::faceObjective (float right, float top, float dt){    
                                                                                 
    ComponentAction *ca = ((ComponentAction*) getOwner()->getComponent("ComponentAction"));
    if (right > 0.02) { //Left
        ca->rotateYaw(dt, -1);  
    }else if (right < -0.02) { //Right
        ca->rotateYaw(dt, 1);   
    }else { //front
        ca->rotateYaw(dt, 0);
    }
    if (top > 0.02) { //down
        ca->rotatePitch(dt, 1); 
    }else if (top < -0.02) { //up
        ca->rotatePitch(dt, -1); 
    }else { //front
        ca->rotatePitch(dt, 0);
    }    
}

bool ComponentControllerIA::chaseObjective(float distance,float dt){
    ComponentAction *ca = ((ComponentAction*) getOwner()->getComponent("ComponentAction"));
    if (distance > 200) {
        ca->accerelate(dt, 1); 
        return false;
    }else return true;
}

void ComponentControllerIA::update(float dt){
    if (getOwner()->state == ALIVE) {
        if (estado == "patrol") {
            Matrix44 mp = *World::Instance()->getActivePlayer()->getModel();
    //        Vector3 pos_player = Vector3(mp.m[12],mp.m[13],mp.m[14]);        
            Vector3 pos_player = World::Instance()->getActivePlayer()->getPosition();        
            Vector3 locationPlayer = locateObjective(pos_player, dt);
            float rightPlayer = locationPlayer.x;
            float topPlayer = locationPlayer.y;
            float distancePlayer = locationPlayer.z;

            if (rightPlayer > -viewing_angle && rightPlayer < viewing_angle && 
                topPlayer > -viewing_angle && topPlayer < viewing_angle &&
                distancePlayer < 1000 && distancePlayer > 0) {
                estado = "chase_player";
                
            }else {
            
                Vector3 locationWaypoint = locateObjective(puntos_patrulla[patrulla], dt);
                float rightWaypoint = locationWaypoint.x;
                float topWaypoint = locationWaypoint.y;
                float distanceWaypoint = locationWaypoint.z;
                
                faceObjective(rightWaypoint, topWaypoint, dt);        
                if (chaseObjective(distanceWaypoint, dt)){
                    patrulla++;
                    if (patrulla >= puntos_patrulla.size()) patrulla = 0;
                    
                }
            }               
        }
        
        
        if (estado == "chase_player") {

            Matrix44 mp = *World::Instance()->getActivePlayer()->getModel();
            Vector3 pos_player = World::Instance()->getActivePlayer()->getPosition();
    //        Vector3 pos_player = Vector3(mp.m[12],mp.m[13],mp.m[14]);        
            Vector3 locationPlayer = locateObjective(pos_player, dt);
            float rightPlayer = locationPlayer.x;
            float topPlayer = locationPlayer.y;
            float distancePlayer = locationPlayer.z;
            
            faceObjective(rightPlayer, topPlayer, dt);
            chaseObjective(distancePlayer, dt);
            if (distancePlayer && rightPlayer > -viewing_angle && rightPlayer < viewing_angle && 
                topPlayer > -viewing_angle && topPlayer < viewing_angle ){
                ComponentAction *ca = ((ComponentAction*) getOwner()->getComponent("ComponentAction"));
                ca->shoot("enemy",dt,1);
            }
        }
    }
    else {
        Vector3 p = getOwner()->getPosition();
        p.y = p.y-1;
        locateObjective(p, dt);
    }
}

bool ComponentControllerPlayer::openJoystick(int num_joystick)
{
	// Initialize the joystick subsystem
	SDL_InitSubSystem(SDL_INIT_JOYSTICK);
    
	// Check for joystick
	if(SDL_NumJoysticks() <= num_joystick)
		return false;
    
	// Open joystick
	joystick = SDL_JoystickOpen(num_joystick);
	if (joystick == NULL)
        return false;
    
	return true;
}


JoystickState ComponentControllerPlayer::getJoystickState()
{
	JoystickState state;
	memset(&state,0,sizeof(JoystickState));
    
	if ( joystick == NULL )
	{
		return state;
	}
    
	state.num_axis = SDL_JoystickNumAxes((::SDL_Joystick*) joystick);
	state.num_buttons = SDL_JoystickNumButtons( (::SDL_Joystick*)joystick);
    
	if (state.num_axis > 8) state.num_axis = 8;
	if (state.num_buttons > 16) state.num_buttons = 16;
    
	for (int i = 0; i < state.num_axis; ++i) //axis
		state.axis[i] = SDL_JoystickGetAxis((::SDL_Joystick*) joystick,i) / 32768.0f; //range -32768 to 32768
	for (int i = 0; i < state.num_buttons; ++i) //buttons
		state.button[i] = SDL_JoystickGetButton((::SDL_Joystick*) joystick,i);
	state.hat = (HATState)(SDL_JoystickGetHat((::SDL_Joystick*) joystick,0) - SDL_HAT_CENTERED); //one hat is enough
    
	return state;
}