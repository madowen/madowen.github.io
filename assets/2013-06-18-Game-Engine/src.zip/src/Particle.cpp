//
//  Particle.cpp
//  JeProject
//
//  Created by Alex Catalán on 26/06/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "Particle.h"
#include "includes.h"
#include <iostream>

Particle::Particle(Vector3 p,Vector3 s){
    position = p;
    speed = s;
    tdv = 0;
    last_time = 0;
}

Vector3 Particle::getPosition(){
    return position;
}
void Particle::setPosition(Vector3 p){
    position = p;
}
Vector3 Particle::getSpeed(){
    return speed;
}
void Particle::setSpeed(Vector3 spd){
    speed = spd;
}
float Particle::getTDV(){
    return tdv;
}
void Particle::update(float dt){
    position = position + speed*dt;
    tdv += dt*100;
}