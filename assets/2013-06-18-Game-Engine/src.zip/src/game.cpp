//
//  game.cpp
//  JeProject
//
//  Created by Alex Catalán on 27/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//
#include "game.h"
#include <iostream>


Game::Game(){
    stage.screen = STAGE_MADLABS;
    last_time=0;
    keystate=NULL;
    lock_mouse=false;
    load = false;
}

Game::~Game(){
}

int Game::createWindow(const char* caption, int width, int height, bool fullscreen)
{
	int bpp = 0;
	int flags;
    
	if( SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		fprintf(stderr, "Video initialization failed: %s\n", SDL_GetError());
		exit(-1);
	}
	SDL_EnableUNICODE(1);
	atexit(SDL_Quit);
    
	flags = SDL_OPENGL | ( fullscreen ? SDL_FULLSCREEN : 0);
	SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);
	SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16); //or 24
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
	SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);
    
	//antialiasing (disable this lines if it goes too slow)
	SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 1);
	SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES, 4 ); //increase to have smoother polygons
    
	const SDL_VideoInfo* info = SDL_GetVideoInfo();
    
	if(!info)
	{
		fprintf(stderr, "Video query failed: %s\n", SDL_GetError());
		return 0;
	}
    
	bpp = info->vfmt->BitsPerPixel;
	if(SDL_SetVideoMode(width, height, bpp, flags) == 0)
	{
		fprintf(stderr, "Video mode set failed: %s\n", SDL_GetError());
		return 0;
	}
    
	SDL_PumpEvents(); //without this line asserts could fail on windows
	SDL_WM_SetCaption(caption,NULL);
	SDL_GetMouseState(&mouse_last_x,&mouse_last_y);
	return bpp;
}
void Game::init(void) {
	//OpenGL flags
	glDisable( GL_CULL_FACE );
	//glEnable( GL_DEPTH_TEST );

    //landscape
    World::Instance()->setLandscape(ResourceFactory::createRender(CIELO_CUBEMAP));
    World::Instance()->getLandscape()->setOwner(World::Instance());

    //player
    World::Instance()->addGameObject("player",ResourceFactory::createPlayer(100,3000,100,X3_INTERCEPTOR,TEAM_BLUE));
    World::Instance()->setActivePlayer("player");
    //cameras
    World::Instance()->addGameObject("camera_1",ResourceFactory::createCamera(CAMERA_FREE,Vector3(150,100,100 ), Vector3(0,0,0), Vector3(0,1,0), 70, WINDOW_WIDTH/(float)WINDOW_HEIGHT, 0.1, 100000));
    World::Instance()->addGameObject("camera_2",ResourceFactory::createCamera(CAMERA_PLAYER,Vector3(0,0,0), Vector3(0,0,0), Vector3(0,0,0), 70, WINDOW_WIDTH/(float)WINDOW_HEIGHT, 0.1, 100000));
    World::Instance()->setActiveCamera("camera_2");
    //terrain
    World::Instance()->addGameObject("terrain_1",ResourceFactory::createStaticObject(0,0,0,ISLAND,0));
    World::Instance()->addGameObject("terrain_2",ResourceFactory::createStaticObject(7000,0,0,ISLAND,0));
    World::Instance()->addGameObject("terrain_3",ResourceFactory::createStaticObject(14000,0,7000,ISLAND,0));
    World::Instance()->addGameObject("terrain_4",ResourceFactory::createStaticObject(0,0,10000,ISLAND,0));
    //objectives
    World::Instance()->addGameObject("objective_1",ResourceFactory::createStaticObject(rand()%14000-7000,rand()%200+200,rand()%14000-7000,SPACE_TANK,TEAM_RED));
    World::Instance()->addGameObject("objective_2",ResourceFactory::createStaticObject(rand()%14000-7000,rand()%200+200,rand()%14000-7000,SPACE_TANK,TEAM_RED));
    World::Instance()->addGameObject("objective_3",ResourceFactory::createStaticObject(rand()%14000-7000,rand()%200+200,rand()%14000-7000,FRIGATE,TEAM_RED));
    World::Instance()->addGameObject("objective_4",ResourceFactory::createStaticObject(rand()%14000-7000,rand()%200+200,rand()%14000-7000,FRIGATE,TEAM_RED));
    //enemy
//    World::Instance()->addGameObject("enemy_fighter_1",ResourceFactory::createIAObect(rand()%7000-7000,rand()%1000+1000,rand()%9000-7000,SPACE_TANK,TEAM_RED));
//    World::Instance()->addGameObject("enemy_fighter_2",ResourceFactory::createIAObect(rand()%14000-7000,rand()%4000+1000,rand()%3000-7000,FRIGATE,TEAM_RED));
//    World::Instance()->addGameObject("enemy_fighter_3",ResourceFactory::createIAObect(rand()%17000-7000,rand()%7000+1000,rand()%14000-7000,SPACE_TANK,TEAM_RED));
//    World::Instance()->addGameObject("enemy_fighter_4",ResourceFactory::createIAObect(rand()%10000-7000,rand()%2000+1000,rand()%13000-7000,FRIGATE,TEAM_RED));
    
    
    ResourceManager::Instance()->update();
    load = true;
    stage.screen = STAGE_CONTROLS;
}
void Game::onKeyPressed( SDL_KeyboardEvent event ){
	switch(event.keysym.sym)
	{
		case SDLK_ESCAPE: exit(0);
        case SDLK_BACKSPACE: World::Instance()->nextCamera();
	}
}
void Game::update(double ft){
    
    
    if (stage.screen == STAGE_GAME) {
        if (!load) {
            init();
        }
        Event *event_update = new Event(EVENT_UPDATE,ft);
        World::Instance()->onEvent(event_update); //update all world's gameObjects
        Bullet::update(ft);
        

        ComponentCamera *cam = (ComponentCamera*) World::Instance()->getActiveCamera()->getComponent("ComponentCamera");
        World::Instance()->getModel()->setIdentity();
        World::Instance()->getModel()->traslateLocal(cam->eye.x, cam->eye.y, cam->eye.z);
        bool gameOver = World::Instance()->update(ft); //update worldObject
        
        if (gameOver) {
            GameOver();
        }

        bulletCollisionCheck();
        gameObjectCollisionCheck();

        delete event_update;
    }else if(stage.screen == STAGE_LOAD && load == false){
        init();
    }else{
        stage.update(ft);
    }
}

void Game::onDraw(void) 
{
    //std::cout << "-----ONDRAW-----" << std::endl;
	//set the clear color (the background color)
	glClearColor(0, 0, 0, 1.0);
    
	// Clear the window and the depth buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    if (stage.screen == STAGE_GAME || stage.screen == STAGE_MISSION_OBJECTIVES) {
        
        //Put the camera matrices on the stack
        Event *camera_set = new Event(EVENT_CAMERA_SET_3D);
        World::Instance()->getActiveCamera()->onEvent(camera_set);
        delete camera_set;
        //camera->set();
        
        //Draw out world
        World::Instance()->getLandscape()->render();

        glEnable(GL_DEPTH_TEST);

        
//        drawGrid(500);
        Event *render = new Event(EVENT_RENDER);
        World::Instance()->onEvent(render);
        Bullet::render();
       
        *render = Event(EVENT_RENDER_PARTICLES);
        World::Instance()->onEvent(render);
        delete render;
            
            
        glDisable(GL_DEPTH_TEST);    
        
        //render HUD
        ComponentCamera camera2D;
        camera2D.setOrthographic(0, 1, 0, 1, -1, 1);
        camera2D.set();
        //((ComponentHUD*)World::Instance()->getActivePlayer()->getComponent("ComponentHUD"))->render();
    }else{
        ComponentCamera camera2D;
        camera2D.setOrthographic(0, 1, 0, 1, -1, 1);
        camera2D.set();
        stage.render();
    }
    //swap between front buffer and back buffer
	SDL_GL_SwapBuffers();
}

void Game::bulletCollisionCheck(){
    std::map<std::string,GameObject*>::iterator itmap;
    for (itmap = World::Instance()->child_list.begin(); itmap != World::Instance()->child_list.end();itmap++){
        ComponentMeshRender* mr = (ComponentMeshRender*)(*itmap).second->getComponent("ComponentMeshRender");
        if(mr != NULL){ //si no tiene MeshRender, significa que no es objeto visible, por lo tanto no le afectan las balas

//            Box box = *mr->getMesh()->getBoundingBox();
            CollisionModel3D *cm = mr->getMesh()->getCollisionModel();
            
            std::list<Bullet*>::iterator itlist;
            for (itlist=Bullet::bulletList.begin();itlist!=Bullet::bulletList.end();itlist++){
                Vector3 p = (*itlist)->getPosition();
                Vector3 pa = (*itlist)->getPositionAnt();
                std::string author = (*itlist)->getAuthor();
                if (author != (*itmap).first){ // && box.intersect(Vector3D(pa.x,pa.y,pa.z),Vector3D(p.x,p.y,p.z))){
                    if (cm->rayCollision(pa.v, p.v, true)){
                        Vector3 point;
                        cm->getCollisionPoint(point.v);
                        Event *collision = new Event(EVENT_BULLET_COLLISION);
                        collision->point = point;
                        collision->bullet = (*itlist);
                        (*itmap).second->onEvent(collision);
//                        delete (*itlist);
                        Bullet::bulletList.remove(*itlist);
                        itlist--;
                    }
                }
            }
        }
    }
}

void Game::gameObjectCollisionCheck(){
    std::map<std::string,GameObject*>::iterator itmap1,itmap2,itmapaux;
    for (itmap1 = World::Instance()->child_list.begin(); itmap1 != World::Instance()->child_list.end();itmap1++){
        itmapaux = itmap1;
        itmapaux++;     //EN EL SEGUNDO BUCLE INICIAMOS DESDE itmap1+1, ES DECIR DESDE LA SIGUIENTE POSICION DEL MAP, ASI EVITAMOS REPETIR COMPROBACIONES O COMPROBAR CONSIGO MISMO
        ComponentMeshRender* mr1 = (ComponentMeshRender*)(*itmap1).second->getComponent("ComponentMeshRender"); // COMPONENTMESHRENDER CONTIENE LA MESH Y LA TEXTURA
        if (mr1 != NULL) {  //PUEDE SER QUE HAYA GAMEOBJECTS SIN MESH

            CollisionModel3D *cm1 = mr1->getMesh()->getCollisionModel(); //LA COLLISIONMODEL
            cm1->setTransform((*itmap1).second->getModel()->m);

            
            for (itmap2 = itmapaux; itmap2 != World::Instance()->child_list.end();itmap2++){
                ComponentMeshRender* mr2 = (ComponentMeshRender*)(*itmap2).second->getComponent("ComponentMeshRender");
                if (mr2 != NULL){

                    CollisionModel3D *cm2 = mr2->getMesh()->getCollisionModel();
                    cm2->setTransform((*itmap2).second->getModel()->m);
                    if ((*itmap1).second->team != 0 || (*itmap2).second != 0)  
                        if (cm2->collision(cm1,-1,0,(*itmap1).second->getModel()->m )) { //COMPROBAMOS SI LAS COLLISIONMODEL COLISIONAN, QUE ESTAN EN LA CLASE MESH, QUE ES LA MISMA PARA TODOS LOS GAMEOBJECT CON LA MISMA MESH
                            if (((*itmap1).first == "player" && (*itmap2).second->team == TEAM_YELLOW ) || ((*itmap2).first == "player" && (*itmap1).second->team == TEAM_YELLOW ) ) {
                                Event *collision = new Event(EVENT_OBJECTIVE_COLLISION);   
                                if ((*itmap1).first == "player") {
                                    collision->key = (*itmap2).first;
                                    World::Instance()->onEvent(collision);
                                }else {
                                    collision->key = (*itmap1).first;
                                    World::Instance()->onEvent(collision);
                                }
                                delete collision;                                   
                            }else{
                                Event *collision = new Event(EVENT_GO_COLLISION);   //
                                collision->go = (*itmap2).second;                   //ENVIAMOS UN EVENTO DE COLISION, CON EL GAMEOBJECT, AL OTRO GAME OBJECT
                                (*itmap1).second->onEvent(collision);               //Y LO RECOGERA EL COMPONENTE ADECUADO PARA BAJAR VIDA, ETC.
                                collision->go = (*itmap1).second;                   //
                                (*itmap2).second->onEvent(collision);               //
                                delete collision;                                   //
                            }
                        }
                }
            }
        }
    }
}

void Game::GameOver(){
    World::Instance()->child_list.clear();
    load = false;
    stage.screen = STAGE_GAME_OVER;
}

