//
//  ComponentAttributes.h
//  JeProject
//
//  Created by Alex Catalán on 09/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_ComponentAttributes_h
#define JeProject_ComponentAttributes_h

#include "Component.h"
#include "ComponentPhysics.h"

class ComponentAttributes: public Component
{
private:

    bool  collide;
    float shoot_per_second;  
    float maxHealth;
    float health;           //health
    float weight;           //weight
public:
    ComponentAttributes(int objectType);

    float   getSPS();
    float   getHealth();
    float   getMaxHealth();
    float   getWeight();
    bool    isColliding();

    void setSPS(float sps);
    void setHealth(float h);
    void setWeight(float w);
    void setCollide(bool c);

    void bulletCollide(Bullet b);
    void gameObjectCollide(GameObject *go);
    void onEvent(Event *event);

    void update(float ft);
    
};
#endif
