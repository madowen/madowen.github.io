// Practica 9 Infografia I by Javi Agenjo. 2008

#include "includes.h"
//#include "ResourceManager.h"
#include "game.h"
#include "framework.h"
//#include "mesh.h"
//#include "ComponentCamera.h"
#include "utils.h"
//#include "GameObject.h"


#include <iostream> //to output

//this would be useful to read it from the app console arguments
#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

Game *game;

//The application main loop
void mainLoop()
{
	SDL_Event sdlEvent;
    float time=0.0;

	while (1)
	{
		//render frame
		game->onDraw();

		//update events
		while(SDL_PollEvent(&sdlEvent))
		{
			switch(sdlEvent.type)
				{
					case SDL_QUIT: return; break; //EVENT for when the user clicks the [x] in the corner
					case SDL_MOUSEBUTTONDOWN: //EXAMPLE OF sync mouse input
						if (sdlEvent.button.button == SDL_BUTTON_MIDDLE)
						{
							game->lock_mouse = !game->lock_mouse;
							SDL_ShowCursor(!game->lock_mouse);
						}
						break;
					case SDL_MOUSEBUTTONUP:
						//...
						break;
					case SDL_KEYDOWN: //EXAMPLE OF sync keyboard input
						game->onKeyPressed( sdlEvent.key );
						break;
				}
		}

		//read keyboard state and stored in keystate
		game->keystate = SDL_GetKeyState(NULL);

		//update logic
		double elapsed_time = (SDL_GetTicks() - game->last_time) * 0.001; //0.001 converts from milliseconds to seconds
		game->last_time = SDL_GetTicks();
        time = time+elapsed_time;
        float fps = 60.0;
        float ft = elapsed_time/fps;
        
        game->update(ft);
	}

	return;
}

int main(int argc, char **argv)
{
    game = new Game();

	if (game->createWindow("My app", WINDOW_WIDTH, WINDOW_HEIGHT) == 0)
		return 0;

	//useful functions
	//SDL_WarpMouse(300, 300); //move the mouse
	//SDL_WM_GrabInput( SDL_GRAB_ON ); //forces to keep the mouse by the app even when you change the focus
	//SDL_ShowCursor(true); //hides and shows the cursor
//	game->onDraw();
//	game->init();
    game->update(0);
	mainLoop();

	//destroy everything and save
	//...
    delete game;

	return 0;
}
