//
//  world.h
//  JeProject
//
//  Created by Alex Catalán on 27/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_world_h
#define JeProject_world_h

#include "ComponentMeshRender.h"
#include "ComponentCamera.h"
#include "GameObject.h"

class World: public GameObject
{
    
protected:
    World();
    World(const World &);
    World &operator= (const World &);
private:
    static World* pinstance;
    static void DestroySingleton();
    std::string activePlayer;
    std::string activeCamera;
    ComponentMeshRender *landScape;
    Vector3 gravity;
    
public:
    std::map<std::string,GameObject*> child_list;

    ~World();
    static World* Instance();
    ComponentMeshRender* getLandscape();
    GameObject* getActivePlayer();
    GameObject* getActiveCamera();
    Vector3 getGravity();
    void setActivePlayer(std::string goName);
    void setActiveCamera(std::string goName);
    void setLandscape(ComponentMeshRender* mr);
    void nextCamera();
    void onEvent(Event *event);
    void addGameObject(std::string name,GameObject *object, GameObject *parent=NULL);
    GameObject* getGameObject(std::string name);
    bool update(float dt);
};

#endif
