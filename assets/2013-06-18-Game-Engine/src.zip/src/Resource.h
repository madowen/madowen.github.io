//
//  Resource.h
//  JeProject
//
//  Created by Alex Catalán on 26/04/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_Resource_h
#define JeProject_Resource_h
#include <iostream>
class Resource
{
public:
    std::string name;
    std::string path;

    Resource(){};
    Resource(std::string n,std::string p):name(n),path(p){};
    ~Resource(){};
    
    virtual bool load(){return false;};
    void setName(std::string n){name=n;};
    void setPath(std::string p){path=p;};
    std::string getName(){return name;};
    std::string getPath(){return path;};

};


#endif
