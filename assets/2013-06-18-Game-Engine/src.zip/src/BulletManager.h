//
//  BulletManager.h
//  JeProject
//
//  Created by Alex Catalán on 29/05/12.
//  Copyright (c) 2012 UPF. All rights reserved.
//

#ifndef JeProject_BulletManager_h
#define JeProject_BulletManager_h
#include "includes.h"
#include "framework.h"
#include <list>
#include <iostream>


class Bullet{
private:
    Vector3 pos;
    Vector3 posAnt;
    Vector3 vel;
    Vector3 color;
    float power;
    int lifetime;
    std::string author;
    
public:
    static std::list<Bullet*> bulletList;
    
    Bullet(int objectType);
    Vector3 getVel();
    Vector3 getPosition();
    Vector3 getPositionAnt();
    std::string getAuthor();
    float getPower();
    void setVel(Vector3 v);
    void setPosition(Vector3 p);
    void setPositionAnt(Vector3 p);
    void setAuthor(std::string a);
    void saveBullet();
    static void update(float ft);
    static void render();
    
};

#endif
