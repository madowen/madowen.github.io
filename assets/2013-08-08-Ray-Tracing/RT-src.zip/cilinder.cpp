#include "cilinder.h"

/*-<==>-----------------------------------------------------------------
/ Constructor
/----------------------------------------------------------------------*/
CCilinder::CCilinder(SCALAR r, SCALAR h):radius(r),height(h){r2=r*r;}

/*-<==>-----------------------------------------------------------------
/ 
/----------------------------------------------------------------------*/
bool CCilinder::hits (const CLine &line, SCALAR &t_hit) {
	VECTOR p0,v;
	std::list <SCALAR> hits;
	p0 = line.loc-loc;
	v = line.dir;
	// y = h // upper cap
	if(true){
		VECTOR norm(0,1,0);
		SCALAR t_hit = ((height+loc.y) - line.loc.dot(norm))/(line.dir.dot(norm));
		//SCALAR tsup = (height+loc.y)/p0.y;
		SCALAR Xint = p0.x + t_hit*v.x;
		SCALAR Zint = p0.z + t_hit*v.z;
		if ((Xint*Xint+Zint*Zint) <= (r2)) 
			hits.push_back(t_hit);
	}
	//-------------------//
	// y = 0 // lower cap
	if(true){
		VECTOR norm(0,-1,0);
		SCALAR t_hit = ((0+loc.y) - line.loc.dot(norm))/(line.dir.dot(norm));
//		SCALAR tinf = (0+loc.y)/p0.y;
		SCALAR Xint = p0.x + t_hit*v.x;
		SCALAR Zint = p0.z + t_hit*v.z;
		if ((Xint*Xint+Zint*Zint) <= (r2)) 
			hits.push_back(t_hit);
	}	
	//-------------------//
	// cilinder
	SCALAR a,b,c,D;
	SCALAR t0,t1;
	a = v.x*v.x+v.z*v.z;
	b = (v.x*p0.x+v.z*p0.z)*2;
	c = p0.x*p0.x+p0.z*p0.z-r2;
	D = b*b - 4*a*c;
	if (D < 0) return false;
	if (D >= 0){
		t0 = (-b + sqrt(D))/(2*a);
		t1 = (-b - sqrt(D))/(2*a);
		SCALAR Yint0 = p0.y + t0*v.y;
		SCALAR Yint1 = p0.y + t1*v.y;
		if (Yint0 > loc.y && Yint0 < loc.y+height) 
			hits.push_back(t0);
		if (Yint1 > loc.y && Yint1 < loc.y+height) 
			hits.push_back(t1);
	}
	 t_hit = -1;
	std::list<SCALAR>::iterator i=hits.begin();
	while (i!=hits.end()){
		SCALAR hit = *i++;
		if ((t_hit > hit || t_hit == -1)&& hit > 0)
			t_hit = hit;
	}
	if (t_hit > 0) return true;
	else return false;
}

VECTOR CCilinder::getNormal(const VECTOR &hit_loc) {
	if (hit_loc.y == loc.y+height) return VECTOR(0,1,0);
	else if (hit_loc.y == loc.y) return VECTOR(0,-1,0);
	else{
		VECTOR N(hit_loc.x-loc.x,0,hit_loc.z-loc.z);
		N.normalize();
		return N;
	}
}

