#include "raytracer.h"

/*-<==>-----------------------------------------------------------------
/ 
/---------------------------------------------------------------------*/
CCamera::CCamera() {
	// Initialize with some default parameters
  setRenderParameters(320, 240, 60.0f);
	setView(VECTOR(0,0,0), VECTOR(0,0,1));
}

CCamera::~CCamera() {
}

/*-<==>-----------------------------------------------------------------
/ Save render parameters for later use
/ fov is in degrees
/---------------------------------------------------------------------*/
void CCamera::setRenderParameters (int axres, int ayres, SCALAR afov_in_deg) {
  // Pendiente de implementar correctamente
  // ...
  // Compute view_d from afov_in_deg
	// ...
	xres = axres;
	yres = ayres;
	fov = afov_in_deg;

	viewd = (yres/2)/tan(fov/2*M_PI/180.0f);
}

/*-<==>-----------------------------------------------------------------
/ Define the axis of the camera (front, up, left) in world coordinates 
/ based on the current values of the vectors target & loc 
/---------------------------------------------------------------------*/
void CCamera::initAxis() {
  // Pendiente de implementar correctamente
	// ...
	front = target-loc;

	VECTOR aux_y(0,1,0);

	left = aux_y.cross(front);

	up = front.cross(left);

	front.normalize();
	left.normalize();
	up.normalize();

}

/*-<==>-----------------------------------------------------------------
/ Save the new camera position and target point
/---------------------------------------------------------------------*/
void CCamera::setView(const VECTOR &src_point, const VECTOR &dst_point) {
  loc = src_point;
  target = dst_point;
  initAxis();
}

/*-<==>-----------------------------------------------------------------
/ return a line which starts on camera position and goes through the pixel
/ (x,y) from the screen
/---------------------------------------------------------------------*/
CLine CCamera::getLineAt (SCALAR x, SCALAR y) const {
  // Pendiente de implementar correctamente
	// ...
	VECTOR v = viewd*front+up*((yres/2)-y-0.5)+left*((xres/2)-x-0.5);
	v.normalize();
	return CLine(loc,v,0);
}

