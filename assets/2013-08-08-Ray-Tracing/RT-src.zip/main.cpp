#include "raytracer.h"
#include "sphere.h"
#include "plane.h"
#include "cilinder.h"
#include "cube.h"
#include <ctime>
#include <iostream>
#include <fstream>
#include <vector>


/*-<==>-----------------------------------------------------------------
/ Defines the scene
/----------------------------------------------------------------------*/
void CRayTracer::load () {

  // Add the camera looking at the origin
  camera.setView (VECTOR(300, 100, 200), VECTOR (0,0,0));
  camera.setRenderParameters (640,480,60);
  background_color = COLOR(0,0,0);
  // Define some materials
  materials["mirror"]  = new CSolidMaterial (COLOR (0, 0, 0),COLOR(0,0,0),COLOR(0,0,0),1,0,0,0);
  materials["cristal"]  = new CSolidMaterial (COLOR (0, 0, 0),COLOR(0,0,0),COLOR(0,0,0),1,1,1,0);
  materials["silver"]  = new CSolidMaterial (COLOR (0.50754,0.50754,0.50754),COLOR (0.508273,0.508273,0.508273),COLOR (0.19225,0.19225,0.19225),0.5,0,0,51.2);
  materials["gold"]  = new CSolidMaterial (COLOR (0.75164,0.60648,0.22648),COLOR (0.628281,0.555802,0.366065),COLOR (0.24725,0.1995,0.0745), 0.6,0,0.2,51.2);
  materials["ruby"]    = new CSolidMaterial (COLOR (0.61424,0.04136,0.04136),COLOR (0.727811,0.626959,0.626959),COLOR (0.1745,0.01175,0.01175), 0.2,1.1,0.2,76.8);
  materials["emerald"]    = new CSolidMaterial (COLOR (0.07568,0.61424,0.07568),COLOR (0.633,0.727811,0.633),COLOR (0.0215,0.1745,0.0215), 0.3,0,0,76.8);
  materials["turquoise"]    = new CSolidMaterial (COLOR (0.396,0.74151,0.69102),COLOR (0.297254,0.30829,0.306678),COLOR (0.1,0.18725,0.1745), 0.3,0,0,12.8);
  materials["pearl"]    = new CSolidMaterial (COLOR (1,0.829,0.829),COLOR (0.296648,0.296648,0.296648),COLOR (0.25,0.20725,0.20725), 0,0,0,11.264);
  materials["black"]    = new CSolidMaterial (COLOR (0.0, 0.0, 0.0),COLOR (0.0, 0.0, 0.0),COLOR (0.0, 0.0, 0.0), 0.8,0,0,20);
  materials["obsidian"]    = new CSolidMaterial (COLOR (0.18275,0.17,0.22525),COLOR (0.332741,0.328634,0.346435),COLOR (0.05375,0.05,0.06625), 0,0,0,38.4);
  materials["obsidian-pearl"] = new CCheckerMaterial ( materials["obsidian"],materials["pearl"],100);
  materials["orange"] = new CSolidMaterial (COLOR(0.8,0,0.3),0);
  // Add a sphere
  CSphere *sph = new CSphere(50);
  sph->setLocation (VECTOR(0,50,120));
  sph->setMaterial (materials["emerald"]);
  //objects.push_back (sph); 

  CSphere *sph2 = new CSphere(50);
  sph2->setLocation (VECTOR(-170,50,-170));
  sph2->setMaterial (materials["gold"]);
  objects.push_back (sph2); 

  CSphere *sph3 = new CSphere(50);
  sph3->setLocation (VECTOR(0,100,0));
  sph3->setMaterial (materials["cristal"]);
  objects.push_back (sph3); 

  CSphere *sph4 = new CSphere(50);
  sph4->setLocation (VECTOR(-240,50,240));
  sph4->setMaterial (materials["mirror"]);
  objects.push_back (sph4); 

  CCilinder *cil = new CCilinder(50,150);
  cil->setLocation (VECTOR(-120,0,0));
  cil->setMaterial (materials["silver"]);
  //objects.push_back (cil); 

  // Add the ground
  CPlane *plane = new CPlane (VECTOR(0,1,0), 0);
  plane->setMaterial (materials["obsidian-pearl"]);
  objects.push_back (plane); 

  // Add a single white light
  CLight *light = new CLight(VECTOR (400,400,400), COLOR (1,1,1));
  CLight *light2 = new CLight(VECTOR (700,200,-700), COLOR (1,1,1));
  lights.push_back (light);
  lights.push_back (light2);

}

bool CRayTracer::loadSnowflake (const char *filename) {
  FILE *f = fopen (filename, "r");
  if (!f)
    return false;

  // Add the camera looking at the origin
  camera.setView (VECTOR(2.1, 1.7, 1.3), VECTOR (0,0,0));
  camera.setRenderParameters (1024,1024,45);

	// Define background color
	background_color = COLOR(0.078,0.361,0.753);
	
  // Add a two material
  materials["txt001"]    = new CSolidMaterial (COLOR (0.8, 0.6, 0.264), 0);
  materials["txt002"]    = new CSolidMaterial (COLOR (0.5, 0.45, 0.35),COLOR (0.5, 0.5, 0.5),COLOR (0, 0, 0), 0.5,0,0,3.0827);

  // Add the ground
  CPlane *plane = new CPlane (VECTOR(0,1,0), -0.5);
  plane->setMaterial (materials["txt001"]);
  objects.push_back (plane); 

	// This is a very simply parser!!
  while (!feof(f)) {
    char buf[512];
    fgets (buf, 511, f);
    if (strncmp (buf, "sphere", 6) == 0) {
      char material[64];
      double x,y,z, rad;
      sscanf (buf, "sphere %s %lf %lf %lf %lf\n", material, &rad, &x,&y,&z);
      CSphere *sph = new CSphere(rad);
      sph->setLocation (VECTOR(x,z,y));
      sph->setMaterial (materials["txt002"]);
      objects.push_back (sph);
    } 
  }

  // Add 3 white lights
  lights.push_back (new CLight(VECTOR ( 4, 2, 3), COLOR (1,1,1)));
  lights.push_back (new CLight(VECTOR ( 1, 4,-4), COLOR (1,1,1)));
  lights.push_back (new CLight(VECTOR (-3, 5, 1), COLOR (1,1,1)));

  fclose (f);
  return true;
}

void CRayTracer::saveStats (const char *filename) {
  std::ofstream f(filename);
  if(f.is_open()){
	  f << "Total lines: " << stats.total_lines << std::endl;
	  f << "Lines from camera: " << stats.camera_lines << std::endl;
	  f << "Lines for shadows: " << stats.shadow_lines << std::endl;
	  f << "Lines for reflections: " << stats.reflection_lines << std::endl;
	  f << "Lines for refractions: " << stats.refraction_lines << std::endl;
	  f << "Intersection tests: " << stats.intersection_tests << std::endl;
	  f << "Positive tests: " << stats.positive_intersection << " - " << (100.0f/stats.intersection_tests)*stats.positive_intersection << "%" << std::endl;
	  f.close();
  }
}

/*-<==>-----------------------------------------------------------------
/ MAIN
/----------------------------------------------------------------------*/
int main(int argc, char **argv) {
  clock_t begin = clock();
  CRayTracer rt;
  //rt.load();
  //rt.render("output.tga");
  rt.loadSnowflake("balls_4.txt");
  rt.render("balls_4.tga");
  rt.saveStats("balls_4_stats.txt");
  //rt.renderWithAntiAliasing("balls_1_AA.tga",2.0f,false);
  clock_t end = clock();
  double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
  std::cout << elapsed_secs << std::endl;
  system("pause");
  return 0;
}

