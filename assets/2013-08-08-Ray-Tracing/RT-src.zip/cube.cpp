#include "cube.h"
#include <algorithm>

using namespace std;

/*-<==>-----------------------------------------------------------------
/ Constructor
/----------------------------------------------------------------------*/
CCube::CCube(VECTOR s):size(s){}
/*-<==>-----------------------------------------------------------------
/ 
/----------------------------------------------------------------------*/
bool CCube::hits (const CLine &line, SCALAR &t_hit) {

	float tNear = -2147000000; // -infinite
    float tFar = 2147000000;   // +infinite
    //compute min and max
    //check x
	VECTOR Min,Max;
    Min.x = min(loc.x-size.x/2, loc.x+size.x/2);
    Min.y = min(loc.y-size.y/2, loc.y+size.y/2);
    Min.z = min(loc.z-size.z/2, loc.z+size.z/2);
    Max.x = max(loc.x-size.x/2, loc.x+size.x/2);
    Max.y = max(loc.y-size.y/2, loc.y+size.y/2);
    Max.z = max(loc.z-size.z/2, loc.z+size.z/2);
    if((line.dir.x == 0) && (line.loc.x < Min.x) && (line.loc.x > Max.x))
        return false; //parallel
    else{
        float t1 = (Min.x - line.loc.x) / line.dir.x;
        float t2 = (Max.x - line.loc.x) / line.dir.x;
        if(t1 > t2)
			swap(t1,t2);
        tNear = max(tNear, t1);
        tFar = min(tFar, t1);
        if((tNear > tFar) || (tFar < 0))
            return false;
    }

    //check y
    if((line.dir.y == 0) && (line.loc.y < Min.y) && (line.loc.y > Max.y))
         return false; //parallel
    else{
        float t1 = (Min.y - line.loc.y) / line.dir.y;
        float t2 = (Max.y - line.loc.y) / line.dir.y;
        if(t1 > t2)
			swap(t1,t2);
        tNear = max(tNear, t1);
        tFar = min(tFar, t1);
        if((tNear > tFar) || (tFar < 0))
            return false;
    }

    //check z
    if((line.dir.z == 0) && (line.loc.z < Min.z) && (line.loc.z > Max.z))
        return false; //parallel
    else{
        float t1 = (Min.z - line.loc.z) / line.dir.z;
        float t2 = (Max.x - line.loc.z) / line.dir.z;
        if(t1 > t2)
			swap(t1,t2);
        tNear = max(tNear, t1);
        tFar = min(tFar, t1);
        if((tNear > tFar) || (tFar < 0))
            return false;

    }
    t_hit = tNear;
    return true;
}

VECTOR CCube::getNormal(const VECTOR &hit_loc) {
	if (hit_loc.x == loc.x+size.x/2)
		return VECTOR(1,0,0);
	if (hit_loc.x == loc.x-size.x/2)
		return VECTOR(-1,0,0);
	if (hit_loc.y == loc.x+size.y/2)
		return VECTOR(0,1,0);
	if (hit_loc.y == loc.x-size.y/2)
		return VECTOR(0,-1,0);
	if (hit_loc.z == loc.x+size.z/2)
		return VECTOR(0,0,1);
	if (hit_loc.z == loc.x-size.z/2)
		return VECTOR(0,0,-1);
}
