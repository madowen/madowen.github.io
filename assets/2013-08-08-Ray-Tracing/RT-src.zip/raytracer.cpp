#include <assert.h>
#include "raytracer.h"
#include "image.h"
#include <ctime>

/*-<==>-----------------------------------------------------------------
/ 
/----------------------------------------------------------------------*/
CRayTracer::CRayTracer() 
: max_recursion_level( 10 )
, background_color( COLOR(0,0,0) )
{ 
	stats.camera_lines=0;
	stats.intersection_tests=0;
	stats.positive_intersection=0;
	stats.reflection_lines=0;
	stats.refraction_lines=0;
	stats.shadow_lines=0;
	stats.total_lines=0;
}

/*-<==>-----------------------------------------------------------------
/ Create an image, and for each pixel in the screen create a line
/ and retrieve which color is seen through this line
/ Save the image to a file
/----------------------------------------------------------------------*/
void CRayTracer::render(const char* out) {
	CBitmap image(camera.getXRes(),camera.getYRes(),24);
	for (int x = 0; x < camera.getXRes(); x++){
		clock_t begin = clock();
		for (int y = 0; y < camera.getYRes(); y++){
			CLine l = camera.getLineAt(x,y);
			stats.total_lines++;
			stats.camera_lines++;
			trace(l);
			if (l.color.x > 1) l.color.x = 1;
			if (l.color.y > 1) l.color.y = 1;
			if (l.color.z > 1) l.color.z = 1;
			image.setPixel(x,y,l.color);
		}
		clock_t end = clock();
		double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
		std::cout << x << " - " << elapsed_secs << std::endl;

	}
	image.saveTGA(out);
}

/*-<==>-----------------------------------------------------------------
/ Create an image with AA Supersampling, and for each pixel 
/ in the screen create N lines and retrieve which color is 
/ seen through this line.
/ Save the image to a file
/----------------------------------------------------------------------*/
void CRayTracer::renderWithAntiAliasing(const char* out,SCALAR N, bool jittering) {
	float Ndiv2 = N/2.0f;
	float Nprod2 = N*2.0f;
	float Idiv2N = 1.0f/(Nprod2);
	float CdivN = 100.0f/N;
	CBitmap image(camera.getXRes(),camera.getYRes(),24);
	for (int x = 0; x < camera.getXRes(); x++){
		clock_t begin = clock();
		for (int y = 0; y < camera.getYRes(); y++){
			std::list<COLOR > colors;
			for (int i = 0; i < N; i++){
				for (int j = 0; j < N; j++){
					SCALAR fx = x+((i-Ndiv2)/N)+(Idiv2N);
					SCALAR fy = y+((j-Ndiv2)/N)+(Idiv2N);
					if (jittering){
						fx+=(fmod(rand(),(CdivN)))-Idiv2N;
						fy+=(fmod(rand(),(CdivN)))-Idiv2N;
					}
					CLine l = camera.getLineAt(fx,fy);
					trace(l);
					if (l.color.x > 1) l.color.x = 1;
					if (l.color.y > 1) l.color.y = 1;
					if (l.color.z > 1) l.color.z = 1;
					colors.push_back(l.color);
				}
			}
			std::list<COLOR >::iterator i = colors.begin();
			COLOR Cf(0,0,0);
			while(i != colors.end()){
				COLOR c = *i++;
				Cf += c;
			}
			Cf /= (N*N);
			image.setPixel(x,y,Cf);
		}
		clock_t end = clock();
		double elapsed_secs = double(end - begin) / CLOCKS_PER_SEC;
		std::cout << x << " - " << elapsed_secs << std::endl;
	}
	image.saveTGA(out);
}

/*-<==>-----------------------------------------------------------------
/ Find which object and at which 't' the line hits and object
/ from the scene.
/ Returns true if the object hits some object
/----------------------------------------------------------------------*/
bool CRayTracer::intersects(CLine &line) {
	stats.intersection_tests++;
	// ...
	SCALAR t_hit =0;
	SCALAR best_hit = 0;
	CRTObject *best_obj = NULL;

	// Example of traversing all the objects registered in the scene
	// Same thing for lights
	LRTObjects::iterator i = objects.begin();
	while( i != objects.end() ) {
		CRTObject *obj = *i++;

		// At this point we can use obj->method...
		if (obj->hits(line,t_hit))
			if (t_hit < best_hit || best_obj == NULL){
				//std::cout << t_hit << std::endl;
				best_hit = t_hit;
				best_obj = obj;
			}

	}

  // Pendiente de implementar correctamente
  // ..
	if (best_obj != NULL){
		line.obj=best_obj;
		line.t = best_hit;
		stats.positive_intersection++;
		return true;
	}

	return false;
}

bool CRayTracer::shadowIntersects(CLine &line) {
	stats.intersection_tests++;
	// ...
	SCALAR t_hit =0;
	SCALAR best_hit = 0;
	CRTObject *best_obj = NULL;

	// Example of traversing all the objects registered in the scene
	// Same thing for lights
	LRTObjects::iterator i = objects.begin();
	while( i != objects.end() ) {
		CRTObject *obj = *i++;

		// At this point we can use obj->method...
		if (obj->hits(line,t_hit)){
			stats.positive_intersection++;
			return true;
		}
	}

	return false;
}


/*-<==>-----------------------------------------------------------------
/ Returns in line.color the color captured by the line.
/----------------------------------------------------------------------*/
void CRayTracer::trace(CLine &line) {
  // Pendiente de implementar correctamente
	if (intersects(line)){
		calculateColorAt(line);
	}else{
		background(line);
	}
}

/*-<==>-----------------------------------------------------------------
/ Default background 
/----------------------------------------------------------------------*/
void CRayTracer::background(CLine &line) {
  line.color = background_color;
}

void CRayTracer::calculateColorAt(CLine &line){
	VECTOR Pi = line.getIntersection();									//Collision point
	VECTOR N = line.obj->getNormal(Pi);									//Normal at Pi
	VECTOR E = -line.dir;												//E = Pi to Camera
	
	CLine LineR = line.getReflected(Pi,N);								//E reflected

	VECTOR Er = LineR.dir;												//E reflected direction
	
	COLOR Ks = line.obj->getMaterial()->getSpecular(Pi);					//Specular Material Color
	COLOR Kd = line.obj->getMaterial()->getDifuse(Pi);						//Difuse Material Color
	COLOR Ka = line.obj->getMaterial()->getAmbient(Pi);						//Ambient Material Color
	SCALAR gloss = line.obj->getMaterial()->getGlossines(Pi);				//Glossines Material
	SCALAR R = line.obj->getMaterial()->getReflectance(Pi);					//Reflectance Material
	SCALAR T = line.obj->getMaterial()->getTransparence(Pi);				//Transparence Material
	SCALAR Rt = line.obj->getMaterial()->getRefractance(Pi);				//Refractance Transmited Material
	SCALAR Ri = 1;															//Refractance Actual Material
	if ( line.inObj )														//if line is inside Object, swap refractance material
		std::swap(Rt,Ri);
	
	SCALAR Ii = 1;															//Light potential

	if (R){
		stats.reflection_lines++;
		stats.total_lines++;
		if (intersects(LineR) && LineR.getLevel() < max_recursion_level)		//Reflection
			calculateColorAt(LineR);											//
		if (!intersects(LineR) && LineR.getLevel() < max_recursion_level)		//Background reflected
				background(LineR);												//
		line.addColor(LineR.color*R);											//
	}

	if (Rt){
		CLine LineT = line.getRefracted(Pi,N,Ri,Rt,E);							//Line Refracted
		stats.refraction_lines++;
		stats.total_lines++;
		if (intersects(LineT) && Rt && LineT.getLevel() < max_recursion_level)	//Refraction
			calculateColorAt(LineT);											//
		line.addColor(LineT.color*T);												//
	}
	

	LLights::iterator i = lights.begin();
	while(i != lights.end()){
		CLight *light = *i++;
		
		VECTOR L = light->getLocation() - Pi;								//L = Pi to Light
		SCALAR d = L.length();
		L.normalize();
		
		CLine l(Pi+L*0.0001,L);
		stats.shadow_lines++;
		stats.total_lines++;

		if (shadowIntersects(l)){										//Shadow
			line.addColor(Ka);											//
		}else{
			//SCALAR att = (light->Kq*d*d+light->Kl*d+light->Kc);
			//SCALAR Aatt = 1/att;										//Light attenuation by distance
			//VECTOR Lr = -L+2*N.dot(E)*N;								//L vector reflected

			COLOR Cl = light->getColor();								//Color Light
		
			SCALAR NdotL = N.dot(L);
				if (NdotL  <= 0) NdotL = 0;
			COLOR diffuse = (NdotL*Kd);//*Aatt

			SCALAR LdotEr = L.dot(Er);
			if (LdotEr <= 0) LdotEr = 0;
			COLOR specular = pow(LdotEr,gloss)*Ks;
			line.addColor((diffuse  + specular).filter(Cl)*Ii);
		}
	}
	//line.color = Ia + sum;
}
