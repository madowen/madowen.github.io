#ifndef INC_LIGHT_H_
#define INC_LIGHT_H_

/*-<==>-----------------------------------------------------------------
/ Basic point light with a single color 
/----------------------------------------------------------------------*/
class CLight {
  VECTOR loc;
  COLOR  color;
public:
  SCALAR Kc,Kl,Kq;
  CLight (const VECTOR &aloc, const VECTOR &acolor) : loc (aloc), color(acolor) {Kc=1; Kl=0; Kq=0; }
  CLight (const VECTOR &aloc, const VECTOR &acolor, SCALAR aKc, SCALAR aKl, SCALAR aKq) : loc (aloc), color(acolor), Kc(aKc), Kl(aKl), Kq(aKq) { }
  COLOR  getColor()    const { return color; }
  VECTOR getLocation() const { return loc;   }
};

#include <list>
typedef std::list<CLight *> LLights;

#endif
