#include <stdio.h>
#include "line.h"

/*-<==>-----------------------------------------------------------------
/ Builds a default empty line
/----------------------------------------------------------------------*/
CLine:: CLine() : loc(0,0,0), dir (1,0,0), color(0,0,0), level(0), t(-1e6), obj(NULL), inObj(false) {
}

/*-<==>-----------------------------------------------------------------
/ Builds a line with specific loc and direction
/----------------------------------------------------------------------*/
CLine::CLine (const VECTOR &nloc, const VECTOR &ndir, int nlevel) : loc (nloc), dir (ndir), color(0,0,0), level (nlevel), t(-1e6), obj(NULL), inObj(false) {
  dir.normalize();
}

/*-<==>-----------------------------------------------------------------
/ 
/----------------------------------------------------------------------*/
CLine CLine::getReflected(const VECTOR &nloc, const VECTOR &normal) {
  // Pendiente de implementar correctamente
	VECTOR E = -dir;
	VECTOR Ep = normal.dot(E)*normal;			//E-parallel
	VECTOR Er = -E+2*Ep;
  return CLine(nloc+Er*0.0001,Er,level+1 );
}

/*-<==>-----------------------------------------------------------------
/ 
/----------------------------------------------------------------------*/
CLine CLine::getRefracted(const VECTOR &nloc, const VECTOR &normal,SCALAR Ri, SCALAR Rt,const VECTOR &E) {
	VECTOR N = normal;
	if (inObj) 
		N = -normal;
	SCALAR n1 = Ri;
	SCALAR n2 = Rt;
	SCALAR n = n1/n2;
	SCALAR c1 = -N.dot(E);
	SCALAR c2 = sqrt(1-n*n*(1-c1*c1));
	VECTOR Rr = (n*E)+(n*c1-c2)*N;
		
	CLine LineT = CLine(nloc+Rr*0.0001,Rr);
	LineT.inObj = !inObj;
	return LineT;

}

/*-<==>-----------------------------------------------------------------
/ 
/----------------------------------------------------------------------*/
VECTOR CLine::getIntersection() const {
  return loc + (dir*t);
}

/*-<==>-----------------------------------------------------------------
/ return current recursion level 
/----------------------------------------------------------------------*/
int CLine::getLevel() const {
  return level;
}

/*-<==>-----------------------------------------------------------------
/ add a color amount to color of this line
/----------------------------------------------------------------------*/
void CLine::addColor(const VECTOR &amount) {
  color += amount;
}

