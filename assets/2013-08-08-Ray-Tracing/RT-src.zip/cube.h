#ifndef INC_CUBE_H_
#define INC_CUBE_H_

#include "raytracer.h"

/*-<==>-----------------------------------------------------------------
/ Cilinder of radius 'radius' and height 'height'
/----------------------------------------------------------------------*/
class CCube :public CRTObject{
	VECTOR size;
	VECTOR bounds[2];
public:
	CCube(VECTOR ss);
	bool hits (const CLine &line, SCALAR &hits);
	VECTOR getNormal (const VECTOR &loc);

};

#endif


