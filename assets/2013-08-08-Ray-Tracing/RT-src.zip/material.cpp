#include "raytracer.h"

/*-<==>-----------------------------------------------------------------
/ Solid Material
/----------------------------------------------------------------------*/
CSolidMaterial::  CSolidMaterial( COLOR diffuse, SCALAR reflectance){
  reflectance_ = reflectance;
  refractance_ = 0;
  ambient_ = diffuse*0.1;
  difuse_ = diffuse;
  specular_ = COLOR(1,1,1);
  transparence_ = 0;
  glossines_ = 50;
}

CSolidMaterial::  CSolidMaterial( COLOR diffuse, COLOR specular, COLOR ambient, SCALAR reflectance, SCALAR refraction, SCALAR transparence, SCALAR glossines){
  reflectance_ = reflectance;
  refractance_ = refraction;
  ambient_ = ambient;
  difuse_ = diffuse;
  specular_ = specular;
  transparence_ = transparence;
  glossines_ = glossines;
}

/*-<==>-----------------------------------------------------------------
/ Reflectance parameters is independent of the position
/----------------------------------------------------------------------*/

SCALAR CSolidMaterial::getReflectance(const VECTOR &loc)  const { 
  return reflectance_; 
}

/*-<==>-----------------------------------------------------------------
/ Checker Material
/----------------------------------------------------------------------*/

CCheckerMaterial::CCheckerMaterial (CMaterial *white, CMaterial *black, SCALAR size) {
	tile_white = white;
	tile_black = black;
	side_size = size;
}

/*-<==>-----------------------------------------------------------------
/ Rreflectance parameters is not independent of the position
/----------------------------------------------------------------------*/
SCALAR CCheckerMaterial::getReflectance(const VECTOR &loc)  const { 
	if (is_white(loc)) return tile_white->getReflectance(loc);
	else return tile_black->getReflectance(loc);
}

bool CCheckerMaterial::is_white(const VECTOR &loc) const{
	SCALAR x = loc.x;
	SCALAR y = loc.y;
	SCALAR z = loc.z;
	if(x < 0) x -= side_size/2;
	if(y < 0) y -= side_size/2;
	if(z < 0) z -= side_size/2;
	if((fabs(fmod(x, side_size)) < side_size/2) && (fabs(fmod(z, side_size)) < side_size/2)){
		return true;
	}
	if((fabs(fmod(x, side_size)) > side_size/2) && (fabs(fmod(z, side_size)) > side_size/2)){
		return true;
	}

	return false;
}