#include "plane.h"

/*-<==>-----------------------------------------------------------------
/ n.x * x + n.y * y + n.z * z = d
/----------------------------------------------------------------------*/
CPlane::CPlane (const VECTOR &normal, SCALAR distance) : norm(normal), dist(distance) {
  // ..

}

bool CPlane::hits (const CLine &line, SCALAR &t_hit) {
  // Pendiente de implementar correctamente
	t_hit = (dist - line.loc.dot(norm))/(line.dir.dot(norm));
	if (t_hit <= 0) return false;
	else return true;
	
}

VECTOR CPlane::getNormal (const VECTOR &loc) {
  // Pendiente de implementar correctamente
	return norm;
}

