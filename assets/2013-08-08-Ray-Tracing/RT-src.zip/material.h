#ifndef INC_MATERIAL_H_
#define INC_MATERIAL_H_

#pragma warning (disable : 4786 )

/*-<==>-----------------------------------------------------------------
/ Generic Material definition
/ Some materials will not use the position to define the diffuse or 
/ reflectance values
/----------------------------------------------------------------------*/
class CMaterial {
public:
  CMaterial() {}
  virtual ~CMaterial() {}
  virtual SCALAR getReflectance(const VECTOR &loc) const = 0;

  virtual COLOR getAmbient(const VECTOR &loc) const = 0;
  virtual COLOR getDifuse(const VECTOR &loc) const = 0;
  virtual COLOR getSpecular(const VECTOR &loc) const = 0;
  virtual SCALAR getRefractance(const VECTOR &loc) const = 0;
  virtual SCALAR getTransparence(const VECTOR &loc) const = 0;
  virtual SCALAR getGlossines(const VECTOR &loc) const = 0;
};

/*-<==>-----------------------------------------------------------------
/ A map, key is a std::string and the value is a material pointer
/----------------------------------------------------------------------*/
#include <map>
#include <string>
typedef std::map<std::string, CMaterial *> MMaterials;

/*-<==>-----------------------------------------------------------------
/ Solid color material
/----------------------------------------------------------------------*/
class CSolidMaterial : public CMaterial {
  SCALAR reflectance_;
  COLOR ambient_,difuse_,specular_;
  SCALAR refractance_;
  SCALAR transparence_;
  SCALAR glossines_;

public:
  CSolidMaterial( COLOR diffuse, SCALAR reflectance);
  CSolidMaterial( COLOR diffuse, COLOR specular, COLOR ambient, SCALAR reflectance, SCALAR refraction, SCALAR transparence, SCALAR glossines);
  SCALAR getReflectance(const VECTOR &loc)  const;

  COLOR getAmbient(const VECTOR &loc)const{return ambient_;}
  COLOR getDifuse(const VECTOR &loc)const{return difuse_;}
  COLOR getSpecular(const VECTOR &loc)const{return specular_;}
  SCALAR getRefractance(const VECTOR &loc)const{return refractance_;}
  SCALAR getTransparence(const VECTOR &loc)const{return transparence_;}
  SCALAR getGlossines(const VECTOR &loc)const{return glossines_;}

};

/*-<==>-----------------------------------------------------------------
/ Checker material
/----------------------------------------------------------------------*/
class CCheckerMaterial : public CMaterial {
   CMaterial *tile_white;
   CMaterial *tile_black;
   SCALAR     side_size;
   bool is_white(const VECTOR &loc) const;
 public:
   CCheckerMaterial (CMaterial *white, CMaterial *black, SCALAR size);
   SCALAR getReflectance(const VECTOR &loc) const;
  
   COLOR getAmbient(const VECTOR &loc)const{if (is_white(loc)) return tile_white->getAmbient(loc); else return tile_black->getAmbient(loc);}
   COLOR getDifuse(const VECTOR &loc)const{if (is_white(loc)) return tile_white->getDifuse(loc); else return tile_black->getDifuse(loc);}
   COLOR getSpecular(const VECTOR &loc)const{if (is_white(loc)) return tile_white->getSpecular(loc); else return tile_black->getSpecular(loc);}
   SCALAR getRefractance(const VECTOR &loc)const{if (is_white(loc)) return tile_white->getRefractance(loc); else return tile_black->getRefractance(loc);}
   SCALAR getTransparence(const VECTOR &loc)const{if (is_white(loc)) return tile_white->getTransparence(loc); else return tile_black->getTransparence(loc);}
   SCALAR getGlossines(const VECTOR &loc)const{if (is_white(loc)) return tile_white->getGlossines(loc); else return tile_black->getGlossines(loc);}

 };
#endif
