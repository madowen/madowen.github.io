#ifndef INC_CILINDER_H_
#define INC_CILINDER_H_

#include "raytracer.h"

/*-<==>-----------------------------------------------------------------
/ Cilinder of radius 'radius' and height 'height'
/----------------------------------------------------------------------*/
class CCilinder :public CRTObject{
	SCALAR radius;
	SCALAR r2;
	SCALAR height;
public:
	CCilinder(SCALAR r, SCALAR h);
	bool hits (const CLine &line, SCALAR &hits);
	VECTOR getNormal (const VECTOR &loc);

};

#endif


