#include "sphere.h"

/*-<==>-----------------------------------------------------------------
/ Constructor
/----------------------------------------------------------------------*/
CSphere::CSphere(SCALAR a_radius) 
: radius( a_radius ) {r2=a_radius*a_radius;}

/*-<==>-----------------------------------------------------------------
/ 
/----------------------------------------------------------------------*/
bool CSphere::hits (const CLine &line, SCALAR &t_hit) {
  // Pendiente de implementar correctamente
	VECTOR p0,v;
	//SCALAR a;
	SCALAR b,bp,c,D;
	p0 = line.loc-loc;	//esfera centarda en loc?????
	//p0 = line.loc;			//esfera centrada en origen
	v = line.dir;
	//a = 1;
	bp = p0.dot(v);
	b = 2*bp;
	c = p0.dot(p0) - (r2);
	D = b*b - 4*c; //b*b - 4*a*C

	//std::cout << D << std::endl;
	if (D < 0) return false;
	if (D == 0){
		t_hit = (-b)/(2);//-b/2*a
		return true;
	}
	if (D > 0){
		SCALAR t0,t1;
		t0 = (-b + sqrt(D))/(2);//-b+sqrt(D)/2*a
		t1 = (-b - sqrt(D))/(2);//-b-sqrt(D)/2*a
		if (t0 < t1 && t0 > 0) t_hit = t0;
		else if (t1 < t0 && t1 > 0) t_hit = t1;
		else return false;
		return true;
	}
  return false;
}

VECTOR CSphere::getNormal(const VECTOR &hit_loc) {
  // Pendiente de implementar correctamente
	VECTOR N;
	N = hit_loc - loc;
	N.normalize();
  return N;
}

