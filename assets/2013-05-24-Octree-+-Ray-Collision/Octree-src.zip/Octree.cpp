#include "Octree.h"
#include "ase.h"
//#include "matrix4x4f.h"
#include <iostream>
#include <sstream>

#ifdef _WIN32
#include <windows.h>
#endif
#include <GL/gl.h>

Octree::Octree(){
	triangle_selected=-1;
	depth=0;
	father=NULL;
	children.resize(2);
	for (unsigned int i=0;i<children.size();i++){
		children[i].resize(2);
		for(unsigned int j=0;j<children[i].size();j++){
			children[i][j].resize(2);
		}
	}
}

Octree::Octree(vector<vector3f> v){
	vertex = v;
	calculateBounding();
}
Octree::~Octree(){}

void Octree::calculateBounding(){
	bool first=true;
	vector3f max;
	vector3f min;
	vector<vector3f>::iterator vit;
	for(vit=vertex.begin();vit!=vertex.end();vit++){
		if (first){
			max = *vit;
			min = *vit;
			first = false;
		}else{
			if(max.x < vit->x) max.x = vit->x;
			if(max.y < vit->y) max.y = vit->y;
			if(max.z < vit->z) max.z = vit->z;
			if(min.x > vit->x) min.x = vit->x;
			if(min.y > vit->y) min.y = vit->y;
			if(min.z > vit->z) min.z = vit->z;
		}
	}
	center = vector3f((max.x - min.x)/2+min.x,(max.y - min.y)/2+min.y,(max.z - min.z)/2+min.z);
	vert000 = min;
	vert111 = max;

}

vector3f Octree::getVert000(){
	return vert000;
}
vector3f Octree::getVert111(){
	return vert111;
}
vector3f Octree::getCenter(){
	return center;
}
int Octree::getDepth(){
	return depth;
}

void Octree::setVert000(vector3f v000){
	vert000 = v000;
}
void Octree::setVert111(vector3f v111){
	vert111 = v111;
}
void Octree::setCenter(vector3f c){
	center = c;
}
void Octree::setDepth(int d){
	depth = d;
}

void Octree::addTrin(triangle t){
	triangles.push_back(t);
}

void Octree::setTrin(vector<triangle> t){
	triangles = t;
}

void Octree::addVert(vector3f v){
	vertex.push_back(v);
}
vector<vector3f> Octree::getVert(){
	return vertex;
}
void Octree::setVert(vector<vector3f> v){
	vertex = v;
	calculateBounding();
}
	
vector<vector<vector<Octree*>>> Octree::getChild(){
	return children;
}
void Octree::makeChildren(){
	if (depth < MAX_DEPTH){
		for (int i=0; i<=1;i++){
			for (int j=0; j<=1;j++){
				for (int k=0; k<=1;k++){
					Octree *oct = new Octree();
					oct -> setVert000(vector3f(vert000.x+((vert111.x-vert000.x)/2)*i, vert000.y+((vert111.y-vert000.y)/2)*j, vert000.z+((vert111.z-vert000.z)/2)*k));
					oct -> setVert111(vector3f(vert000.x+((vert111.x-vert000.x)/2)+(((vert111.x-vert000.x)/2)*i),(vert000.y+((vert111.y-vert000.y)/2)+(((vert111.y-vert000.y)/2)*j)), (vert000.z+((vert111.z-vert000.z)/2)+(((vert111.z-vert000.z)/2)*k))));
					oct -> setCenter(vector3f(vert000.x+((vert111.x-vert000.x)/2)/2+(((vert111.x-vert000.x)/2)*i),(vert000.y+((vert111.y-vert000.y)/2)/2+(((vert111.y-vert000.y)/2)*j)), (vert000.z+((vert111.z-vert000.z)/2)/2+(((vert111.z-vert000.z)/2)*k))));
					oct->setDepth(depth+1);
					oct->father = this;
					children[k][j][i] = oct;
				}
			}
		}
		for (int i=0; i<=1;i++){
			for (int j=0; j<=1;j++){
				for (int k=0; k<=1;k++){
					for(unsigned int l = 0; l < triangles.size();l++){
						if( children[k][j][i]->vertIn(vertex[triangles[l].a]) || 
							children[k][j][i]->vertIn(vertex[triangles[l].b]) || 
							children[k][j][i]->vertIn(vertex[triangles[l].c]))
						{
							children[k][j][i]->addVert(vertex[triangles[l].a]);
							children[k][j][i]->addVert(vertex[triangles[l].b]);
							children[k][j][i]->addVert(vertex[triangles[l].c]);
							triangle t;
							t.a = children[k][j][i]->sizeVertex()-3;
							t.b = children[k][j][i]->sizeVertex()-2;
							t.c = children[k][j][i]->sizeVertex()-1;
							children[k][j][i]->addTrin(t);
						}
					}
				
					if (children[k][j][i]->hasVertex())
						children[k][j][i]->makeChildren();
				}
			}
		}
		vertex.clear();
		triangles.clear();
	}
}
string tabInfo(int depth){
	string out="";
	for (int i = 0; i < depth; i++)
		out+="\t";
	return out;
	
}
string Octree::printInfo(){
	stringstream ss;
	ss << tabInfo(depth);
	ss << "Depth: " << depth << endl;
	ss << tabInfo(depth);
	ss << "Center:" << endl;
	ss << tabInfo(depth);
	ss << "(" << center.x << "," << center.y << "," << center.z << ")" << endl;
	ss << tabInfo(depth);
	ss << "Vert000:" << endl;
	ss << tabInfo(depth);
	ss << "(" << vert000.x << "," << vert000.y << "," << vert000.z << ")" << endl;
	ss << tabInfo(depth);
	ss << "Vert111:" << endl;
	ss << tabInfo(depth);
	ss << "(" << vert111.x << "," << vert111.y << "," << vert111.z << ")" << endl;
	ss << tabInfo(depth);
	ss << "Triangles: " << endl;
	for (unsigned int i = 0; i<triangles.size();i++){
		ss << tabInfo(depth);
		ss << "\t " << triangles[i].a << " " << triangles[i].b << " " << triangles[i].c << endl;
	}
	ss << tabInfo(depth);
	ss << "Vertex: " << endl;
	for (unsigned int i = 0; i<vertex.size();i++){
		ss << tabInfo(depth);
		ss << "\t (" << vertex[i].x << "," << vertex[i].y << "," << vertex[i].z << ")" << endl;
	}
	ss << tabInfo(depth);
	ss << "Children: " << endl;
	for (int i=0; i<=1;i++){
		for (int j=0; j<=1;j++){
			for (int k=0; k<=1;k++){
				if (children[k][j][i] != NULL){
					ss << tabInfo(depth);
					ss << "Child " << k << j << i << endl;
					ss << children[k][j][i]->printInfo();
				}
			}
		}
	}
	ss << endl;
	return ss.str();
}
void Octree::optimizeChildren(){
		cout << "optimize" << endl;

	//std::vector<Octree*>::iterator sit;
	//for (sit = children.begin(); sit!=children.end(); ){
	//	if (!(*sit)->hasVertex()){
	//		if (!(*sit)->hasChildren()){
	//			sit = children.erase(sit);
	//		}else{
	//			(*sit)->optimizeChildren();
	//			sit++;
	//		}
	//	}else sit++;
	//}
	//	

}
bool Octree::vertIn(vector3f v){

	bool x1;
	bool y1;
	bool z1;
	float x = vert000.x - vert111.x;
	if (x > 0.0){ 
		if ((v.x <= vert000.x) && (v.x >= vert111.x)){
			x1 = true;
		} else{
			return false;
		}
	} else {
		if ((v.x >= vert000.x) && (v.x <= vert111.x)){
			x1 = true;
		} else {
			return false;
		}
	}
	float y = vert000.y - vert111.y;

	if (y > 0.0){ 
		if ((v.y <= vert000.y) && (v.y >= vert111.y)){
			y1 = true;
		} else{
			return false;
		}

	} else {
		if ((v.y >= vert000.y) && (v.y <= vert111.y)){
			y1 = true;
		}
		else{
			return false;
		}
	}
	float z = vert000.z - vert111.z;
	if (z > 0.0){ 
		if ((v.z <= vert000.z) && (v.z >= vert111.z)){
			z1 = true;
		} else{
			return false;
		}
	} else {
		if ((v.z >= vert000.z) && (v.z <= vert111.z)){
			z1 = true;
		} else{
			return false;
		}
	}
	if ((x1 == true) && (y1 == true) && (z1 == true)){
		return true;
	}
	return false;
}
bool Octree::hasChildren(){
	cout << "Deprecated function" << endl;
	//if (sizeChildren() != 0) return true;
	//else return false;
	return true;
}
bool Octree::hasVertex(){
//	cout << "Deprecated function" << endl;
	if (sizeVertex() != 0) return true;
	else return false;
	return true;
}
int Octree::sizeChildren(){
	cout << "Deprecated function" << endl;
//	return children.size();
	return true;
}
int Octree::sizeVertex(){
	return vertex.size();
}

void Octree::renderChildBounding() const{
	renderBoundingBox();
	for (int i=0; i<=1;i++){
		for (int j=0; j<=1;j++){
			for (int k=0; k<=1;k++){
				if (children[k][j][i] != NULL){
					children[k][j][i]->renderChildBounding();
				}
			}
		}
	}
}
void Octree::renderChildTriangles() const{
	renderTriangles();
	for (int i=0; i<=1;i++){
		for (int j=0; j<=1;j++){
			for (int k=0; k<=1;k++){
				if (children[k][j][i] != NULL){
					children[k][j][i]->renderChildTriangles();
				}
			}
		}
	}
}

void Octree::renderTriangles() const{
	
	glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
	
	glBegin(GL_TRIANGLES);
	unsigned int i;
	for (i=0;i<triangles.size();i++)
	{
		const triangle & t = triangles[i];

		if(triangle_selected == i)
			glColor3f(1,0,0);
		else
		    glColor3f(1.0f,1.0f,0.0f);

		glVertex3fv(vertex[t.a]);
		glVertex3fv(vertex[t.b]);
		glVertex3fv(vertex[t.c]);
	}
	glEnd();
	glColor3f(1,1,1);

}
void Octree::renderBoundingBox() const
{
    glColor3f(0, 0, 1);

    glBegin(GL_LINES);

    glVertex3f(vert111.x,vert111.y,vert111.z);     //+++
    glVertex3f(vert111.x,vert111.y,vert000.z);     //++-
    
    glVertex3f(vert111.x,vert111.y,vert111.z);     //+++
    glVertex3f(vert000.x,vert111.y,vert111.z);	   //-++
    
    glVertex3f(vert111.x,vert111.y,vert111.z);     //+++
    glVertex3f(vert111.x,vert000.y,vert111.z);     //+-+
    
    glVertex3f(vert111.x,vert111.y,vert000.z);     //++-
    glVertex3f(vert000.x,vert111.y,vert000.z);     //-+-
    
    glVertex3f(vert111.x,vert111.y,vert000.z);     //++-
    glVertex3f(vert111.x,vert000.y,vert000.z);     //+--
    
    glVertex3f(vert111.x,vert000.y,vert111.z);     //+-+
    glVertex3f(vert000.x,vert000.y,vert111.z);     //--+
    
    glVertex3f(vert000.x,vert000.y,vert111.z);     //--+
     glVertex3f(vert000.x,vert111.y,vert111.z);	   //-++
    
    glVertex3f(vert000.x,vert000.y,vert111.z);     //--+
    glVertex3f(vert000.x,vert000.y,vert000.z);     //---

    glVertex3f(vert000.x,vert000.y,vert000.z);     //---
    glVertex3f(vert111.x,vert000.y,vert000.z);     //+--
    
    glVertex3f(vert000.x,vert000.y,vert000.z);     //---
    glVertex3f(vert000.x,vert111.y,vert000.z);     //-+-
    
    glVertex3f(vert000.x,vert111.y,vert000.z);     //-+-
     glVertex3f(vert000.x,vert111.y,vert111.z);	   //-++
    
    glVertex3f(vert111.x,vert000.y,vert000.z);     //+--
    glVertex3f(vert111.x,vert000.y,vert111.z);     //+-+
    
    glEnd();
    glColor3f(1,1,1);
}

void Octree::checkOctree(vector3f initial_point, vector3f director){
	triangle_selected = -1;
	if (checkBoxIntersection(initial_point,director)){
		for (int i=0; i<=1;i++){
			for (int j=0; j<=1;j++){
				for (int k=0; k<=1;k++){
					if (children[k][j][i] != NULL){
						children[k][j][i]->checkOctree(initial_point,director);
					}else{
						checkTriangles(initial_point, director);
					}
				}
			}
		}
	}
}

bool Octree::checkBoxIntersection(vector3f initial_point, vector3f director){

	double tx0,tx1,ty0,ty1,tz0,tz1;

	tx0 = (initial_point.x-vert000.x)/director.x;
	tx1 = (initial_point.x-vert111.x)/director.x;

	ty0 = (initial_point.y-vert000.y)/director.y;
	ty1 = (initial_point.y-vert111.y)/director.y;

	tz0 = (initial_point.z-vert000.z)/director.z;
	tz1 = (initial_point.z-vert111.z)/director.z;


	if(min(tx1,min(ty1,tz1)) < max(tx0,max(ty0,tz0))){
		return true;
	}
	return false;
}

void Octree::checkTriangles(vector3f initial_point, vector3f director){
	for(unsigned int i=0; i < triangles.size(); i++){
		if (checkTriangleIntersection(&triangles[i],initial_point,director))
			triangle_selected = i;
	}
}

bool Octree::checkTriangleIntersection(triangle *t,vector3f initial_point, vector3f director){//*3-1

	vector3f e1,e2,h,s,q;
	float a,f,u,v;

	std::vector<vector3f> vex = getVert();

	vector3f v1 = vex[t->a];
	vector3f v2 = vex[t->b];
	vector3f v3 = vex[t->c];

	e1 = vector3f(v2.x-v1.x,v2.y-v1.y,v2.z-v1.z);
	e2 = vector3f(v3.x-v1.x,v3.y-v1.y,v3.z-v1.z);

	h = crossProduct(director,e2);
	a = dotProduct(e1,h);

	if (a > -0.00001 && a < 0.00001){
		return false;
	}

	f = 1/a;

	s = vector3f(initial_point.x-v1.x, initial_point.y-v1.y, initial_point.z-v1.z);

	u = f * (dotProduct(s,h));

	if (u < 0.0 || u > 1.0){
		return false;
	}

	q= crossProduct(s,e1);
	v = f * dotProduct(director,q);


	if (v < 0.0 || u + v > 1.0){
		return false;
	}

	float tt = f * dotProduct(e2,q);

	if (tt > 0.00001){ 
		return true;
	}else{ 
		return false;
	}
}