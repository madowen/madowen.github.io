#include <iostream>
#include <string>

// global includes
#include <GL/glut.h>

// local includes
#include "ase.h"
#include "vector3f.h"
#include "matrix4x4f.h"

// global libs
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glut32.lib")

// global variables
vector3f g_vEye(0,1,-5);
vector3f g_vLook(0,0,1);
vector3f g_vRight(-1,0,0);
vector3f g_vUp(0,1,0);
int g_buttons[3];
int g_mouse_x,g_mouse_y;
int g_width, g_height;

// raypicking variables
vector3f position;
vector3f view; //view = g_vLook - g_vEye
int viewportWidth(576);
int viewportHeigth(1024);
int screenX;	//mouse position on screen X
int screenY;	//mouse position on screen Y
vector3f screenHorizontal;
vector3f screenVertical;
vector3f lookAt;

bool childBounding = false;
bool childTriangles = true;
bool octreeSelect = true;
bool allTriangles = true;
bool mouseClicked = false;

double objx = 0, objy=0, objz=0;

//ray
vector3f ini_line;
vector3f director;
int t = 1000;

// the mesh model
CASEModel g_model;

// local defines
#define LEFTMOUSE 0
#define MIDDLEMOUSE 1
#define RIGHTMOUSE 2

//2k8

void drawString(int x, int y, const char* string)
{
	int i, len;
	glRasterPos2f(x, y);
	glColor3f(1,1,1);
	len = strlen (string);
	for (i=0;i<len;i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10,string[i]);
	}
}

void help()
{
	glDisable(GL_LIGHTING);
	// prepare 2d viewport
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0,1000,0,1000);

	drawString(650,10,"Press UP/DOWN/LEFT/RIGHT to navigate");
	drawString(650,40,"Press LEFT BUTTON to perform looking");
	drawString(650,70,"Press O to show/hide the Octree's BoundingBox and Triangles");
	drawString(650,100,"Press A to show/hide the Mesh's Triangles (white)");
	drawString(650,130,"Press T to show/hide the Octree's Triangles (yellow)");
	drawString(650,160,"Press B to show/hide the Octree's Children (blue)");
	drawString(650,190,"Press H to select the main Octree");
	drawString(650,220,"Press BackSpace to select Octree's Father");
	drawString(650,250,"Press 0..7 to select the Octree's N Children");
}


void renderRay(){
		glBegin(GL_LINES);
	{
		glColor3f(1,0,0);
		glVertex3f(ini_line.x,ini_line.y,ini_line.z);
		glVertex3f(ini_line.x+t*director.x,ini_line.y+t*director.y,ini_line.z+t*director.z);
		//cout << objx << "," << objy << "," << objz << endl;
		//glPushMatrix();
		//glutSolidCube( 1 );
		//glTranslatef( g_vEye.x, g_vEye.y, g_vEye.z );
		//glPopMatrix();
		glColor3f(1,1,1);
	}
	glEnd();
}

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);
	//glEnable(GL_LIGHTING);
	//glEnable(GL_LIGHT0);
	//glShadeModel(GL_FLAT);

	// setup camera
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity ();
	gluPerspective(60,1.33,1,200);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
 
	matrix4x4f view;
  view.identity();

  g_vLook.normalize();

  g_vRight = crossProduct(g_vLook, g_vUp);
  g_vRight.normalize();

  g_vUp = crossProduct(g_vRight, g_vLook);
  g_vUp.normalize();

  view.m[0] =  g_vRight.x;
  view.m[1] =  g_vUp.x;
  view.m[2] = -g_vLook.x;
  view.m[3] =  0.0f;

  view.m[4] =  g_vRight.y;
  view.m[5] =  g_vUp.y;
  view.m[6] = -g_vLook.y;
  view.m[7] =  0.0f;

  view.m[8]  =  g_vRight.z;
  view.m[9]  =  g_vUp.z;
  view.m[10] = -g_vLook.z;
  view.m[11] =  0.0f;

  view.m[12] = -dotProduct(g_vRight, g_vEye);
  view.m[13] = -dotProduct(g_vUp, g_vEye);
  view.m[14] =  dotProduct(g_vLook, g_vEye);
  view.m[15] =  1.0f;

  glMultMatrixf( view.m );
	//render here

	//draw two triangles centered at 0,0,0
 // glutSolidSphere(1,20,20);
	glBegin(GL_LINES);
	for (int i=0;i<10;i++){
		glVertex3f(-3,0,-3);
		glVertex3f(3,0,-3);

		glVertex3f(-3,0,3);
		glVertex3f(3,0,3);

		glVertex3f(-3,0,-3);
		glVertex3f(-3,0,3);

		glVertex3f(3,0,-3);
		glVertex3f(3,0,3);

		glVertex3f(3,0,-3);
		glVertex3f(-3,0,3);
	}
	glEnd();

	// draw 3d model
	if (octreeSelect)
		g_model.render(childBounding,childTriangles);
	if (allTriangles)
		g_model.render();
	if (mouseClicked) renderRay();
	// ...
	//glutWireCube(1);
	// dibuixar un cub on cada banda t� 1 de llarg
	//glDisable(GL_LIGHTING);
	//help();
	

	glFlush();
	glutSwapBuffers();
}

void reshape(int w, int h)
{
	g_width = w;
	g_height = h;
	glMatrixMode (GL_MODELVIEW);
	glViewport (0, 0, w, h);
}

void parsekey(unsigned char key, int x, int y)
{
	int a = key;
	switch (key)
	{
		case 32: //space
			break;
		case 'A':
		case 'a':
			allTriangles = !allTriangles;
			break;
		case 'O':
		case 'o':
			octreeSelect = !octreeSelect;
			break;
		case 'T':
		case 't':
			childTriangles = !childTriangles;
			break;
		case 'b':
		case 'B':
			childBounding = !childBounding;
			break;
		case 'h':
		case 'H':
			g_model.oct_render = g_model.oct;
			break;
		case 8: //backspace
			if (g_model.oct_render.father != NULL)
				g_model.oct_render = *g_model.oct_render.father;
			break;
		case '0':
			if (g_model.oct_render.children[0][0][0] != NULL)
				g_model.oct_render = *g_model.oct_render.children[0][0][0];
			break;
		case '1':  //int 49
			if (g_model.oct_render.children[0][0][1] != NULL)
				g_model.oct_render = *g_model.oct_render.children[0][0][1];
			break;
		case '2': 
			if (g_model.oct_render.children[0][1][0] != NULL)
			g_model.oct_render = *g_model.oct_render.children[0][1][0];
			break;
		case '3': 
			if (g_model.oct_render.children[0][1][1] != NULL)
				g_model.oct_render = *g_model.oct_render.children[0][1][1];
			break;
		case '4': 
			if (g_model.oct_render.children[1][0][0] != NULL)
				g_model.oct_render = *g_model.oct_render.children[1][0][0];
			break;
		case '5': 
			if (g_model.oct_render.children[1][0][1] != NULL)
				g_model.oct_render = *g_model.oct_render.children[1][0][1];
			break;
		case '6': 
			if (g_model.oct_render.children[1][1][0] != NULL)
				g_model.oct_render = *g_model.oct_render.children[1][1][0];
			break;
		case '7': 
			if (g_model.oct_render.children[1][1][1] != NULL)
				g_model.oct_render = *g_model.oct_render.children[1][1][1];
			break;
		case 27: exit(0); break;
		case 13: break;
	}
}

void parsekey_special(int key, int x, int y)
{
	switch (key)
	{
		case GLUT_KEY_UP:
			g_vEye += (g_vLook)*0.05f;
			break;
		case GLUT_KEY_DOWN:
			g_vEye -= (g_vLook)*0.05f;
			break;
		case GLUT_KEY_RIGHT:
			g_vEye += (g_vRight)*0.05f;
			break;
		case GLUT_KEY_LEFT:	
			g_vEye -= (g_vRight)*0.05f;
			break;
		
	}
}

void idle()
{
	display();
}

void motion(int x, int y)
{
	int dx = x - g_mouse_x;
	int dy = y - g_mouse_y;

	if (g_buttons[LEFTMOUSE] == 1)
	{
		matrix4x4f matRotation;
		if( dy != 0 )
		{
				matRotation.rotate( -(float)dy / 3.0f, g_vRight );
				matRotation.transformVector( &g_vLook );
				matRotation.transformVector( &g_vUp );
		}

		if( dx != 0 )
		{
				matRotation.rotate( -(float)dx / 3.0f, vector3f(0.0f, 1.0f, 0.0f) );
				matRotation.transformVector( &g_vLook );
				matRotation.transformVector( &g_vUp );
		}

	}

	g_mouse_x = x;
	g_mouse_y = y;
}

void getMouse3DCoords(int x, int y){
double modelview[16], projection[16];
	int viewport[4];
	float z = 1;
	
	/*Read the projection, modelview and viewport matrices
	using the glGet functions.*/
	glGetDoublev( GL_PROJECTION_MATRIX, projection );
	glGetDoublev( GL_MODELVIEW_MATRIX, modelview );
	glGetIntegerv( GL_VIEWPORT, viewport );

	//Read the window z value from the z-buffer	
	glReadPixels( x, viewport[3]-y, 1, 1, GL_DEPTH_COMPONENT, GL_FLOAT, &z );	

	//Use the gluUnProject to get the world co-ordinates of
	//the point the user clicked and save in objx, objy, objz.
	gluUnProject( x, viewport[3]-y, z, modelview, projection, viewport, &objx, &objy, &objz );

}

void mouse(int button, int state, int x, int y)
{
    g_mouse_x = x;
    g_mouse_y = y;
    switch (button) {
    case GLUT_LEFT_BUTTON:
        g_buttons[LEFTMOUSE] = (state == GLUT_DOWN);
        break;
    case GLUT_MIDDLE_BUTTON:
        g_buttons[MIDDLEMOUSE] = (state == GLUT_DOWN);
        break;
    case GLUT_RIGHT_BUTTON:
		if(state){
			getMouse3DCoords(x,y);
			ini_line = vector3f(g_vEye.x,g_vEye.y,g_vEye.z);
			director = g_vLook;
			g_model.oct.checkOctree(ini_line,director);
			mouseClicked = true;
		}
        g_buttons[RIGHTMOUSE] = (state == GLUT_DOWN);
        break;
    }
}


int main(int arg, char** argv)
{
	glutInitDisplayMode(GLUT_DEPTH | GLUT_RGB | GLUT_DOUBLE);
	glutInitWindowPosition(200, 0);
	glutInitWindowSize(viewportHeigth, viewportWidth);
	glutCreateWindow("Practica 1. Octree");
	glutDisplayFunc(display);
	glutKeyboardFunc(parsekey);
	glutSpecialFunc(parsekey_special);
	glutReshapeFunc(reshape);
	glutIdleFunc(idle);
  glutMouseFunc(mouse);
  glutMotionFunc(motion);

	// load a model
	g_model.load("data\\teapot.ase");
	//g_model.load("data\\knot.ase");
    //g_model.load("data\\box.ase");
    //g_model.load("data\\x3_fighter.ase");
	//g_model.load("data\\terrain.ase");

	glutSwapBuffers();
	glutMainLoop();
	return 0;
}


#undef LEFTMOUSE
#undef MIDDLEMOUSE
#undef RIGHTMOUSE
