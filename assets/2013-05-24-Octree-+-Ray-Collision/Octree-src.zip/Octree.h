#ifndef _OCTREE_H_
#define _OCTREE_H_

class triangle;

#include "vector3f.h"
#include <vector>
#include <string>

#define MAX_DEPTH 4

using namespace std;

class Octree{

private:
	vector3f vert000;
	vector3f vert111;
	vector3f center;

	int triangle_selected;

	int depth;

	vector<vector3f> vertex;
	vector<triangle> triangles; 

public:
	Octree* father;
	vector<vector<vector<Octree*>>> children;

	vector3f getVert000();
	vector3f getVert111();
	vector3f getCenter();
	int getDepth();

	void setVert000(vector3f v000);
	void setVert111(vector3f v111);
	void setCenter(vector3f c);
	void setDepth(int d);


	Octree();
	Octree(std::vector<vector3f> v);
	~Octree();

	void calculateBounding();							//calculate vert000, vert111, center
	
	void addTrin(triangle t);							//add a new triangle to the stack
	void setTrin(vector<triangle> t);					//overwrite the triangle stack

	void addVert(vector3f v);							//add a new vertex to the stack
	vector<vector3f> getVert();							//returns the vertex stack
	void setVert(vector<vector3f> v);					//overwrite the vertex stack
	
	vector<vector<vector<Octree*>>> getChild();			//returns the children stack

	void makeChildren();								//create children with their vertex
	void optimizeChildren();							//delete useless children to optimize memory

	bool vertIn(vector3f v);							//if vertex is inbound return true else return false
	bool hasChildren();									//if octree has children return true else return false
	bool hasVertex();									//if octree has vertes return true else return false
	int sizeChildren();									//returns children.size
	int sizeVertex();									//returns vertex.size
	
	string printInfo();									//returns an string with octree info
	void renderChildBounding() const;					//renders the child's bounding box
	void renderChildTriangles() const;					//renders the child's triangles
	void renderBoundingBox() const;						//renders the bounding box
	void renderTriangles() const;						//renders the triangles

	void checkOctree(vector3f initial_point, vector3f director);
	bool checkBoxIntersection(vector3f initial_point, vector3f director);
	void checkTriangles(vector3f initial_point, vector3f director);
	bool checkTriangleIntersection(triangle *t,vector3f initial_point, vector3f director);


};

#endif // _OCTREE_H_