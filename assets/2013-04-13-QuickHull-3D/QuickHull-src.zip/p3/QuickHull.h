#pragma once
#include "vector3f.h"
#include <vector>
#include "ase.h"

using namespace std;


typedef pair<int,int> ridge;

class facet
{
public:
	union
	{
		struct{unsigned int t[3];};
		struct{unsigned int a,b,c;};
	};
	vector<int> outside_points;
	facet();
	facet(int A, int B,int C):a(A),b(B),c(C){};
	
};

class QuickHull
{
	vector<vector3f> qh_points;
	vector<facet> qh_facets;
	vector3f ref_point;
	unsigned int cstep;
	unsigned int cfacet;
	unsigned int furthest;
	vector<int> vFacets;


public:
	QuickHull(void);
	~QuickHull(void);
	QuickHull(vector<vector3f> p);
	void calculateHull();
	void calcHullStepByStep();

	void renderFacets(bool fill);
	void renderPoints();
	int nfacets(){return qh_facets.size();}

private:
	void calculateSimplex();
	bool pointsOutside();
	bool pointAbovePlane(int a, int b, int c, vector3f p);
	vector<int> allocatePoints(int a, int b, int c,vector<int> points);
	int furthestPoint(facet f);
	float distancePointPlane(int a, int b, int c, vector3f P);
	vector<int> getNeighbourFacet(int f);
	vector<int> getVisibleFacetsFromPoint(int f, int p);
	void eliminarAristasDuplicadas(vector<pair<int, int> >& aristas);
	vector<pair <int,int> > getBoundaryRidges(vector<int> f);
	vector<facet> createNewFacets(vector<pair <int,int> > r,int p);
	vector<int> getOutsidePoints(vector<int>);
	void assignOutsidePoints(vector<int> p);
	void eraseOldFacets(vector<int> facets);
};

