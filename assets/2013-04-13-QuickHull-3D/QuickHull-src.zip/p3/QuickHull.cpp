#include "QuickHull.h"

#ifdef _WIN32
#include <windows.h>
#endif
#include <GL/gl.h>
#include <algorithm>
#include <iostream>

QuickHull::QuickHull(void)
{
	cstep=-1;
	cfacet=0;
	furthest=-1;
}


QuickHull::QuickHull(vector<vector3f> p):
qh_points(p)
{
	cstep=-1;
	cfacet=0;
	furthest=-1;
}


QuickHull::~QuickHull(void)
{
}

void QuickHull::renderFacets(bool fill){
	if(!qh_facets.size()) return;

	glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);

	glBegin(GL_TRIANGLES);
	glColor3f(1,0,0);
	for (unsigned int i=0;i<qh_facets.size();i++)
	{
		glVertex3fv(qh_points[qh_facets[i].a]);
		glVertex3fv(qh_points[qh_facets[i].b]);
		glVertex3fv(qh_points[qh_facets[i].c]);
	}
	glEnd();

	if(fill){
		glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);

		glBegin(GL_TRIANGLES);
		glColor3f(0,1,1);
		glVertex3fv(qh_points[qh_facets[cfacet].a]);
		glVertex3fv(qh_points[qh_facets[cfacet].b]);
		glVertex3fv(qh_points[qh_facets[cfacet].c]);
		for (unsigned int i=0;i<qh_facets.size();i++)
		{
			if(find(vFacets.begin(),vFacets.end(),i)!=vFacets.end()){
				glColor3f(0.8,0.8f,0.0f);
				glVertex3fv(qh_points[qh_facets[i].a]);
				glVertex3fv(qh_points[qh_facets[i].b]);
				glVertex3fv(qh_points[qh_facets[i].c]);

			}else if(cfacet != i){
				glColor3f(0.0f,0.8f,0.0f);
				glVertex3fv(qh_points[qh_facets[i].a]);
				glVertex3fv(qh_points[qh_facets[i].b]);
				glVertex3fv(qh_points[qh_facets[i].c]);
			}
		}
		glEnd();
	}

	glColor3f(1,1,1);
}

void QuickHull::renderPoints(){
	if (!qh_facets.size()) return;

	glPointSize(4);
	
	if (furthest != -1){
		glBegin(GL_POINTS);
		glColor3f(0,1,1);
		glVertex3f(qh_points[furthest].x,qh_points[furthest].y,qh_points[furthest].z);
		glEnd();
	}
	for (unsigned int i=0;i<qh_facets[cfacet].outside_points.size();i++)
	{
		glBegin(GL_POINTS);
		glColor3f(1,0,0);
		glVertex3f(qh_points[qh_facets[cfacet].outside_points[i]].x,qh_points[qh_facets[cfacet].outside_points[i]].y,qh_points[qh_facets[cfacet].outside_points[i]].z);
		glEnd();
	}
	glColor3f(1,1,1);
}

bool QuickHull::pointAbovePlane(int a, int b, int c, vector3f p){
	vector3f A=qh_points[a];
	vector3f B=qh_points[b];
	vector3f C=qh_points[c];
	vector3f AB = B-A;
	vector3f AC = C-A;
	vector3f n = crossProduct(AB,AC); 
	n.normalize();
	float d = -(A.x*n.x+A.y*n.y+A.z*n.z);
	bool res = (p.x*n.x+p.y*n.y+p.z*n.z+d) >= 0;
	return res;

}

vector<int> QuickHull::allocatePoints(int a, int b, int c,vector<int> points){
	vector<int> out;
	for (unsigned int i = 0; i < points.size(); i++){
		if (!(points[i]==a || points[i]==b || points[i]==c))
		if (pointAbovePlane(a,b,c,qh_points[points[i]]))
			out.push_back(points[i]);
	}
	return out;
}

float QuickHull::distancePointPlane(int a, int b, int c, vector3f P){
	vector3f A=qh_points[a];
	vector3f B=qh_points[b];
	vector3f C=qh_points[c];
	vector3f AB = B-A;
	vector3f AC = C-A;
	//AB.normalize();
	//AC.normalize();
	vector3f n = crossProduct(AB,AC);
	//n.normalize();
	float d = -(A.x*n.x+A.y*n.y+A.z*n.z);
	return abs(P.x*n.x+P.y*n.y+P.z*n.z+d)/n.length();
}

void QuickHull::calculateSimplex(){
	int maxZ,minX,maxY;
	for (unsigned int i=0; i <qh_points.size(); i++){
		if (i==0)
			minX = maxZ = maxY = i;
		else{
				 if(qh_points[minX].x > qh_points[i].x)minX = i;
			else if(qh_points[maxZ].z < qh_points[i].z)maxZ = i;
			else if(qh_points[maxY].y < qh_points[i].y)maxY = i;
		}
	}
	qh_facets.push_back(facet(maxZ,minX,maxY));
	qh_facets.push_back(facet(maxZ,maxY,minX));
	float x = (qh_points[minX].x+qh_points[maxZ].x+qh_points[maxY].x)/3.0;
	float y = (qh_points[minX].y+qh_points[maxZ].y+qh_points[maxY].y)/3.0;
	float z = (qh_points[minX].z+qh_points[maxZ].z+qh_points[maxY].z)/3.0;
	ref_point = vector3f(x,y,z);
}


bool QuickHull::pointsOutside(){
	for (unsigned int i=0;i<qh_facets.size();i++){
		if (qh_facets[i].outside_points.size()) return true;
	}
	return false;
}

int QuickHull::furthestPoint(facet f){
	float max=distancePointPlane(f.a,f.b,f.c,qh_points[f.outside_points[0]]);
	int p=f.outside_points[0];
	for (unsigned int i=1; i<f.outside_points.size();i++){
		float dist = distancePointPlane(f.a,f.b,f.c,qh_points[f.outside_points[i]]);
		if (max < dist){
			max = dist;
			p = f.outside_points[i];
		}
	}
	return p;
}


vector<int> QuickHull::getNeighbourFacet(int f){
	vector<int> out;
	for (unsigned int i=0; i<qh_facets.size(); i++){
		if (qh_facets[i].a == qh_facets[f].a || qh_facets[i].a == qh_facets[f].b || qh_facets[i].a == qh_facets[f].c || 
			qh_facets[i].b == qh_facets[f].a || qh_facets[i].b == qh_facets[f].b || qh_facets[i].b == qh_facets[f].c || 
			qh_facets[i].c == qh_facets[f].a || qh_facets[i].c == qh_facets[f].b || qh_facets[i].c == qh_facets[f].c)
			out.push_back(i);
	}
	return out;
}

vector<int> QuickHull::getVisibleFacetsFromPoint(int f, int p){
	vector<int> out = getNeighbourFacet(f);
	for (unsigned int i=0; i<out.size(); i++){
		if (!pointAbovePlane(qh_facets[out[i]].a,qh_facets[out[i]].b,qh_facets[out[i]].c,qh_points[p])){ 
			out.erase(out.begin()+i);
			--i;
		}
	}
	return out;
}

void QuickHull::eliminarAristasDuplicadas(vector<pair<int, int> >& aristas){
	vector<pair<int, int> > out;
	bool found;
	for (unsigned int i = 0; i < aristas.size(); i++){
		found = false;
		for (unsigned int j = i+1; j < aristas.size(); j++){
			if ((aristas[i].first == aristas[j].first && aristas[i].second == aristas[j].second) || (aristas[i].first == aristas[j].second && aristas[i].second == aristas[j].first)){
				found = true;
				aristas.erase(aristas.begin()+j);
				j=aristas.size();
			}
		}
		if (!found)
			out.push_back(aristas[i]);
	}
		aristas = out;
}

vector<pair <int,int> > QuickHull::getBoundaryRidges(vector<int> f){
	vector<pair<int,int> > aristas;
	for (unsigned int i = 0; i < f.size(); i++){
		aristas.push_back(make_pair(qh_facets[f[i]].a,qh_facets[f[i]].b));
		aristas.push_back(make_pair(qh_facets[f[i]].b,qh_facets[f[i]].c));
		aristas.push_back(make_pair(qh_facets[f[i]].c,qh_facets[f[i]].a));
	}
	eliminarAristasDuplicadas(aristas);
	return aristas;
}

vector<facet> QuickHull::createNewFacets(vector<pair <int,int> > r,int p){
	vector<facet> out;
	for (unsigned int i=0; i < r.size(); i++){
		if (!pointAbovePlane(r[i].first,r[i].second,p,ref_point)){
			facet f(r[i].first,r[i].second,p);
			out.push_back(f);
		}else{
			facet f(r[i].first,p,r[i].second);
			out.push_back(f);
		}
	}
	return out;
}

vector<int> QuickHull::getOutsidePoints(vector<int> facets){
	vector<int> outpoints;
	for (unsigned int i=0; i<facets.size(); i++){
		for (unsigned int j=0; j<qh_facets[facets[i]].outside_points.size();j++){
			if (find(outpoints.begin(),outpoints.end(),qh_facets[facets[i]].outside_points[j]) == outpoints.end()) 
				outpoints.push_back(qh_facets[facets[i]].outside_points[j]);
		}
	}
	return outpoints;
}

void QuickHull::assignOutsidePoints(vector<int> p)
{
	for(unsigned int i=0;i<qh_facets.size();i++)
			qh_facets[i].outside_points=allocatePoints(qh_facets[i].a,qh_facets[i].b,qh_facets[i].c,p);
}

void QuickHull::eraseOldFacets(vector<int> facets)
{
	for (unsigned int i=0;i<facets.size();i++)
	{
		qh_facets.erase(qh_facets.begin()+facets[i]);
		
		for (unsigned int j=0;j<facets.size();j++) 
			if (facets[i]<facets[j]) (facets[j])--;
	}
}

void QuickHull::calculateHull(){
	/*
	- Create a triangle with the furthest 3 points.
	- Meanwhile there are points outside the Hull
		- For each facet F.
			- For each point p, assign to F's outside set if is above F.
		- For each facet F with non-empty outside set.
			- Select the furthest point p.
			- Get all facets that p is above.
			- Create a new facet with every non-shared ridge, and delete the old ones
	*/
	vector<int> points;
	points.resize(qh_points.size());
	for (unsigned int i=0; i<qh_points.size();i++) points[i] = i;

	calculateSimplex();

	//assign all points to initial 2 facets
	assignOutsidePoints(points);

	bool outside = true;
	while (outside){
		vector<facet> ff;

		//for each facet that have outside points
		for(unsigned int f=0; f<qh_facets.size();f++){
			if(qh_facets[f].outside_points.size()){
				
				//calculate the furthest point
				int p = furthestPoint(qh_facets[f]);

				//get facets that can see the point
				vector<int> n = getVisibleFacetsFromPoint(f,p);
				
				//get the outside points from the neightbour facets
				points = getOutsidePoints(n);

				//get the ridges from the facets
				vector<ridge> ridges = getBoundaryRidges(n);

				//create new facets with non-shared ridges from ridges and the furthest point
				ff = createNewFacets(ridges,p);

				//erase neightbour facets
				eraseOldFacets(n);
				
				for (unsigned int i=0; i < ff.size(); i++){
					//add the new facets 
					qh_facets.push_back(ff[i]);
					//assign the outside points from old facets to the new facets
					qh_facets[qh_facets.size()-1].outside_points = allocatePoints(qh_facets[qh_facets.size()-1].a,qh_facets[qh_facets.size()-1].b,qh_facets[qh_facets.size()-1].c,points);
				}
				//f = qh_facets.size();
			}
		}
		outside = pointsOutside();
	}

	 
}

void QuickHull::calcHullStepByStep(){
	static vector<int> points;
	if (cstep==-1)
	{
		points.resize(qh_points.size());
		for (unsigned int i=0; i<qh_points.size();i++) points[i] = i;

		calculateSimplex();
		assignOutsidePoints(points);
		cstep++;

		return;
	}

	if (!pointsOutside()) return;

	static vector<ridge> ridges;
	static vector<facet> newFacets;

	switch (cstep%4)
	{
	case 0:
	//find if facet has outside points
		furthest=-1;
		vFacets.clear();
		for (unsigned int i=0;i<qh_facets.size();i++)
			if (qh_facets[i].outside_points.size()>0)
			{
				cfacet=i;
				break;
			}
		
		break;

	case 1:
	//get furthest point
	//get neighboring facets that can see the furthest point 
		furthest=furthestPoint(qh_facets[cfacet]);
		vFacets=getVisibleFacetsFromPoint(cfacet,furthest);
		points = getOutsidePoints(vFacets);

		break;

	case 2:
	//get boundary
		ridges=getBoundaryRidges(vFacets);
		
		break;

	case 3:
	//create new facets from non-shared ridges and the furthest point p
	//erase inside facets
		newFacets = createNewFacets(ridges,furthest);
		eraseOldFacets(vFacets);

		for (unsigned int i=0;i<newFacets.size();i++){
			qh_facets.push_back(newFacets[i]);
			qh_facets[qh_facets.size()-1].outside_points = allocatePoints(qh_facets[qh_facets.size()-1].a,qh_facets[qh_facets.size()-1].b,qh_facets[qh_facets.size()-1].c,points);
		}

		break;
	}
	cstep++;
}
