#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){

    //------------------------ARDUINO =)------------------------
    ofSetWindowPosition(0, 0);

	ofBackground(255);
	m_bSendSerialMessage = false; //Variable to control the interval at which you read information from the Arduino

    m_serial.enumerateDevices(); //print all the devices
	m_serial.setup("COM3", 9600); //open the device at this address



    //----------------------------------------------------------
    //----------------------------------------------------------
    /*------------------------OSC =)------------------------*/
    receiver.setup(PORT);
    sender.setup(HOST, PORT);
    //----------------------------------------------------------
    //----------------------------------------------------------

    // Enabling Alpha Blending for rendering with transparency.    Basically what oF does is rise OpenGL
    // blending flag by calling "glEnable(GL_BLEND);" (and more, like the way the blending should be done).
    // View http://nehe.gamedev.net/tutorial/blending/16001/ for better understanding of the topic.
    ofEnableAlphaBlending();

    // We set the application to run at 60 FPS.
    ofSetFrameRate(60);
    oldTimeSinceStart_ = 0;

    // We initialize the game variables. For this we use their setup() method, following the structure oF
    // proposed for programs.
    scenario_.setup();

    // Initializing the car positions and textures
    cars_[2].setup(120,37.5,35,20);
    cars_[2].set_texture("cars/Small/Red.png");
    cars_[1].setup(120,70,35,20);
    cars_[1].set_texture("cars/Small/Blue.png");
    cars_[0].setup(80,37.5,35,20);
    cars_[0].set_texture("cars/Small/Yellow.png");
    cars_[3].setup(80,70,35,20);
    cars_[3].set_texture("cars/Small/Green.png");

    ofxOscMessage m;
    m.setAddress("texture");
    m.addStringArg("Yellow.png");
    sender.sendMessage(m);
    texture_send_=false;
}

//--------------------------------------------------------------
void testApp::update(){

    /*------------------------ARDUINO =)------------------------

	if (m_bSendSerialMessage){
        m_serial.writeByte('x'); //Send something to the Arduino to wake it up
        unsigned char bytesReturned[NUM_BYTES];
        memset(bytesReturned, 0, NUM_BYTES);//Set 0 for NUM_BYTES in bytesReturned
        while(m_serial.readBytes(bytesReturned, NUM_BYTES) > 0){ //While there's in receiving
        }
        //Read info from the potentiometer
        m_iValPotenciometer = ofToInt(ofToString(bytesReturned[0]));

        //Read info from the button
        m_iValButton = ofToInt(ofToString(bytesReturned[1]));


        m_bSendSerialMessage = false;

    }
    // wait a 5 cycles before asking again since OF go faster than serial
    m_iCountCycles++;
    if(m_iCountCycles >= 5) {
        m_bSendSerialMessage = true;
        m_iCountCycles = 0;
    }
*/
    //----------------------------------------------------------
    //----------------------------------------------------------
    /*------------------------OSC =)------------------------*/
    while(receiver.hasWaitingMessages()){
        ofxOscMessage m;
        receiver.getNextMessage(&m);
        if (!texture_send_ && m.getAddress() == "texture"){
            cars_[1].set_texture("cars/Small/"+m.getArgAsString(0));
            ofxOscMessage m;
            m.setAddress("texture");
            m.addStringArg("Yellow.png");
            sender.sendMessage(m);
            texture_send_=true;
        }
        if (m.getAddress() == "position"){
            string s = m.getArgAsString(0);
            XML.loadFromBuffer(s);
            int x,y,r;
            XML.pushTag("POSITION");
            x = XML.getValue("X", 1.0);
            y = XML.getValue("Y", 1.0);
            r = XML.getValue("R", 1.0);

            cars_[1].setPosition(ofPoint(x,y));
            cars_[1].setRotation(r);
            XML.popTag();
        }
    }
    //----------------------------------------------------------
    //----------------------------------------------------------
/*
    if (m_iValButton) cars_[0].car_accelerate();
    if (!m_iValButton) cars_[0].car_break();
    if (m_iValPotenciometer-2) cars_[0].car_turn((m_iValPotenciometer-2)*2);

*/
/*
    if (key_Pressed[357]) //Up
        cars_[0].car_accelerate();
    if (!key_Pressed[357] && !key_Pressed[359]) //If the accelerating button is not pressed the speed decrements
        cars_[0].car_break();
    if (key_Pressed[356]) //Left
        cars_[0].car_turn_left();
    if (key_Pressed[358]) //Right
        cars_[0].car_turn_right();
    if (key_Pressed[359]) //Down
        cars_[0].car_reverse();
*/

    if (key_Pressed['w']) //Up
        cars_[0].car_accelerate();
    if (!key_Pressed['w'] && !key_Pressed['s']) //If the accelerating button is not pressed the speed decrements
        cars_[0].car_break();
    if (key_Pressed['a']) //Left
        cars_[0].car_turn_left();
    if (key_Pressed['d']) //Right
        cars_[0].car_turn_right();
    if (key_Pressed['s']) //Down
        cars_[0].car_reverse();

    float timeSinceStart_ = ofGetElapsedTimef();
    float dt = timeSinceStart_ - oldTimeSinceStart_;
    oldTimeSinceStart_ = timeSinceStart_;

//    for (int i = 0; i < 2; i++)
    cars_[0].update(dt);

    ofxOscMessage m1;
    string s = "<POSITION><X>"+ofToString(cars_[0].getPosition().x)+"</X><Y>"+ofToString(cars_[0].getPosition().y)+"</Y><R>"+ofToString(cars_[0].getRotation())+"</R></POSITION>";
    m1.setAddress("position");
    m1.addStringArg(s);
    sender.sendMessage(m1);
}

//--------------------------------------------------------------
void testApp::draw(){

    //cout << m_iValPotenciometer << " - " << m_iValButton <<endl;
    scenario_.draw();

    //Drawing all the cars
    for (int i = 0; i < 2; i++)
        cars_[i].draw();

    // Displaying the frames per second of the application at the main Window. We close
    // it inside a push and popStyle calls so the color set for draw won't affect any
    // drawing outside.
    ofPushStyle();
        string info = "";
        info += "FPS: "+ofToString(ofGetFrameRate())+"\n";
        ofSetHexColor(0xFF8800);
        ofDrawBitmapString(info, 30, 15);
    ofPopStyle();

}

//--------------------------------------------------------------
void testApp::keyPressed(int key){
    key_Pressed[key] = true;
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){
    key_Pressed[key] = false;
}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){

}
