#include "car.h"

//--------------------------------------------------------------
Car::Car(){
    texture_ = (ofImage*)malloc(sizeof(ofImage));

}

//--------------------------------------------------------------
Car::~Car(){

}

//--------------------------------------------------------------
void Car::setup(float x, float y, float width, float height){

    cout << "LOADING CAR" << endl;

    car_position_.set(x, y);
    car_rotation_ = 0;

    car_speed_ = 0;
    car_angle_ = 0;

    car_width_ = width;
    car_height_ = height;

}

void Car::set_texture(string path){
    texture_ = new ofImage();
    texture_->loadImage(path);
}

//--------------------------------------------------------------
void Car::update(float dt){

    ofVec2f giro(cos(car_rotation_*PI/180),sin(car_rotation_*PI/180)); //cos() and sin() works in radians
    ofPoint new_point = car_position_+giro*car_speed_*dt;
    //The position is only setted if we are on the limits of the scenario
    if (ofInRange(new_point.x,0, ofGetWidth()-car_width_) &&
        ofInRange(new_point.y,0,ofGetHeight()-car_height_))
            car_position_.set(new_point);
}

//--------------------------------------------------------------
void Car::draw(){
    ofPushMatrix();

        ofTranslate(car_position_.x,car_position_.y);
        ofTranslate(car_width_/2,car_height_/2);
        ofRotate(car_rotation_,0,0,1);

        ofTranslate(-car_width_/2,-car_height_/2);

        texture_->draw(0,0,car_width_,car_height_);

    ofPopMatrix();

}

void Car::car_accelerate(){
    if (car_speed_ < 250)
        car_speed_+=10;
}

void Car::car_break(){
    if(car_speed_>5)
        car_speed_-=5;
    else if(car_speed_<-5)
        car_speed_+=5;
    else
        car_speed_=0;
}
void Car::car_turn(int t){
    car_rotation_ +=t;
    car_rotation_ = fmod(car_rotation_,360);
}

void Car::car_turn_left(){
    car_rotation_-=4;
    car_rotation_ = fmod(car_rotation_,360);
}

void Car::car_turn_right(){
    car_rotation_+=4;
    car_rotation_ = fmod(car_rotation_,360);
}

void Car::car_reverse(){
    if (car_speed_> -200)
        car_speed_-=8;
}

void Car::to_string(){
    cout << "Position: " << car_position_.x << "x" << car_position_.y << endl;
    cout << "Rotation: " << car_rotation_ << endl;
    cout << "Speed: " << car_speed_ << endl;
}


