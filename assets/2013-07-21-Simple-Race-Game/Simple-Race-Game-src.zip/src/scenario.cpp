#include "scenario.h"

//--------------------------------------------------------------
Scenario::Scenario(){

    // Here we reserve space for the instantation of the class.
    texture_array_ = (ofImage**)malloc(7*sizeof(ofImage*));

    scenario_width_ = 8;
    scenario_height_ = 6;

    tile_width_ = ofGetWidth()/scenario_width_;
    tile_height_ = ofGetHeight()/scenario_height_;

    scenario_array_ = (int*)malloc(scenario_width_*scenario_height_*sizeof(int));

}

//--------------------------------------------------------------
Scenario::~Scenario(){

}

//--------------------------------------------------------------
void Scenario::setup(){

	// Just for loading purposes we print by console when we start loading the scenario.
	cout << "LOADING SCENARIO" << endl;

    string track_temp;

    if( XML.loadFile("game_data.xml") ){
        std::cout << "LOADING FROM XML"<<std::endl;
        std::string auxs;
        float auxfx, auxfy;
        int auxi;

        XML.pushTag("TEXTURES");

		for(int i = 0; i <= 7; ++i){
            XML.pushTag("TEXTURE",i);
            auxs = XML.getValue("ADDRESS", "");
            (*(texture_array_+i)) = new ofImage();
            (*(texture_array_+i))->loadImage(auxs);
            XML.popTag();
        }

        XML.popTag();

        XML.pushTag("TREES");
        auxi = XML.getNumTags("TREE");
        std::cout << auxi << std::endl;

        for(int i = 0; i < auxi; ++i){
            XML.pushTag("TREE", i);
            auxfx = XML.getValue("X", 0.0);
            auxfy = XML.getValue("Y", 0.0);
            trees_vector_.push_back(ofPoint(auxfx, auxfy));
            XML.popTag();
        }
        XML.popTag();

        track_temp = XML.getValue("TRACK:DESIGN", "");
	}else{
        // We load the different tiles for later drawing the scenario given by the scenario_array_.
        // The order for loading the tiles images is important as their position in the array
        // is the code being used for specifying the scenario.
        cout << "SCENARIO: LOADING TILES IMAGES" << endl;
        (*(texture_array_+0)) = new ofImage();
        (*(texture_array_+0))->loadImage("track/grass.jpg");
        (*(texture_array_+1)) = new ofImage();
        (*(texture_array_+1))->loadImage("track/racing_curve_1.jpg");
        (*(texture_array_+2)) = new ofImage();
        (*(texture_array_+2))->loadImage("track/racing_curve_2.jpg");
        (*(texture_array_+3)) = new ofImage();
        (*(texture_array_+3))->loadImage("track/racing_curve_3.jpg");
        (*(texture_array_+4)) = new ofImage();
        (*(texture_array_+4))->loadImage("track/racing_curve_4.jpg");
        (*(texture_array_+5)) = new ofImage();
        (*(texture_array_+5))->loadImage("track/racing_road_vert.jpg");
        (*(texture_array_+6)) = new ofImage();
        (*(texture_array_+6))->loadImage("track/racing_road_hor.jpg");
        (*(texture_array_+7)) = new ofImage();
        (*(texture_array_+7))->loadImage("track/Tree.png");

        // We load different positions for the trees.
        trees_vector_.push_back(ofPoint(187, 441));
        trees_vector_.push_back(ofPoint(221, 307));
        trees_vector_.push_back(ofPoint(563, 226));
        trees_vector_.push_back(ofPoint(509, 595));
        trees_vector_.push_back(ofPoint(903, 229));
        trees_vector_.push_back(ofPoint(755, 364));

        // This is normally the way to do this, but you will understand later why we do it with a string.
        // Here we create a string that defines the scenario. We parse this string taking the numbers
        // and adding them to the scenario array.
        // The scenario looks like:
        // 3, 6, 6, 6, 6, 6, 6, 4,
        // 5, 0, 0, 0, 0, 0, 3, 1,
        // 5, 0, 0, 3, 4, 0, 5, 0,
        // 5, 0, 3, 1, 5, 0, 2, 4,
        // 5, 0, 5, 0, 5, 0, 0, 5,
        // 2, 6, 1, 0, 2, 6, 6, 1
        track_temp = "3, 6, 6, 6, 6, 6, 6, 4, 5, 0, 0, 0, 0, 0, 3, 1, 5, 0, 0, 3, 4, 0, 5, 0, 5, 0, 3, 1, 5, 0, 2, 4, 5, 0, 5, 0, 5, 0, 0, 5, 2, 6, 1, 0, 2, 6, 6, 1";
    }

    int i = 0;
    unsigned found = track_temp.find_first_of(",");
    while (found!=std::string::npos && i <scenario_width_*scenario_height_)
    {
        *(scenario_array_+i) = ofToInt(ofToString(track_temp[found-1]));
        found = track_temp.find_first_of(",",found+1);
        i++;
    }

    // We load at the last position the last number in the string.
    *(scenario_array_+i) = ofToInt(ofToString(track_temp[track_temp.length()-1]));

}
//--------------------------------------------------------------
void Scenario::update(){



}

//--------------------------------------------------------------
void Scenario::draw(){

    // We set the color to draw at pure white.
    ofSetColor(255, 255, 255);

    // For the size of the scenario specified by scenario_width_ and scenario_height_
    // we parse the scenario_array_ to get which texture should be drawn. Then we draw
    // it in the expected position.
    for(int j = 0; j < scenario_height_; j++){
        for(int i = 0; i < scenario_width_; i++){
            int tile_type = *(scenario_array_+j*scenario_width_+i);

            (*(texture_array_+tile_type))->draw(i*tile_width_, j*tile_height_, tile_width_, tile_height_);

        }
    }

    // We iterate over the different tree position stored at tree_vector_. In this case we use an iterator
    // to go through the vector (iterators tend to be the most efficient way to search through a data
    // container from STL.
    // For each position we do a push and popMatrix() so the call to ofTranslate() will not affect the posterior
    // renders in the game loop. Observe by that calling the ofTranslate, we can now pass as x and y arguments to
    // ogImage().draw() the values 0, 0.
    for (std::vector<ofPoint>::iterator it = trees_vector_.begin() ; it != trees_vector_.end(); ++it){
        ofPushMatrix();
            ofTranslate((*it).x, (*it).y);
            (*(texture_array_+7))->draw(0, 0, tile_width_/3, tile_height_/3);
        ofPopMatrix();
    }

}
