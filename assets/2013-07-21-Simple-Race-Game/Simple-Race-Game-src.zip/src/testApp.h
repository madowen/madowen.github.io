#pragma once

#include "ofMain.h"

#include "car.h"
#include "scenario.h"

#include "ofxOsc.h"
#include "ofxXmlSettings.h"

#define PLAYERS 4

#define PORT 12345
#define HOST "37.15.230.170"

const int NUM_BYTES = 2;


class testApp : public ofBaseApp{
	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y);
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);

	private:
		// We declare the car and scenario
		Car			cars_[PLAYERS];
		Scenario	scenario_;

		float       oldTimeSinceStart_;
		bool        key_Pressed[370];
		// ARDUINO
		int             m_iValPotenciometer, m_iValButton;
        bool            m_bSendSerialMessage;
        int             m_iCountCycles;
        ofSerial        m_serial;

        // OSC
        ofxOscReceiver receiver;
		ofxOscSender sender;
        ofxXmlSettings XML;
        bool texture_send_;


};
