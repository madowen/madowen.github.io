#pragma once

#include "ofMain.h"
#include "ofxXmlSettings.h"


class Scenario{
    public:
        // Declaration of the basic methods for the scenario class.
        Scenario();
        ~Scenario();

        void setup();
        void update();
        void draw();

    private:
        // Declaring a pointer of ofImage pointer for dinamically allocating
        // memory. It could have been used a static array, or a vector, but
        // this we can see different types of storing data.
        ofImage**                texture_array_;

        // This pointer will store the information for drawing the scenario.
        // It will have a series of integers representing which texture shoudl
        // be drawn.
        int*                    scenario_array_;
        //int                    scenario_array_[];

        // In this vector we store with ofPoints the position of some decorative
        // trees.
        vector<ofPoint>            trees_vector_;

        // Widht and hide of the scenario measured by tiles (or how many "rectangles"
        // compose the scenario.
        int                        scenario_width_;
        int                        scenario_height_;

        // Width and height of the tiles for drawing the scenario.
        float                    tile_width_;
        float                    tile_height_;

        ofxXmlSettings XML;
};
