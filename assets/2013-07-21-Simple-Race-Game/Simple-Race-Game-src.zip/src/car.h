#pragma once

#include "ofMain.h"
#include <math.h>

class Car{
    public:
        // We declare the basic methods for the class.
        Car();
        ~Car();

        void setup(float x, float y,float width, float height);
        void update(float dt);
        void draw();

        void set_texture(string path);

        // Declaration of two helper functions. These can be used to call them from
        // testApp and draw with the ofDrawBitmapString() info of the car in real time
        // while running the application. (much better than displaying by console :)).
        ofPoint getPosition(){
            return car_position_;
        };
        float getRotation(){
            return car_rotation_;
        };

        float getSpeed(){
            return car_speed_;
        };
        void setSpeed(float s){car_speed_=s;};
        void setPosition(ofPoint p){car_position_=p;};
        void setRotation(float r){car_rotation_=r;};

        void car_accelerate();  //Increase car speed
        void car_break();       //Decrease car speed if accelerate key is not pressed
        void car_turn(int t);   //Turn the car t units //ARDUINO
        void car_turn_left();   //Turn the car into left direction
        void car_turn_right();  //Turn the car into left direction
        void car_reverse();     //Decrease car speed faster than car_break and. If speed = 0 reverse
        void to_string();

    private:
        // These are variables that may come in hand for the car movement. You can use
        // any of these or implement car's behaviour any other way.
        ofPoint              car_position_;
        float                car_rotation_;
        float                car_speed_;
        float                car_angle_;
        ofImage*             texture_;
        // The variables are declared to store the size in which the car image will
        // be drawn.
        float                car_width_;
        float                car_height_;

};
